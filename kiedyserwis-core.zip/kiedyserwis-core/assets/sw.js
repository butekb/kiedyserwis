const CACHE_NAME = 'kiedyserwis-v2';
// Only cache static, non-sensitive assets.
// The dashboard panel (/panel-serwisanta/) intentionally excluded to prevent
// caching authenticated customer data (names, phones, service records) on
// shared or compromised devices.
const urlsToCache = [
  './manifest.json'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Always use the network for the authenticated dashboard and any POST request.
  // This prevents stale or cross-user data being served from the cache.
  if (
    url.pathname.startsWith('/panel-serwisanta') ||
    url.pathname.startsWith('/wp-json') ||
    url.pathname.startsWith('/wp-admin') ||
    event.request.method !== 'GET'
  ) {
    event.respondWith(fetch(event.request));
    return;
  }

  // Cache-first for truly static assets (manifest, icons, etc.).
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) {
          return response;
        }
        return fetch(event.request);
      }
    )
  );
});
