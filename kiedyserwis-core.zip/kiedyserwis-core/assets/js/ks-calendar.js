/**
 * KiedySerwis Enhanced Calendar – ks-calendar.js
 *
 * FullCalendar v6 integration for the serwisant (field technician) dashboard.
 * Loaded only when the ks_use_new_calendar feature flag is enabled.
 *
 * Globals injected by wp_localize_script:
 *   ksCalendarData.apiBase     – REST API base URL
 *   ksCalendarData.nonce       – X-WP-Nonce value
 *   ksCalendarData.userId      – current WordPress user ID
 *   ksCalendarData.locale      – WordPress locale string
 *   ksCalendarData.initialView – 'timeGridWeek' | 'listWeek'
 */
/* global FullCalendar, ksCalendarData */
(function () {
    'use strict';

    // =========================================================
    // State
    // =========================================================
    var calendar = null;
    var isMobile = window.innerWidth < 768;

    // DOM references (resolved after DOMContentLoaded)
    var calEl          = null;
    var modalEl        = null;
    var sheetEl        = null;
    var sheetOverlayEl = null;
    var fabEl          = null;
    var quickModal     = null;
    var conflictModal  = null;
    var filterBar      = null;
    var bulkBar        = null;

    // Event currently displayed in the detail modal / bottom-sheet.
    var activeEvent     = null;
    // IDs selected for bulk operations.
    var selectedIds     = [];
    // Pending drag/resize revert function (FullCalendar).
    var pendingRevert   = null;
    // Pending conflict data waiting for user resolution.
    var pendingConflict = null;

    // =========================================================
    // Bootstrap
    // =========================================================
    document.addEventListener('DOMContentLoaded', function () {
        calEl          = document.getElementById('ks-new-calendar');
        modalEl        = document.getElementById('ks-cal-modal');
        sheetEl        = document.getElementById('ks-cal-sheet');
        sheetOverlayEl = document.getElementById('ks-cal-sheet-overlay');
        fabEl          = document.getElementById('ks-cal-fab');
        quickModal     = document.getElementById('ks-cal-quick-modal');
        conflictModal  = document.getElementById('ks-cal-conflict-modal');
        filterBar      = document.getElementById('ks-cal-filters');
        bulkBar        = document.getElementById('ks-cal-bulk-bar');

        if (!calEl) return;

        initCalendar();
        bindStaticEvents();
    });

    // =========================================================
    // FullCalendar initialisation
    // =========================================================
    function initCalendar() {
        var locale = (ksCalendarData.locale || 'pl_PL').split('_')[0];

        calendar = new FullCalendar.Calendar(calEl, {
            locale:       locale === 'pl' ? 'pl' : 'en',
            initialView:  ksCalendarData.initialView || 'timeGridWeek',
            firstDay:     1,
            nowIndicator: true,
            editable:     false,   // drag-and-drop disabled (issue #8)
            selectable:   true,
            selectMirror: true,
            allDaySlot:   false,   // remove "all-day" row entirely (issue #2)
            height:       'auto',
            headerToolbar: {
                left:   'prev,next today',
                center: 'title',
                right:  'timeGridDay,timeGridWeek,listWeek'
            },
            buttonText: {
                today: 'Dziś',
                day:   'Dzień',
                week:  'Tydzień',
                list:  'Lista'
            },
            noEventsText: 'Brak wizyt do wyświetlenia',
            slotMinTime:    '06:00:00',
            slotMaxTime:    '21:00:00',
            slotDuration:   '00:30:00',
            snapDuration:   '00:15:00',
            eventMinHeight: 30,

            events:       fetchEvents,
            eventContent: renderEventContent,
            eventClick:   onEventClick,
            select:       onSlotSelect,

            loading: function (isLoading) {
                var spinner = document.getElementById('ks-cal-spinner');
                if (spinner) spinner.style.display = isLoading ? 'flex' : 'none';
            }
        });

        calendar.render();
        wireViewSwitch();
    }

    // =========================================================
    // Event fetching (REST)
    // =========================================================
    function fetchEvents(info, successCallback, failureCallback) {
        var url = ksCalendarData.apiBase + '/events'
            + '?start=' + formatDate(info.start)
            + '&end='   + formatDate(info.end)
            + getActiveFilters();

        apiFetch('GET', url, null, function (data) {
            successCallback(data.map(mapEventToFC));
        }, function (err) {
            console.error('[KS-Cal] fetch error', err);
            failureCallback(err);
        });
    }

    function getActiveFilters() {
        if (!filterBar) return '';
        var status = filterBar.querySelector('[data-filter="status"]');
        return (status && status.value) ? '&status=' + encodeURIComponent(status.value) : '';
    }

    function mapEventToFC(ev) {
        return {
            id:              String(ev.id),
            title:           ev.title,
            start:           ev.start,
            end:             ev.end,
            extendedProps:   ev,
            classNames:      eventClassNames(ev),
            backgroundColor: statusColor(ev.status, ev.is_custom),
            borderColor:     statusColor(ev.status, ev.is_custom)
        };
    }

    function eventClassNames(ev) {
        var cls = ['ks-fc-event'];
        cls.push('ks-status-' + (ev.status || 'scheduled'));
        if (ev.is_custom)            cls.push('ks-custom-app');
        if (ev.meta && ev.meta.has_protocol) cls.push('ks-has-protocol');
        if (ev.meta && ev.meta.parts_needed) cls.push('ks-parts-needed');
        return cls;
    }

    function statusColor(status, isCustom) {
        if (isCustom) return '#8B5CF6';
        switch (status) {
            case 'completed': return '#10B981';
            case 'cancelled': return '#EF4444';
            default:          return '#4F46E5';
        }
    }

    // =========================================================
    // Custom event rendering (badges + icons)
    // =========================================================
    function renderEventContent(arg) {
        var ev   = arg.event.extendedProps;
        var meta = (ev && ev.meta) ? ev.meta : {};
        var view = arg.view.type;

        if (view.indexOf('list') === 0) {
            return renderListItem(arg.event, meta);
        }
        return renderGridItem(arg.event, meta);
    }

    function renderGridItem(event, meta) {
        var time  = event.start ? formatTime(event.start) : '';
        var icons = '';
        if (meta.has_protocol) icons += '<span class="ks-badge-icon" aria-label="Protokół podpisany" title="Protokół podpisany">&#10003;</span>';
        if (meta.parts_needed) icons += '<span class="ks-badge-icon ks-badge-warn" aria-label="Brak części" title="Brak części">!</span>';
        if (meta.sms_sent)     icons += '<span class="ks-badge-icon ks-badge-sms" aria-label="SMS wysłany" title="SMS wysłany">&#9993;</span>';

        var html = '<div class="ks-fc-event-inner">'
            + '<span class="ks-fc-time">' + time + '</span>'
            + '<span class="ks-fc-title">' + escHtml(event.title) + '</span>'
            + '<span class="ks-fc-icons">' + icons + '</span>'
            + '</div>';

        var el = document.createElement('div');
        el.innerHTML = html;
        return { domNodes: [el] };
    }

    function renderListItem(event, meta) {
        var ev       = event.extendedProps || {};
        var status   = ev.status || 'scheduled';
        var labelMap = { scheduled: 'Zaplanowana', completed: 'Zakończona' };
        var label    = labelMap[status] || status;
        var time     = event.start ? formatTime(event.start) : '';
        var worker   = ev.worker_name || '';
        var icons = '';
        if (meta.has_protocol) icons += '<span class="ks-badge-icon" aria-label="Protokół">&#10003;</span>';
        if (meta.parts_needed) icons += '<span class="ks-badge-icon ks-badge-warn" aria-label="Brak części">!</span>';

        // Top row: time + icons; title on second row; status badge below title; worker name last.
        var html = '<div class="ks-fc-list-item">'
            + '<div class="ks-fc-list-top">'
            + (time ? '<span class="ks-fc-list-time">' + time + '</span>' : '')
            + icons
            + '</div>'
            + '<div class="ks-fc-list-title">' + escHtml(event.title) + '</div>'
            + '<div class="ks-fc-list-meta">'
            + '<span class="ks-fc-status-badge ks-status-badge-' + status + '">' + escHtml(label) + '</span>'
            + '</div>'
            + (worker ? '<div class="ks-fc-list-worker">&#128100; ' + escHtml(worker) + '</div>' : '')
            + '</div>';

        var el = document.createElement('div');
        el.innerHTML = html;
        attachSwipeGesture(el, event, ev);
        return { domNodes: [el] };
    }

    // =========================================================
    // Swipe gestures (list view – mobile)
    // =========================================================
    function attachSwipeGesture(el, fcEvent, ev) {
        var startX    = 0;
        var THRESHOLD = 80;

        el.addEventListener('touchstart', function (e) {
            startX = e.touches[0].clientX;
        }, { passive: true });

        el.addEventListener('touchend', function (e) {
            var dx = e.changedTouches[0].clientX - startX;
            if (Math.abs(dx) < THRESHOLD) return;

            if (dx > 0) {
                // Swipe right → mark done
                markDone(ev);
            } else {
                // Swipe left → open event details for rescheduling
                openEventDetail(ev, fcEvent);
            }
        }, { passive: true });
    }

    function markDone(ev) {
        patchEvent(ev.id, { status: 'completed' }, function () {
            calendar.refetchEvents();
            showToast('Wizyta oznaczona jako zakończona.', 'success');
        }, function (err) {
            showToast('Błąd: ' + ((err && err.message) || 'Nie udało się zaktualizować statusu.'), 'error');
        });
    }

    // =========================================================
    // Event click / slot select
    // =========================================================
    function onEventClick(info) {
        var ev = info.event.extendedProps;
        openEventDetail(ev, info.event);
    }

    function onSlotSelect(info) {
        openQuickCreate(info.startStr, info.endStr);
        calendar.unselect();
    }

    // =========================================================
    // Event detail modal (desktop) / bottom-sheet (mobile)
    // =========================================================
    function openEventDetail(ev, fcEvent) {
        activeEvent  = ev;
        var meta     = (ev && ev.meta) ? ev.meta : {};
        var phone    = meta.phone      || '';
        var addr     = meta.address    || '';
        var notes    = meta.notes      || '';
        var status   = ev.status       || 'scheduled';
        var worker   = ev.worker_name  || '';
        var labelMap = { scheduled: 'Zaplanowana', completed: 'Zakończona' };

        var content = '<div class="ks-detail-header">'
            + '<h3 class="ks-detail-title">' + escHtml(ev.title) + '</h3>'
            + '</div>'
            + '<div class="ks-detail-meta">'
            + '<span class="ks-status-badge ks-status-badge-' + status + '">' + escHtml(labelMap[status] || status) + '</span>'
            + (worker ? '<span class="ks-detail-worker">&#128100; ' + escHtml(worker) + '</span>' : '')
            + '</div>';

        if (ev.start) {
            content += '<p class="ks-detail-row"><span class="ks-detail-icon" aria-hidden="true">📅</span>'
                + escHtml(formatDateTime(ev.start))
                + (ev.end ? ' – ' + escHtml(formatTime(ev.end)) : '') + '</p>';
        }
        if (addr) {
            content += '<p class="ks-detail-row"><span class="ks-detail-icon" aria-hidden="true">📍</span>'
                + '<a href="https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(addr)
                + '" target="_blank" rel="noopener noreferrer">' + escHtml(addr) + '</a></p>';
        }
        if (phone) {
            content += '<p class="ks-detail-row"><span class="ks-detail-icon" aria-hidden="true">📞</span>'
                + '<a href="tel:' + escHtml(phone) + '">' + escHtml(phone) + '</a></p>';
        }
        if (notes) {
            content += '<p class="ks-detail-row ks-detail-notes">' + escHtml(notes) + '</p>';
        }

        var badges = '';
        if (meta.has_protocol) badges += '<span class="ks-chip ks-chip-ok">Protokół podpisany</span>';
        if (meta.parts_needed)  badges += '<span class="ks-chip ks-chip-warn">Brak części</span>';
        if (meta.sms_sent)      badges += '<span class="ks-chip ks-chip-sms">SMS wysłany</span>';
        if (badges) content += '<div class="ks-chip-row">' + badges + '</div>';

        var actions = '<div class="ks-detail-actions">';
        if (phone) {
            actions += '<a href="tel:' + escHtml(phone) + '" class="ks-btn-action-detail ks-btn-call">📞 Zadzwoń</a>';
        }
        if (status !== 'completed') {
            actions += '<button class="ks-btn-action-detail ks-btn-done" type="button">&#10003; Zakończ</button>';
        }
        actions += '<button class="ks-btn-action-detail ks-btn-reschedule" type="button">🗓 Przełóż</button>';
        actions += '<button class="ks-btn-action-detail ks-btn-ics" type="button">💾 Zapisz na swoim urządzeniu</button>';
        actions += '<button class="ks-btn-action-detail ks-btn-delete" type="button">🗑 Usuń</button>';
        actions += '</div>';

        content += actions;

        if (isMobile) {
            openBottomSheet(content, ev);
        } else {
            openModal(content, ev);
        }
    }

    function openModal(html, ev) {
        if (!modalEl) return;
        var body = modalEl.querySelector('.ks-cal-modal-body');
        if (body) body.innerHTML = html;
        modalEl.style.display = 'flex';
        modalEl.setAttribute('aria-hidden', 'false');
        bindDetailActions(modalEl, ev);
        var closer = modalEl.querySelector('.ks-close-btn');
        if (closer) closer.focus();
    }

    function closeModal() {
        if (!modalEl) return;
        modalEl.style.display = 'none';
        modalEl.setAttribute('aria-hidden', 'true');
    }

    function openBottomSheet(html, ev) {
        if (!sheetEl) return;
        var body = sheetEl.querySelector('.ks-cal-sheet-body');
        if (body) body.innerHTML = html;
        sheetEl.classList.add('open');
        if (sheetOverlayEl) sheetOverlayEl.classList.add('open');
        sheetEl.setAttribute('aria-hidden', 'false');
        bindDetailActions(sheetEl, ev);
    }

    function closeBottomSheet() {
        if (!sheetEl) return;
        sheetEl.classList.remove('open');
        if (sheetOverlayEl) sheetOverlayEl.classList.remove('open');
        sheetEl.setAttribute('aria-hidden', 'true');
    }

    function bindDetailActions(container, ev) {
        var doneBtn = container.querySelector('.ks-btn-done');
        if (doneBtn) {
            doneBtn.addEventListener('click', function () {
                markDone(ev);
                if (isMobile) closeBottomSheet(); else closeModal();
            });
        }
        var rescheduleBtn = container.querySelector('.ks-btn-reschedule');
        if (rescheduleBtn) {
            rescheduleBtn.addEventListener('click', function () {
                openQuickCreate(ev.start, ev.end, ev.id);
                if (isMobile) closeBottomSheet(); else closeModal();
            });
        }
        var icsBtn = container.querySelector('.ks-btn-ics');
        if (icsBtn) {
            icsBtn.addEventListener('click', function () {
                exportICS(ev);
            });
        }
        var deleteBtn = container.querySelector('.ks-btn-delete');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                if (!confirm('Czy na pewno chcesz usunąć tę wizytę? Operacja jest nieodwracalna.')) return;
                if (isMobile) closeBottomSheet(); else closeModal();
                deleteEvent(ev);
            });
        }
    }

    // =========================================================
    // Delete event
    // =========================================================
    function deleteEvent(ev) {
        apiFetch('DELETE', ksCalendarData.apiBase + '/events/' + ev.id, null,
            function () {
                calendar.refetchEvents();
                showToast('Wizyta usunięta.', 'success');
            },
            function (err) {
                showToast('Błąd: ' + ((err && err.message) || 'Nie udało się usunąć wizyty.'), 'error');
            }
        );
    }

    // =========================================================
    // Quick-create / reschedule modal
    // =========================================================
    function openQuickCreate(start, end, editId) {
        if (!quickModal) return;

        var startVal = start ? String(start).replace('Z', '').substring(0, 16) : '';
        var endVal   = end   ? String(end).replace('Z', '').substring(0, 16)   : '';
        var isEdit   = !!editId;

        var titleWrap = quickModal.querySelector('#ks-qc-title-wrap');
        if (titleWrap) titleWrap.style.display = isEdit ? 'none' : '';

        var deviceInput = quickModal.querySelector('#ks-qc-device-id');
        if (deviceInput) deviceInput.value = isEdit ? String(editId) : '';

        var startInput = quickModal.querySelector('#ks-qc-start');
        if (startInput) startInput.value = startVal;

        var endInput = quickModal.querySelector('#ks-qc-end');
        if (endInput) endInput.value = endVal;

        var titleInput = quickModal.querySelector('#ks-qc-title');
        if (titleInput) titleInput.value = '';

        var addrInput = quickModal.querySelector('#ks-qc-address');
        if (addrInput) addrInput.value = '';

        var notesInput = quickModal.querySelector('#ks-qc-notes');
        if (notesInput) notesInput.value = '';

        // Worker picker: pre-select the existing event's technician when rescheduling;
        // reset to "— Ja (Manager) —" when creating a new appointment.
        var workerSelect = quickModal.querySelector('#ks-qc-worker');
        if (workerSelect) {
            if (isEdit && activeEvent && activeEvent.technician_id) {
                workerSelect.value = String(activeEvent.technician_id);
            } else {
                workerSelect.value = '';
            }
        }

        quickModal.style.display = 'flex';
        quickModal.setAttribute('aria-hidden', 'false');

        var firstInput = quickModal.querySelector('input:not([type=hidden]), select, textarea');
        if (firstInput) firstInput.focus();
    }

    function closeQuickModal() {
        if (!quickModal) return;
        quickModal.style.display = 'none';
        quickModal.setAttribute('aria-hidden', 'true');
    }

    // =========================================================
    // Drag & Drop / Resize – optimistic UI + server reconciliation
    // =========================================================
    function onEventDrop(info) {
        handleEventChange(info.event, info.revert, false, '');
    }

    function onEventResize(info) {
        handleEventChange(info.event, info.revert, false, '');
    }

    function handleEventChange(fcEvent, revert, force, note) {
        var ev      = fcEvent.extendedProps;
        var startISO = fcEvent.start ? fcEvent.start.toISOString() : null;
        var endISO   = fcEvent.end   ? fcEvent.end.toISOString()   : null;

        if (!startISO || !endISO) { revert(); return; }

        var payload = { start: startISO, end: endISO };
        if (force) payload.force = true;
        if (note)  payload.note  = note;

        patchEvent(ev.id, payload, function () {
            calendar.refetchEvents();
        }, function (err) {
            if (err && err.code === 'ks_conflict' && err.conflicts) {
                pendingRevert   = revert;
                pendingConflict = { event: fcEvent, conflicts: err.conflicts };
                openConflictDialog(fcEvent, err.conflicts);
            } else {
                revert();
                showToast('Błąd: ' + ((err && err.message) || 'Nie udało się zaktualizować wizyty.'), 'error');
            }
        });
    }

    // =========================================================
    // Conflict dialog
    // =========================================================
    function openConflictDialog(fcEvent, conflicts) {
        if (!conflictModal) return;

        var listHtml = conflicts.map(function (c) {
            return '<li><strong>' + escHtml(c.title) + '</strong> – ' + escHtml(formatDateTime(c.start)) + '</li>';
        }).join('');

        var body = conflictModal.querySelector('.ks-conflict-body');
        if (body) {
            body.innerHTML = '<p>Serwisant ma już zaplanowane wizyty w tym czasie:</p>'
                + '<ul class="ks-conflict-list">' + listHtml + '</ul>'
                + '<div class="ks-form-group">'
                + '<label for="ks-conflict-note">Notatka (wymagana przy wymuszeniu)</label>'
                + '<input id="ks-conflict-note" class="ks-input" type="text" '
                + 'placeholder="Powód nadpisania..." aria-required="false">'
                + '</div>';
        }

        conflictModal.style.display = 'flex';
        conflictModal.setAttribute('aria-hidden', 'false');
    }

    function closeConflictModal() {
        if (!conflictModal) return;
        conflictModal.style.display = 'none';
        conflictModal.setAttribute('aria-hidden', 'true');
    }

    // =========================================================
    // Bulk reschedule
    // =========================================================
    function updateBulkBar() {
        if (!bulkBar) return;
        bulkBar.style.display = selectedIds.length > 0 ? 'flex' : 'none';
        var label = bulkBar.querySelector('.ks-bulk-count');
        if (label) label.textContent = selectedIds.length + ' zaznaczone';
    }

    function bulkReschedule(deltaDays, deltaHours) {
        if (selectedIds.length === 0) return;

        var payload = {
            ids:   selectedIds.map(Number),
            delta: { days: deltaDays, hours: deltaHours }
        };

        apiFetch('POST', ksCalendarData.apiBase + '/events/bulk-reschedule', payload,
            function (data) {
                var failed = (data.results || []).filter(function (r) { return r.status !== 'ok'; });
                calendar.refetchEvents();
                selectedIds = [];
                updateBulkBar();
                if (failed.length) {
                    showToast(failed.length + ' wizyt nie mogło być przesuniętych (konflikty).', 'error');
                } else {
                    showToast('Przesunięto ' + payload.ids.length + ' wizyt.', 'success');
                }
            },
            function (err) {
                showToast('Błąd: ' + ((err && err.message) || 'Błąd przesuwania.'), 'error');
            }
        );
    }

    // =========================================================
    // ICS export (client-side, no server round-trip)
    // =========================================================
    function exportICS(ev) {
        var dtStart = ev.start ? toICSDate(ev.start) : null;
        var dtEnd   = ev.end   ? toICSDate(ev.end)   : dtStart;
        if (!dtStart) return;

        var meta = (ev && ev.meta) ? ev.meta : {};

        var lines = [
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'PRODID:-//KiedySerwis//Calendar//PL',
            'BEGIN:VEVENT',
            'UID:ks-event-' + ev.id + '@kiedyserwis',
            'DTSTAMP:' + toICSDate(new Date().toISOString()),
            'DTSTART:' + dtStart,
            'DTEND:' + dtEnd,
            'SUMMARY:' + icsEscape(ev.title),
            meta.address ? 'LOCATION:' + icsEscape(meta.address) : '',
            meta.notes   ? 'DESCRIPTION:' + icsEscape(meta.notes) : '',
            'END:VEVENT',
            'END:VCALENDAR'
        ].filter(Boolean).join('\r\n');

        var blob = new Blob([lines], { type: 'text/calendar;charset=utf-8' });
        var url  = URL.createObjectURL(blob);
        var a    = document.createElement('a');
        a.href     = url;
        a.download = 'wizyta-' + ev.id + '.ics';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    function toICSDate(iso) {
        return String(iso).replace(/[-:]/g, '').replace(/\.\d+/, '') + (String(iso).indexOf('Z') === -1 ? 'Z' : '');
    }
    function icsEscape(s) {
        return (s || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
    }

    // =========================================================
    // REST API helpers
    // =========================================================
    function apiFetch(method, url, body, onSuccess, onError) {
        var opts = {
            method:  method,
            headers: {
                'X-WP-Nonce':   ksCalendarData.nonce,
                'Content-Type': 'application/json'
            }
        };
        if (body) opts.body = JSON.stringify(body);

        fetch(url, opts)
            .then(function (res) {
                return res.json().then(function (data) {
                    return { ok: res.ok, status: res.status, data: data };
                });
            })
            .then(function (r) {
                if (r.ok) {
                    onSuccess(r.data);
                } else {
                    onError(r.data || { message: 'Błąd serwera' });
                }
            })
            .catch(function (err) {
                console.error('[KS-Cal] network error', err);
                onError({ message: 'Błąd sieci: ' + err.message });
            });
    }

    function patchEvent(id, payload, onSuccess, onError) {
        apiFetch('PATCH', ksCalendarData.apiBase + '/events/' + id, payload, onSuccess, onError);
    }

    // =========================================================
    // View switch – keep responsive on window resize
    // =========================================================
    function wireViewSwitch() {
        window.addEventListener('resize', function () {
            var wasMobile = isMobile;
            isMobile = window.innerWidth < 768;
            if (isMobile !== wasMobile && calendar) {
                calendar.changeView(isMobile ? 'listWeek' : 'timeGridWeek');
            }
        });
    }

    // =========================================================
    // Static event binding
    // =========================================================
    function bindStaticEvents() {

        // FAB → quick-create with next rounded 15-min slot
        if (fabEl) {
            fabEl.addEventListener('click', function () {
                var now     = Date.now();
                var rounded = new Date(Math.ceil(now / 900000) * 900000);
                var end     = new Date(rounded.getTime() + 3600000);
                openQuickCreate(rounded.toISOString(), end.toISOString());
            });
        }

        // Click-outside / overlay to close modals
        document.addEventListener('click', function (e) {
            if (e.target === modalEl)       closeModal();
            if (e.target === quickModal)    closeQuickModal();
            if (e.target === conflictModal) closeConflictModal();
            if (e.target.classList.contains('ks-close-btn')) {
                closeModal();
                closeQuickModal();
                closeConflictModal();
            }
            if (e.target.classList.contains('ks-sheet-close')) {
                closeBottomSheet();
            }
        });

        if (sheetOverlayEl) {
            sheetOverlayEl.addEventListener('click', closeBottomSheet);
        }

        // Quick-create form submit
        var qcForm = document.getElementById('ks-cal-quick-form');
        if (qcForm) {
            qcForm.addEventListener('submit', function (e) {
                e.preventDefault();

                var startInput  = document.getElementById('ks-qc-start');
                var endInput    = document.getElementById('ks-qc-end');
                var titleInput  = document.getElementById('ks-qc-title');
                var addrInput   = document.getElementById('ks-qc-address');
                var notesInput  = document.getElementById('ks-qc-notes');
                var deviceInput = document.getElementById('ks-qc-device-id');
                var workerSel   = document.getElementById('ks-qc-worker');

                var payload = {
                    start:   startInput  ? startInput.value  : '',
                    end:     endInput    ? endInput.value    : '',
                    title:   titleInput  ? titleInput.value  : '',
                    address: addrInput   ? addrInput.value   : '',
                    notes:   notesInput  ? notesInput.value  : ''
                };
                var deviceId = deviceInput ? parseInt(deviceInput.value, 10) : 0;
                if (deviceId) payload.device_id = deviceId;

                // Pass target worker when manager assigns the appointment.
                if (workerSel && workerSel.value) {
                    payload.target_worker_id = parseInt(workerSel.value, 10);
                }

                apiFetch('POST', ksCalendarData.apiBase + '/events/quick-create', payload,
                    function () {
                        closeQuickModal();
                        calendar.refetchEvents();
                        showToast('Wizyta dodana pomyślnie.', 'success');
                    },
                    function (err) {
                        showToast('Błąd: ' + ((err && err.message) || 'Nie udało się dodać wizyty.'), 'error');
                    }
                );
            });
        }

        // Conflict: Cancel (revert drag)
        var conflictCancel = document.getElementById('ks-conflict-cancel');
        if (conflictCancel) {
            conflictCancel.addEventListener('click', function () {
                if (pendingRevert) { pendingRevert(); pendingRevert = null; }
                pendingConflict = null;
                closeConflictModal();
            });
        }

        // Conflict: Force override
        var conflictForce = document.getElementById('ks-conflict-force');
        if (conflictForce) {
            conflictForce.addEventListener('click', function () {
                if (!pendingConflict) { closeConflictModal(); return; }
                var noteEl = document.getElementById('ks-conflict-note');
                var note   = noteEl ? noteEl.value.trim() : '';
                var fc     = pendingConflict.event;
                closeConflictModal();
                pendingConflict = null;
                handleEventChange(fc, function () {}, true, note);
            });
        }

        // Filters change → refetch
        if (filterBar) {
            filterBar.addEventListener('change', function () {
                calendar.refetchEvents();
            });
        }

        // Bulk bar actions
        var bulkNextDay = document.getElementById('ks-bulk-next-day');
        if (bulkNextDay) {
            bulkNextDay.addEventListener('click', function () { bulkReschedule(1, 0); });
        }
        var bulkPrevDay = document.getElementById('ks-bulk-prev-day');
        if (bulkPrevDay) {
            bulkPrevDay.addEventListener('click', function () { bulkReschedule(-1, 0); });
        }
        var bulkClear = document.getElementById('ks-bulk-clear');
        if (bulkClear) {
            bulkClear.addEventListener('click', function () {
                selectedIds = [];
                updateBulkBar();
            });
        }

        // Keyboard: Escape closes any open overlay
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                closeModal();
                closeBottomSheet();
                closeQuickModal();
                closeConflictModal();
            }
        });
    }

    // =========================================================
    // Toast notifications
    // =========================================================
    function showToast(msg, type) {
        var toast = document.createElement('div');
        toast.className  = 'ks-toast ks-toast-' + (type || 'info');
        toast.textContent = msg;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        document.body.appendChild(toast);
        setTimeout(function () { toast.classList.add('ks-toast-visible'); }, 10);
        setTimeout(function () {
            toast.classList.remove('ks-toast-visible');
            setTimeout(function () {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 400);
        }, 4000);
    }

    // =========================================================
    // Utility helpers
    // =========================================================
    function escHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function formatDate(date) {
        if (!date) return '';
        if (date instanceof Date) return date.toISOString().substring(0, 10);
        return String(date).substring(0, 10);
    }

    function formatTime(iso) {
        if (!iso) return '';
        var d = (iso instanceof Date) ? iso : new Date(iso);
        if (isNaN(d.getTime())) return String(iso);
        return d.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
    }

    function formatDateTime(iso) {
        if (!iso) return '';
        var d = new Date(iso);
        if (isNaN(d.getTime())) return String(iso);
        return d.toLocaleDateString('pl-PL', { weekday: 'short', day: 'numeric', month: 'short' })
            + ' ' + formatTime(d);
    }

}());
