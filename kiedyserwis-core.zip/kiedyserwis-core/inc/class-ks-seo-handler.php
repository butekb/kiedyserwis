<?php
/**
 * Class KS_SEO_Handler
 * Handles Premium SEO module logic, metadata saving, and technical SEO output.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KS_SEO_Handler {

	public function __construct() {
		// Form submission handler
		add_action( 'admin_post_ks_save_seo', array( $this, 'handle_save_seo_settings' ) );

		// Technical SEO output
		add_action( 'wp_head', array( $this, 'seo_output' ), 1 );

		// Dynamic title override
		add_filter( 'pre_get_document_title', array( $this, 'seo_title_filter' ), 10 );
	}

	/**
	 * Handle saving SEO fields from dashboard.
	 */
	public function handle_save_seo_settings() {
		if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
			wp_die( 'Brak uprawnień.' );
		}

		if ( ! isset( $_POST['ks_seo_nonce'] ) || ! wp_verify_nonce( $_POST['ks_seo_nonce'], 'ks_save_seo' ) ) {
			wp_die( 'Błąd bezpieczeństwa.' );
		}

		$user_id = get_current_user_id();

		if ( ! ks_is_premium_active( $user_id ) ) {
			wp_die( 'Ta funkcja wymaga aktywnego Pakietu Premium.' );
		}

		$seo_fields = array(
			'ks_seo_cities'     => 'sanitize_textarea_field',
			'ks_seo_services'   => 'sanitize_textarea_field',
			'ks_seo_brands'     => 'sanitize_text_field',
			'ks_seo_title'      => 'sanitize_text_field',
			'ks_seo_description'=> 'sanitize_textarea_field',
			'ks_seo_category'   => 'sanitize_text_field',
			'ks_seo_category_custom' => 'sanitize_text_field',
			'ks_opening_hours'  => 'sanitize_text_field',
		);

		foreach ( $seo_fields as $field => $sanitize_callback ) {
			if ( isset( $_POST[ $field ] ) ) {
				update_user_meta( $user_id, $field, $sanitize_callback( $_POST[ $field ] ) );
			}
		}

		// Force Cache Purge
		ks_purge_user_cache( $user_id );

		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'seo', 'seo_updated' => '1', 'updated' => time() ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	/**
	 * Output Meta Tags and Schema.org on Business Card page.
	 */
	public function seo_output() {
		$author_id = 0;

		$slug = get_query_var( 'ks_company_slug' );
		if ( $slug ) {
			$users = get_users( array(
				'meta_key'   => 'ks_company_slug',
				'meta_value' => $slug,
				'number'     => 1,
			) );
			if ( ! empty( $users ) ) {
				$author_id = $users[0]->ID;
			}
		} elseif ( is_author() ) {
			$author    = get_queried_object();
			$author_id = isset( $author->ID ) ? $author->ID : 0;
		}

		if ( ! $author_id || ! ks_is_premium_active( $author_id ) ) {
			return;
		}

		$cities      = get_user_meta( $author_id, 'ks_seo_cities', true );
		$services    = get_user_meta( $author_id, 'ks_seo_services', true );
		$seo_desc    = get_user_meta( $author_id, 'ks_seo_description', true );
		$category    = get_user_meta( $author_id, 'ks_seo_category', true );
		$category_custom = get_user_meta( $author_id, 'ks_seo_category_custom', true );
		$hours       = get_user_meta( $author_id, 'ks_opening_hours', true );

		$display_category = ( $category === 'Inna (wpisz poniżej...)' ) ? $category_custom : $category;
		$comp_name   = get_user_meta( $author_id, 'ks_company_name', true ) ?: get_the_author_meta( 'display_name', $author_id );
		$phone    = get_user_meta( $author_id, 'ks_company_phone', true );
		$logo_id  = get_user_meta( $author_id, 'ks_company_logo', true );
		$logo_url = $logo_id ? wp_get_attachment_url( $logo_id ) : '';
		$card_url = get_author_posts_url( $author_id );

		// Meta Description
		$meta_desc = $seo_desc ?: sprintf( '%s - %s. Obsługiwane miasta: %s. Zapraszamy do kontaktu!', $comp_name, $services, $cities );
		echo '<meta name="description" content="' . esc_attr( $meta_desc ) . '">' . "\n";

		// Schema.org JSON-LD
		$schema = array(
			'@context'     => 'https://schema.org',
			'@type'        => 'LocalBusiness',
			'name'         => $comp_name,
			'description'  => $services,
			'category'     => $display_category,
			'url'          => $card_url,
			'telephone'    => $phone,
			'openingHours' => $hours,
		);

		if ( $logo_url ) {
			$schema['image'] = $logo_url;
			$schema['logo']  = $logo_url;
		}

		if ( $cities ) {
			$schema['areaServed'] = array_map( 'trim', explode( ',', $cities ) );
		}

		echo '<script type="application/ld+json">' . json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . '</script>' . "\n";
	}

	/**
	 * Filter page title on Business Card page.
	 */
	public function seo_title_filter( $title ) {
		$author_id = 0;

		$slug = get_query_var( 'ks_company_slug' );
		if ( $slug ) {
			$users = get_users( array(
				'meta_key'   => 'ks_company_slug',
				'meta_value' => $slug,
				'number'     => 1,
			) );
			if ( ! empty( $users ) ) {
				$author_id = $users[0]->ID;
			}
		} elseif ( is_author() ) {
			$author    = get_queried_object();
			$author_id = isset( $author->ID ) ? $author->ID : 0;
		}

		if ( $author_id && ks_is_premium_active( $author_id ) ) {
			$seo_title = get_user_meta( $author_id, 'ks_seo_title', true );
			if ( $seo_title ) {
				return $seo_title;
			}
		}

		return $title;
	}
}
