<?php
/**
 * Class KS_Admin_Users
 * Extends WordPress Admin User Panel with Premium status management.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KS_Admin_Users {

	public function __construct() {
		if ( ! is_admin() ) {
			return;
		}

		// User table columns
		add_filter( 'manage_users_columns', array( $this, 'add_premium_columns' ) );
		add_action( 'manage_users_custom_column', array( $this, 'render_premium_columns' ), 10, 3 );
		add_filter( 'manage_users_sortable_columns', array( $this, 'make_columns_sortable' ) );
		add_action( 'pre_get_users', array( $this, 'handle_column_sorting' ) );

		// Free / Premium filter dropdown and status filtering
		add_action( 'restrict_manage_users', array( $this, 'add_plan_status_filter' ) );
		add_action( 'pre_get_users', array( $this, 'filter_users_by_plan_status' ) );

		// Summary counts above the users list
		add_action( 'admin_notices', array( $this, 'display_plan_summary' ) );

		// User profile fields
		add_action( 'show_user_profile', array( $this, 'add_premium_profile_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'add_premium_profile_fields' ) );
		add_action( 'personal_options_update', array( $this, 'save_premium_profile_fields' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_premium_profile_fields' ) );
	}

	/**
	 * Add custom columns to users table.
	 */
	public function add_premium_columns( $columns ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return $columns;
		}

		$columns['ks_company_phone'] = 'Telefon';
		$columns['ks_plan_status']   = 'Status Planu';
		$columns['ks_plan_expiry']   = 'Wygasa dnia';
		$columns['ks_referral_code'] = 'KOD';
		return $columns;
	}

	/**
	 * Render custom columns content.
	 */
	public function render_premium_columns( $output, $column_name, $user_id ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return $output;
		}

		if ( $column_name === 'ks_company_phone' ) {
			$phone = get_user_meta( $user_id, 'ks_company_phone', true );
			return $phone ? esc_html( $phone ) : '<span style="color:#9CA3AF;">—</span>';
		}

		if ( $column_name === 'ks_plan_status' ) {
			$status = get_user_meta( $user_id, 'ks_plan_status', true ) ?: 'free';
			$expiry = (int) get_user_meta( $user_id, 'ks_plan_expiry', true ) ?: 0;
			// Auto-reflect expired premium / multi / premium14
			if ( in_array( $status, array( 'premium', 'multi', 'premium14' ), true ) && $expiry > 0 && $expiry < time() ) {
				$status = 'free';
			}
			if ( $status === 'multi' ) {
				return '<strong style="color: #3B82F6;">Multi</strong>';
			} elseif ( $status === 'premium' ) {
				return '<strong style="color: #10B981;">Premium</strong>';
			} elseif ( $status === 'premium14' ) {
				return '<strong style="color: #8B5CF6;">Premium14</strong>';
			} else {
				return '<span style="color: #6B7280;">Free</span>';
			}
		}

		if ( $column_name === 'ks_plan_expiry' ) {
			$expiry = get_user_meta( $user_id, 'ks_plan_expiry', true );
			if ( ! $expiry ) {
				return '—';
			}

			$date = date( 'Y-m-d', $expiry );
			$is_expired = $expiry < time();
			$color = $is_expired ? '#EF4444' : 'inherit';

			return '<span style="color: ' . $color . ';">' . $date . '</span>';
		}

		if ( $column_name === 'ks_referral_code' ) {
			$code = get_user_meta( $user_id, 'ks_referral_code', true );
			if ( ! $code ) {
				// Generate lazily for older accounts that pre-date this feature.
				$code = ks_get_or_create_referral_code( $user_id );
			}
			return '<code style="background:#F1F5F9; padding:2px 6px; border-radius:4px; font-size:0.8125rem; letter-spacing:0.05em;">' . esc_html( $code ) . '</code>';
		}

		return $output;
	}

	/**
	 * Make columns sortable.
	 */
	public function make_columns_sortable( $columns ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return $columns;
		}

		$columns['ks_plan_status'] = 'ks_plan_status';
		return $columns;
	}

	/**
	 * Handle custom sorting logic.
	 */
	public function handle_column_sorting( $query ) {
		if ( ! is_admin() ) {
			return;
		}

		if ( $query->get( 'orderby' ) === 'ks_plan_status' ) {
			$query->set( 'meta_key', 'ks_plan_status' );
			$query->set( 'orderby', 'meta_value' );
		}
	}

	/**
	 * Add Free / Premium filter dropdown above users list.
	 */
	public function add_plan_status_filter() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$current = isset( $_GET['ks_plan_filter'] ) ? sanitize_text_field( $_GET['ks_plan_filter'] ) : '';
		?>
		<select name="ks_plan_filter" style="margin-left:4px;">
			<option value="">— Status planu —</option>
			<option value="premium" <?php selected( $current, 'premium' ); ?>>Premium</option>
			<option value="premium14" <?php selected( $current, 'premium14' ); ?>>Premium14 (próbny)</option>
			<option value="multi" <?php selected( $current, 'multi' ); ?>>Multi</option>
			<option value="free" <?php selected( $current, 'free' ); ?>>Free</option>
		</select>
		<?php
	}

	/**
	 * Filter users list by plan status.
	 */
	public function filter_users_by_plan_status( $query ) {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$filter = isset( $_GET['ks_plan_filter'] ) ? sanitize_text_field( $_GET['ks_plan_filter'] ) : '';
		if ( ! $filter ) {
			return;
		}
		$query->set( 'meta_query', array(
			array(
				'key'     => 'ks_plan_status',
				'value'   => $filter,
				'compare' => '=',
			),
		) );
	}

	/**
	 * Show Premium / Free count summary at the top of the users list page.
	 */
	public function display_plan_summary() {
		$screen = get_current_screen();
		if ( ! $screen || $screen->id !== 'users' ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		global $wpdb;
		$premium_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value = %s",
				'ks_plan_status',
				'premium'
			)
		);
		$premium14_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value = %s",
				'ks_plan_status',
				'premium14'
			)
		);
		$multi_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value = %s",
				'ks_plan_status',
				'multi'
			)
		);
		// Count serwisant-role users and subtract premium+premium14+multi users to get accurate free count
		$serwisant_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value LIKE %s",
				$wpdb->get_blog_prefix() . 'capabilities',
				'%serwisant%'
			)
		);
		$free_count = max( 0, $serwisant_count - $premium_count - $premium14_count - $multi_count );

		echo '<div class="notice notice-info" style="padding:10px 16px; font-size:14px; margin-bottom:0;">';
		echo '<strong>KiedySerwis – Statystyki serwisantów:</strong>&nbsp;&nbsp;';
		echo '<span style="color:#10B981; font-weight:700;">Premium: ' . $premium_count . '</span>';
		echo '&nbsp; | &nbsp;';
		echo '<span style="color:#8B5CF6; font-weight:700;">Premium14: ' . $premium14_count . '</span>';
		echo '&nbsp; | &nbsp;';
		echo '<span style="color:#3B82F6; font-weight:700;">Multi: ' . $multi_count . '</span>';
		echo '&nbsp; | &nbsp;';
		echo '<span style="color:#6B7280; font-weight:700;">Free: ' . $free_count . '</span>';
		echo '</div>';
	}

	/**
	 * Add fields to user profile edit screen.
	 */
	public function add_premium_profile_fields( $user ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$status = get_user_meta( $user->ID, 'ks_plan_status', true ) ?: 'free';
		$expiry = get_user_meta( $user->ID, 'ks_plan_expiry', true );
		$expiry_date = $expiry ? date( 'Y-m-d', $expiry ) : '';
		?>
		<h3>Ustawienia KiedySerwis Premium</h3>
		<table class="form-table">
			<tr>
				<th><label for="ks_plan_status">Typ planu</label></th>
				<td>
					<select name="ks_plan_status" id="ks_plan_status">
						<option value="free" <?php selected( $status, 'free' ); ?>>Free</option>
						<option value="premium" <?php selected( $status, 'premium' ); ?>>Premium</option>
						<option value="premium14" <?php selected( $status, 'premium14' ); ?>>Premium14 (14-dniowy próbny)</option>
						<option value="multi" <?php selected( $status, 'multi' ); ?>>Multi (do 10 serwisantów)</option>
					</select>
				</td>
			</tr>
			<tr>
				<th><label for="ks_plan_expiry">Data wygaśnięcia</label></th>
				<td>
					<input type="date" name="ks_plan_expiry" id="ks_plan_expiry" value="<?php echo esc_attr( $expiry_date ); ?>" class="regular-text">
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Save custom profile fields.
	 */
	public function save_premium_profile_fields( $user_id ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( isset( $_POST['ks_plan_status'] ) ) {
			$allowed_statuses = array( 'free', 'premium', 'premium14', 'multi' );
			$new_status = sanitize_text_field( $_POST['ks_plan_status'] );
			if ( in_array( $new_status, $allowed_statuses, true ) ) {
				update_user_meta( $user_id, 'ks_plan_status', $new_status );

				// Sync service_manager role with multi status.
				$target_user = get_user_by( 'id', $user_id );
				if ( $target_user ) {
					if ( $new_status === 'multi' ) {
						if ( ! in_array( 'service_manager', (array) $target_user->roles, true ) ) {
							KS_Multi_Account::register_roles();
							$target_user->add_role( 'service_manager' );
						}
					} else {
						if ( in_array( 'service_manager', (array) $target_user->roles, true ) ) {
							$target_user->remove_role( 'service_manager' );
						}
					}
				}
			}
		}

		if ( isset( $_POST['ks_plan_expiry'] ) ) {
			$expiry_date = sanitize_text_field( $_POST['ks_plan_expiry'] );
			if ( ! empty( $expiry_date ) ) {
				$expiry_ts = strtotime( $expiry_date . ' 23:59:59' );
				update_user_meta( $user_id, 'ks_plan_expiry', $expiry_ts );
			} else {
				delete_user_meta( $user_id, 'ks_plan_expiry' );
			}
		}

		// Clear cache to reflect changes immediately
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
		}
	}
}
