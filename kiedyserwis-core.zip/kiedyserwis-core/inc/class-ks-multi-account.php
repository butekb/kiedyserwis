<?php
/**
 * Class KS_Multi_Account
 *
 * Obsługuje system sub-kont (Multi-Account) dla platformy KiedySerwis.pl.
 *
 * Architektura:
 *   - Rola service_manager  – właściciel konta firmowego (do 10 pracowników).
 *   - Rola service_worker   – pracownik podpięty pod Managera.
 *   - Metadane:
 *       _parent_manager_id  (na koncie pracownika) – ID Managera
 *       ks_plan_status      (na koncie Managera)   – 'free'|'premium'
 *       ks_plan_expiry      (na koncie Managera)   – timestamp wygaśnięcia
 *
 * Shortcodes:
 *   [ks_manager_dashboard] – Panel Managera (lista, dodawanie, usuwanie pracowników)
 *
 * Filtry:
 *   pre_get_posts – izolacja danych (Manager i pracownik widzą wyłącznie
 *                   własne urządzenia i wpisy; konta są od siebie odizolowane)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KS_Multi_Account {

	/** Maksymalna liczba pracowników podpiętych do jednego Managera. */
	const MAX_WORKERS = 10;

	public function __construct() {
		// Shortcode dla panelu Managera.
		add_shortcode( 'ks_manager_dashboard', array( $this, 'render_manager_dashboard' ) );

		// Blokada logowania pracownika przy wygasłej subskrypcji Managera.
		add_action( 'wp_login', array( $this, 'check_worker_subscription_on_login' ), 10, 2 );

		// Izolacja danych: ograniczenie WP_Query na froncie.
		add_action( 'pre_get_posts', array( $this, 'scope_device_queries' ) );

		// Obsługa formularzy panelu Managera (POST).
		add_action( 'init', array( $this, 'handle_form_submissions' ) );
	}

	/* =====================================================================
	   1. ROLE – rejestracja (wywoływana z hooka aktywacji)
	   ===================================================================== */

	/**
	 * Rejestruje role service_manager i service_worker.
	 * Bezpieczne do wielokrotnego wywołania (idempotent).
	 */
	public static function register_roles() {
		if ( ! get_role( 'service_manager' ) ) {
			add_role(
				'service_manager',
				'Manager Serwisu',
				array(
					'read'         => true,
					'edit_posts'   => true,
					'publish_posts' => true,
					'upload_files' => true,
				)
			);
		}

		if ( ! get_role( 'service_worker' ) ) {
			add_role(
				'service_worker',
				'Pracownik Serwisu',
				array(
					'read'         => true,
					'edit_posts'   => true,
					'publish_posts' => true,
					'upload_files' => true,
				)
			);
		}
	}

	/* =====================================================================
	   2. BLOKADA LOGOWANIA – weryfikacja subskrypcji Managera
	   ===================================================================== */

	/**
	 * Po zalogowaniu pracownika sprawdza, czy subskrypcja jego Managera jest aktywna.
	 * Jeśli nie – wylogowuje pracownika i przekierowuje z komunikatem.
	 *
	 * @param string  $user_login Nazwa użytkownika.
	 * @param WP_User $user       Obiekt zalogowanego użytkownika.
	 */
	public function check_worker_subscription_on_login( $user_login, $user ) {
		if ( ! in_array( 'service_worker', (array) $user->roles, true ) ) {
			return;
		}

		$manager_id = (int) get_user_meta( $user->ID, '_parent_manager_id', true );
		if ( ! $manager_id ) {
			// Pracownik bez przypisanego Managera – zezwól na logowanie.
			return;
		}

		$sub_active = $this->is_manager_subscription_active( $manager_id );
		if ( $sub_active ) {
			return;
		}

		// Subskrypcja wygasła – wyloguj pracownika.
		wp_destroy_current_session();
		wp_clear_auth_cookie();

		$login_url = add_query_arg(
			array(
				'ks_sub_expired' => '1',
				'manager_id'     => $manager_id,
			),
			wp_login_url()
		);

		wp_safe_redirect( $login_url );
		exit;
	}

	/**
	 * Sprawdza, czy subskrypcja Managera jest aktywna.
	 * Używa istniejących meta kluczy ks_plan_status / ks_plan_expiry.
	 *
	 * @param int $manager_id ID użytkownika z rolą service_manager.
	 * @return bool
	 */
	public function is_manager_subscription_active( $manager_id ) {
		$status = get_user_meta( $manager_id, 'ks_plan_status', true );
		$expiry = (int) get_user_meta( $manager_id, 'ks_plan_expiry', true );

		if ( in_array( $status, array( 'premium', 'multi' ), true ) && $expiry > time() ) {
			return true;
		}

		// Fallback: sprawdź dedykowany klucz _sub_active ustawiany zewnętrznie.
		$sub_active = get_user_meta( $manager_id, '_sub_active', true );
		return ( $sub_active === '1' || $sub_active === 'yes' || $sub_active === true );
	}

	/* =====================================================================
	   3. IZOLACJA DANYCH – pre_get_posts
	   ===================================================================== */

	/**
	 * Ogranicza zapytania WP_Query do urządzeń (ks_urzadzenie):
	 *   - service_manager widzi wyłącznie urządzenia przypisane do własnego user_id.
	 *   - service_worker widzi wyłącznie urządzenia przypisane do własnego user_id.
	 *
	 * Konto multi (service_manager) służy do zarządzania uprawnieniami pracowników.
	 * Każde konto – zarówno manager, jak i pracownik – prowadzi własną bazę urządzeń.
	 *
	 * @param WP_Query $query Aktualny obiekt zapytania.
	 */
	public function scope_device_queries( $query ) {
		// Działa tylko na froncie i dla zapytań ks_urzadzenie.
		if ( is_admin() ) {
			return;
		}

		if ( ! $query->is_main_query() && $query->get( 'post_type' ) !== 'ks_urzadzenie' ) {
			return;
		}

		if ( $query->get( 'post_type' ) !== 'ks_urzadzenie' ) {
			return;
		}

		$user = wp_get_current_user();

		// Block unauthenticated access to device records entirely.
		// Using post__in with an impossible value guarantees an empty result set
		// regardless of other query parameters.
		if ( ! $user || ! $user->ID ) {
			$query->set( 'post__in', array( 0 ) );
			return;
		}

		// All three technician/account roles see only their own devices.
		// 'serwisant'       – standard technician (primary role)
		// 'service_worker'  – employee linked to a service_manager account
		// 'service_manager' – company account owner; sees own + all workers' devices.

		if ( in_array( 'service_manager', (array) $user->roles, true ) ) {
			// Manager widzi urządzenia własne i wszystkich swoich pracowników.
			$worker_ids = $this->get_manager_worker_ids( $user->ID );
			$all_ids    = array_merge( array( (int) $user->ID ), $worker_ids );
			$query->set( 'author__in', $all_ids );
			$query->set( 'author', 0 ); // Zeruj filtr po jednym autorze.
			return;
		}

		$device_roles = array( 'serwisant', 'service_worker' );
		if ( ! empty( array_intersect( $device_roles, (array) $user->roles ) ) ) {
			$query->set( 'author', $user->ID );
			$query->set( 'author__in', array() ); // Wyczyść filtr tablicowy (musi być array, nie string).
			return;
		}
	}

	/* =====================================================================
	   4. HELPERY – pracownicy Managera
	   ===================================================================== */

	/**
	 * Zwraca tablicę ID pracowników (service_worker) podpiętych do danego Managera.
	 *
	 * @param int $manager_id ID Managera.
	 * @return int[] Tablica ID użytkowników.
	 */
	public function get_manager_worker_ids( $manager_id ) {
		return self::get_worker_ids_for_manager( $manager_id );
	}

	/**
	 * Statyczna wersja get_manager_worker_ids – bezpieczna do wywołania
	 * bez tworzenia nowej instancji klasy (np. z funkcji globalnych).
	 *
	 * @param int $manager_id ID Managera.
	 * @return int[] Tablica ID użytkowników.
	 */
	public static function get_worker_ids_for_manager( $manager_id ) {
		$users = get_users(
			array(
				'role'       => 'service_worker',
				'meta_key'   => '_parent_manager_id',
				'meta_value' => $manager_id,
				'fields'     => 'ID',
				'number'     => self::MAX_WORKERS + 1, // +1 do sprawdzenia limitu.
			)
		);
		return array_map( 'intval', $users );
	}

	/**
	 * Zwraca liczbę pracowników podpiętych do Managera.
	 *
	 * @param int $manager_id
	 * @return int
	 */
	public function count_workers( $manager_id ) {
		return count( $this->get_manager_worker_ids( $manager_id ) );
	}

	/* =====================================================================
	   5. OBSŁUGA FORMULARZY (POST)
	   ===================================================================== */

	/**
	 * Przetwarza:
	 *   - ks_add_worker   – dodawanie nowego pracownika
	 *   - ks_remove_worker – odpinanie pracownika
	 */
	public function handle_form_submissions() {
		if ( ! isset( $_POST['ks_multi_action'] ) ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			return;
		}

		$manager = wp_get_current_user();
		if ( ! in_array( 'service_manager', (array) $manager->roles, true ) ) {
			return;
		}

		$action = sanitize_key( $_POST['ks_multi_action'] );

		if ( $action === 'ks_add_worker' ) {
			$this->process_add_worker( $manager );
		} elseif ( $action === 'ks_remove_worker' ) {
			$this->process_remove_worker( $manager );
		}
	}

	/**
	 * Dodaje nowego pracownika do konta Managera.
	 *
	 * @param WP_User $manager Zalogowany Manager.
	 */
	private function process_add_worker( $manager ) {
		// Weryfikacja nonce.
		if ( ! isset( $_POST['ks_multi_nonce'] ) ||
			 ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ks_multi_nonce'] ) ), 'ks_add_worker_' . $manager->ID ) ) {
			$this->redirect_back( 'Błąd bezpieczeństwa. Odśwież stronę i spróbuj ponownie.', 'error' );
			return;
		}

		// Sprawdź limit.
		if ( $this->count_workers( $manager->ID ) >= self::MAX_WORKERS ) {
			$this->redirect_back( 'Osiągnięto limit ' . self::MAX_WORKERS . ' kont pracowników.', 'error' );
			return;
		}

		$email            = sanitize_email( $_POST['worker_email'] ?? '' );
		$password         = $_POST['worker_password'] ?? '';
		$password_confirm = $_POST['worker_password_confirm'] ?? '';
		$name             = sanitize_text_field( $_POST['worker_name'] ?? '' );

		if ( empty( $name ) ) {
			$this->redirect_back( 'Imię i nazwisko pracownika jest wymagane.', 'error' );
			return;
		}

		if ( ! is_email( $email ) ) {
			$this->redirect_back( 'Podaj prawidłowy adres e-mail pracownika.', 'error' );
			return;
		}

		if ( strlen( $password ) < 8 ) {
			$this->redirect_back( 'Hasło musi mieć co najmniej 8 znaków.', 'error' );
			return;
		}

		if ( ! hash_equals( $password, $password_confirm ) ) {
			$this->redirect_back( 'Hasła nie są identyczne. Spróbuj ponownie.', 'error' );
			return;
		}

		if ( email_exists( $email ) ) {
			$this->redirect_back( 'Konto o podanym adresie e-mail już istnieje.', 'error' );
			return;
		}

		// Utwórz konto pracownika.
		$username = sanitize_user( strtolower( str_replace( '@', '_', $email ) ) );
		$username = $this->unique_username( $username );

		$worker_id = wp_create_user( $username, $password, $email );
		if ( is_wp_error( $worker_id ) ) {
			$this->redirect_back( 'Błąd podczas tworzenia konta: ' . $worker_id->get_error_message(), 'error' );
			return;
		}

		// Ustaw rolę i powiąż z Managerem.
		$worker = new WP_User( $worker_id );
		$worker->set_role( 'service_worker' );

		if ( ! empty( $name ) ) {
			$parts = explode( ' ', $name, 2 );
			wp_update_user(
				array(
					'ID'         => $worker_id,
					'first_name' => $parts[0],
					'last_name'  => $parts[1] ?? '',
					'display_name' => $name,
				)
			);
		}

		update_user_meta( $worker_id, '_parent_manager_id', $manager->ID );
		update_user_meta( $worker_id, 'ks_account_status', 'active' );

		// Wyczyść cache, żeby zmiany były widoczne natychmiast.
		if ( function_exists( 'ks_purge_user_cache' ) ) {
			ks_purge_user_cache( $manager->ID );
		}

		$this->redirect_back( 'Pracownik ' . esc_html( $email ) . ' został dodany.', 'success' );
	}

	/**
	 * Odłącza pracownika od konta Managera.
	 *
	 * @param WP_User $manager Zalogowany Manager.
	 */
	private function process_remove_worker( $manager ) {
		if ( ! isset( $_POST['ks_multi_nonce'] ) ||
			 ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ks_multi_nonce'] ) ), 'ks_remove_worker_' . $manager->ID ) ) {
			$this->redirect_back( 'Błąd bezpieczeństwa.', 'error' );
			return;
		}

		$worker_id = (int) ( $_POST['worker_id'] ?? 0 );
		if ( ! $worker_id ) {
			$this->redirect_back( 'Nieprawidłowy ID pracownika.', 'error' );
			return;
		}

		// Upewnij się, że pracownik należy do tego Managera.
		$parent = (int) get_user_meta( $worker_id, '_parent_manager_id', true );
		if ( $parent !== $manager->ID ) {
			$this->redirect_back( 'Brak uprawnień do tego konta.', 'error' );
			return;
		}

		// Usuń powiązanie (nie kasuj konta – Manager może chcieć powtórnie podpiąć).
		delete_user_meta( $worker_id, '_parent_manager_id' );

		// Wyczyść cache, żeby zmiany były widoczne natychmiast.
		if ( function_exists( 'ks_purge_user_cache' ) ) {
			ks_purge_user_cache( $manager->ID );
		}

		$this->redirect_back( 'Pracownik został odpięty od Twojego konta.', 'success' );
	}

	/**
	 * Generuje unikalną nazwę użytkownika.
	 *
	 * @param string $base Baza nazwy.
	 * @return string
	 */
	private function unique_username( $base ) {
		$username = $base;
		$i        = 1;
		while ( username_exists( $username ) ) {
			$username = $base . $i;
			$i++;
		}
		return $username;
	}

	/**
	 * Przekierowuje na panel managera (zakładka multi) z komunikatem w query stringu.
	 *
	 * @param string $message Treść komunikatu.
	 * @param string $type    'success' lub 'error'.
	 */
	private function redirect_back( $message, $type = 'success' ) {
		$url = add_query_arg(
			array(
				'ks_tab'  => 'multi',
				'ks_msg'  => $message,
				'ks_type' => $type,
				'updated' => time(),
			),
			home_url( '/panel-serwisanta/' )
		);
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Zwraca liczbę urządzeń (bez niestandardowych wizyt) dodanych przez użytkownika.
	 *
	 * Używamy bezpośredniego zapytania $wpdb zamiast WP_Query, aby uniknąć uruchamiania
	 * hooka pre_get_posts (scope_device_queries), który nadpisywałby filtr autora
	 * i powodował podwójne zliczanie dla roli service_manager.
	 *
	 * @param int $user_id
	 * @return int
	 */
	private function count_worker_devices( $user_id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT p.ID)
				 FROM {$wpdb->posts} p
				 LEFT JOIN {$wpdb->postmeta} pm
				       ON ( pm.post_id = p.ID AND pm.meta_key = 'ks_is_custom_app' )
				 WHERE p.post_type   = 'ks_urzadzenie'
				   AND p.post_status = 'publish'
				   AND p.post_author = %d
				   AND pm.post_id    IS NULL",
				(int) $user_id
			)
		);
	}

	/**
	 * Zwraca liczbę wpisów w kalendarzu (ks_urzadzenie z niepustą datą wizyty) dla użytkownika.
	 *
	 * Używamy bezpośredniego zapytania $wpdb zamiast WP_Query z tego samego powodu
	 * co count_worker_devices – unikamy efektu ubocznego filtra pre_get_posts.
	 *
	 * @param int $user_id
	 * @return int
	 */
	private function count_worker_calendar_entries( $user_id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT p.ID)
				 FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm
				        ON ( pm.post_id = p.ID AND pm.meta_key = 'ks_app_date' )
				 WHERE p.post_type   = 'ks_urzadzenie'
				   AND p.post_status = 'publish'
				   AND p.post_author = %d
				   AND pm.meta_value != ''",
				(int) $user_id
			)
		);
	}

	/* =====================================================================
	   6. SHORTCODE – Panel Managera [ks_manager_dashboard]
	   ===================================================================== */

	/**
	 * Renderuje panel zarządzania pracownikami dla Managera.
	 *
	 * @return string HTML panelu.
	 */
	public function render_manager_dashboard() {
		if ( ! is_user_logged_in() ) {
			return '<p>Musisz być zalogowany, aby zobaczyć ten panel.</p>';
		}

		$manager = wp_get_current_user();
		if ( ! in_array( 'service_manager', (array) $manager->roles, true ) ) {
			return '<p>Ten panel jest dostępny wyłącznie dla kont Managera.</p>';
		}

		$workers      = $this->get_manager_worker_ids( $manager->ID );
		$worker_count = count( $workers );
		$can_add      = $worker_count < self::MAX_WORKERS;

		// Komunikaty (po przekierowaniu).
		$msg      = isset( $_GET['ks_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['ks_msg'] ) ) : '';
		$msg_type = isset( $_GET['ks_type'] ) ? sanitize_key( $_GET['ks_type'] ) : 'success';

		// Statystyki Managera
		$mgr_devices  = $this->count_worker_devices( $manager->ID );
		$mgr_calendar = $this->count_worker_calendar_entries( $manager->ID );

		// Dane i statystyki pracowników
		$worker_data = array();
		$total_devices  = $mgr_devices;
		$total_calendar = $mgr_calendar;
		foreach ( $workers as $wid ) {
			$wu = get_userdata( $wid );
			if ( ! $wu ) {
				continue;
			}
			$w_dev = $this->count_worker_devices( $wid );
			$w_cal = $this->count_worker_calendar_entries( $wid );
			$total_devices  += $w_dev;
			$total_calendar += $w_cal;
			$worker_data[] = array(
				'id'       => $wid,
				'name'     => $wu->display_name ?: $wu->user_email,
				'email'    => $wu->user_email,
				'devices'  => $w_dev,
				'calendar' => $w_cal,
			);
		}

		ob_start();
		?>
		<style>
		/* ── Manager Dashboard ── */
		.ks-md {
			font-family: 'Inter', Arial, sans-serif;
			max-width: 860px;
			margin: 0 auto;
			padding: 8px 0 40px;
			color: #1e293b;
		}
		.ks-md__header {
			background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%);
			color: #fff;
			border-radius: 16px;
			padding: 26px 32px;
			margin-bottom: 24px;
			display: flex;
			align-items: center;
			gap: 20px;
		}
		.ks-md__header-icon {
			width: 52px; height: 52px;
			background: rgba(255,255,255,.18);
			border-radius: 14px;
			display: flex; align-items: center; justify-content: center;
			flex-shrink: 0;
			font-size: 26px;
		}
		.ks-md__header h2 { margin: 0 0 3px; font-size: 20px; font-weight: 800; }
		.ks-md__header p  { margin: 0; font-size: 13px; opacity: .85; }
		.ks-md__notice {
			padding: 12px 18px;
			border-radius: 10px;
			margin-bottom: 20px;
			font-size: 14px;
			font-weight: 500;
		}
		.ks-md__notice--success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
		.ks-md__notice--error   { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
		/* Statystyki ogólne */
		.ks-md__stats-grid {
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			gap: 14px;
			margin-bottom: 28px;
		}
		.ks-md__stat-card {
			background: #fff;
			border: 1px solid #e2e8f0;
			border-radius: 14px;
			padding: 18px 20px;
			text-align: center;
		}
		.ks-md__stat-card .stat-num {
			font-size: 32px;
			font-weight: 800;
			color: #4F46E5;
			line-height: 1;
			margin-bottom: 4px;
		}
		.ks-md__stat-card .stat-label {
			font-size: 12px;
			color: #64748b;
			font-weight: 600;
			text-transform: uppercase;
			letter-spacing: .05em;
		}
		.ks-md__section-title {
			font-size: 13px;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: .07em;
			color: #64748b;
			margin: 0 0 14px;
		}
		/* Tabela pracowników */
		.ks-md__table {
			width: 100%;
			border-collapse: collapse;
			background: #fff;
			border-radius: 12px;
			overflow: hidden;
			border: 1px solid #e2e8f0;
			margin-bottom: 28px;
		}
		.ks-md__table th {
			background: #f8fafc;
			font-size: 12px;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: .05em;
			color: #64748b;
			padding: 12px 16px;
			text-align: left;
			border-bottom: 1px solid #e2e8f0;
		}
		.ks-md__table td {
			padding: 13px 16px;
			font-size: 14px;
			border-bottom: 1px solid #f1f5f9;
			vertical-align: middle;
		}
		.ks-md__table tr:last-child td { border-bottom: none; }
		.ks-md__table tr:hover td { background: #fafbff; }
		.ks-md__empty {
			text-align: center;
			color: #94a3b8;
			padding: 28px 0;
			font-size: 14px;
		}
		.ks-md__badge {
			display: inline-flex;
			align-items: center;
			gap: 5px;
			background: #EEF2FF;
			color: #4338CA;
			border-radius: 20px;
			padding: 3px 12px;
			font-size: 13px;
			font-weight: 700;
		}
		.ks-md__badge.green { background: #DCFCE7; color: #166534; }
		/* Formularz dodawania */
		.ks-md__form {
			background: #fff;
			border: 1px solid #e2e8f0;
			border-radius: 14px;
			padding: 26px 30px;
			margin-bottom: 20px;
		}
		.ks-md__form-row {
			display: grid;
			grid-template-columns: 1fr 1fr;
			gap: 14px;
			margin-bottom: 14px;
		}
		.ks-md__form label {
			display: block;
			font-size: 13px;
			font-weight: 600;
			color: #374151;
			margin-bottom: 5px;
		}
		.ks-md__form input[type="text"],
		.ks-md__form input[type="email"],
		.ks-md__form input[type="password"] {
			width: 100%;
			padding: 10px 13px;
			border: 1.5px solid #d1d5db;
			border-radius: 9px;
			font-size: 14px;
			box-sizing: border-box;
			color: #1e293b;
			outline: none;
			transition: border-color .15s;
		}
		.ks-md__form input:focus { border-color: #4F46E5; box-shadow: 0 0 0 3px rgba(79,70,229,.1); }
		.ks-md__btn {
			display: inline-flex;
			align-items: center;
			gap: 7px;
			padding: 11px 22px;
			border-radius: 9px;
			font-size: 14px;
			font-weight: 700;
			border: none;
			cursor: pointer;
			text-decoration: none;
			transition: filter .15s;
		}
		.ks-md__btn:hover { filter: brightness(1.08); }
		.ks-md__btn--primary { background: #4F46E5; color: #fff; }
		.ks-md__btn--danger  { background: #fff; border: 1px solid #fca5a5; color: #dc2626; font-size: 13px; padding: 7px 14px; }
		.ks-md__limit-bar {
			display: flex;
			align-items: center;
			gap: 10px;
			background: #f8fafc;
			border: 1px solid #e2e8f0;
			border-radius: 10px;
			padding: 10px 16px;
			margin-bottom: 20px;
			font-size: 13px;
			color: #64748b;
		}
		.ks-md__limit-bar strong { color: #1e293b; }
		.ks-md__limit-pill {
			background: #e0e7ff;
			color: #4F46E5;
			font-weight: 700;
			font-size: 12px;
			padding: 2px 10px;
			border-radius: 20px;
		}
		.ks-md__locked {
			background: #fff7ed;
			border: 1px solid #fed7aa;
			border-radius: 10px;
			padding: 14px 18px;
			font-size: 14px;
			color: #9a3412;
		}
		@media (max-width: 600px) {
			.ks-md__form-row { grid-template-columns: 1fr; }
			.ks-md__table td, .ks-md__table th { padding: 10px 12px; }
			.ks-md__stats-grid { grid-template-columns: 1fr; }
			.ks-md__header { flex-direction: column; gap: 12px; text-align: center; }
		}
		</style>

		<div class="ks-md">

			<!-- Nagłówek -->
			<div class="ks-md__header">
				<div class="ks-md__header-icon">👥</div>
				<div>
					<h2>Panel Managera — Zarządzanie Zespołem</h2>
					<p>Zalogowany jako: <?php echo esc_html( $manager->display_name ?: $manager->user_email ); ?></p>
				</div>
			</div>

			<?php if ( $msg ) : ?>
			<div class="ks-md__notice ks-md__notice--<?php echo esc_attr( $msg_type ); ?>">
				<?php echo esc_html( $msg ); ?>
			</div>
			<?php endif; ?>

			<!-- Statystyki ogólne -->
			<p class="ks-md__section-title">📊 Statystyki Zespołu</p>
			<div class="ks-md__stats-grid">
				<div class="ks-md__stat-card">
					<div class="stat-num"><?php echo esc_html( $worker_count ); ?>/<?php echo esc_html( self::MAX_WORKERS ); ?></div>
					<div class="stat-label">Pracownicy</div>
				</div>
				<div class="ks-md__stat-card">
					<div class="stat-num"><?php echo esc_html( $total_devices ); ?></div>
					<div class="stat-label">Łącznie urządzeń</div>
				</div>
				<div class="ks-md__stat-card">
					<div class="stat-num"><?php echo esc_html( $total_calendar ); ?></div>
					<div class="stat-label">Wpisów w kalendarzu</div>
				</div>
			</div>

			<!-- Twój zespół - lista pracowników ze statystykami -->
			<p class="ks-md__section-title">👷 Twój Zespół</p>
			<div style="overflow-x:auto;">
			<table class="ks-md__table">
				<thead>
					<tr>
						<th>Pracownik</th>
						<th>E-mail</th>
						<th>Urządzenia</th>
						<th>Wpisy w kalendarzu</th>
						<th>Akcja</th>
					</tr>
				</thead>
				<tbody>
				<!-- Wiersz Managera zawsze na górze -->
				<tr style="background:#f0f4ff;">
					<td><strong>👑 Ja – Manager</strong></td>
					<td style="color:#64748b;"><?php echo esc_html( $manager->user_email ); ?></td>
					<td><span class="ks-md__badge"><?php echo esc_html( $mgr_devices ); ?></span></td>
					<td><span class="ks-md__badge green"><?php echo esc_html( $mgr_calendar ); ?></span></td>
					<td>—</td>
				</tr>
				<?php if ( empty( $worker_data ) ) : ?>
					<tr>
						<td colspan="5" class="ks-md__empty">Brak pracowników. Dodaj pierwszego poniżej.</td>
					</tr>
				<?php else : ?>
					<?php foreach ( $worker_data as $wd ) : ?>
					<tr>
						<td>
							<strong><?php echo esc_html( $wd['name'] ); ?></strong>
						</td>
						<td style="color:#64748b;"><?php echo esc_html( $wd['email'] ); ?></td>
						<td>
							<span class="ks-md__badge"><?php echo esc_html( $wd['devices'] ); ?></span>
						</td>
						<td>
							<span class="ks-md__badge green"><?php echo esc_html( $wd['calendar'] ); ?></span>
						</td>
						<td>
							<form method="post" onsubmit="return confirm('Odpiąć pracownika <?php echo esc_js( $wd['name'] ); ?>?');">
								<input type="hidden" name="ks_multi_action" value="ks_remove_worker">
								<input type="hidden" name="worker_id" value="<?php echo esc_attr( $wd['id'] ); ?>">
								<?php wp_nonce_field( 'ks_remove_worker_' . $manager->ID, 'ks_multi_nonce' ); ?>
								<button type="submit" class="ks-md__btn ks-md__btn--danger">Odepnij</button>
							</form>
						</td>
					</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>
			</div>

			<!-- Formularz dodawania pracownika -->
			<p class="ks-md__section-title">➕ Dodaj Pracownika</p>

			<?php if ( $can_add ) : ?>
			<div class="ks-md__form">
				<p style="font-size:13px; color:#64748b; margin:0 0 18px;">Pozostałe miejsca: <strong><?php echo esc_html( self::MAX_WORKERS - $worker_count ); ?></strong></p>
				<form method="post">
					<input type="hidden" name="ks_multi_action" value="ks_add_worker">
					<?php wp_nonce_field( 'ks_add_worker_' . $manager->ID, 'ks_multi_nonce' ); ?>

					<div class="ks-md__form-row">
						<div>
							<label for="ks_worker_name">Imię i nazwisko <span style="color:#dc2626">*</span></label>
							<input type="text" id="ks_worker_name" name="worker_name" required placeholder="Jan Kowalski">
						</div>
						<div>
							<label for="ks_worker_email">Adres e-mail <span style="color:#dc2626">*</span></label>
							<input type="email" id="ks_worker_email" name="worker_email" required placeholder="jan@firma.pl">
						</div>
					</div>
					<div class="ks-md__form-row">
						<div>
							<label for="ks_worker_password">Hasło (min. 8 znaków) <span style="color:#dc2626">*</span></label>
							<input type="password" id="ks_worker_password" name="worker_password" required minlength="8" placeholder="••••••••">
						</div>
						<div>
							<label for="ks_worker_password_confirm">Powtórz hasło <span style="color:#dc2626">*</span></label>
							<input type="password" id="ks_worker_password_confirm" name="worker_password_confirm" required minlength="8" placeholder="••••••••">
						</div>
					</div>

					<button type="submit" class="ks-md__btn ks-md__btn--primary">
						<span>+</span> Dodaj pracownika
					</button>
				</form>
			</div>
			<?php else : ?>
			<div class="ks-md__locked">
				🔒 Osiągnięto limit <?php echo esc_html( self::MAX_WORKERS ); ?> kont pracowników.
				Aby dodać kolejnych pracowników, skontaktuj się z pomocą techniczną.
			</div>
			<?php endif; ?>

		</div><!-- /.ks-md -->
		<?php
		return ob_get_clean();
	}
}
