<?php
/**
 * KiedySerwis – Enhanced Calendar Module (v1.0.0)
 *
 * Loaded by kiedyserwis-core.php via require_once.
 * Provides the FullCalendar-based UI with REST routes under /wp-json/ks/v1/.
 *
 * @package KiedySerwis
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Bump this string whenever JS/CSS assets change to bust browser cache. */
define( 'KS_CAL_VERSION', '1.1.4' );

/** Absolute path to this file – used to build asset URLs. */
define( 'KS_CAL_FILE', __FILE__ );

// ============================================================
// ASSET LOADING
// ============================================================

add_action( 'wp_enqueue_scripts', 'ks_cal_enqueue_assets' );

/**
 * Enqueue FullCalendar + ks-calendar.js + ks-calendar.css for logged-in
 * users who can edit posts.
 */
function ks_cal_enqueue_assets() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		return;
	}

	$plugin_url = plugin_dir_url( dirname( KS_CAL_FILE ) );

	// FullCalendar v6 global bundle – includes interaction, timegrid, daygrid, list.
	wp_enqueue_script(
		'fullcalendar',
		'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js',
		array(),
		'6.1.15',
		true
	);

	wp_enqueue_script(
		'ks-calendar',
		$plugin_url . 'assets/js/ks-calendar.js',
		array( 'fullcalendar' ),
		KS_CAL_VERSION,
		true
	);

	$current_user_for_cal = wp_get_current_user();
	$is_service_manager   = in_array( 'service_manager', (array) $current_user_for_cal->roles, true );

	// Build worker list (id + name) so the JS quick-create form can offer a picker.
	$manager_workers = array();
	if ( $is_service_manager ) {
		$worker_ids = KS_Multi_Account::get_worker_ids_for_manager( $current_user_for_cal->ID );
		foreach ( $worker_ids as $wid ) {
			$wu = get_userdata( $wid );
			if ( $wu ) {
				$manager_workers[] = array(
					'id'   => $wid,
					'name' => $wu->display_name ?: $wu->user_email,
				);
			}
		}
	}

	wp_localize_script(
		'ks-calendar',
		'ksCalendarData',
		array(
			'apiBase'     => esc_url_raw( rest_url( 'ks/v1' ) ),
			'nonce'       => wp_create_nonce( 'wp_rest' ),
			'userId'      => get_current_user_id(),
			'locale'      => get_locale(),
			'initialView' => wp_is_mobile() ? 'listWeek' : 'timeGridWeek',
			'isManager'   => $is_service_manager,
			'workers'     => $manager_workers,
		)
	);

	wp_enqueue_style(
		'ks-calendar',
		$plugin_url . 'assets/css/ks-calendar.css',
		array(),
		KS_CAL_VERSION
	);
}

// ============================================================
// REST ROUTES – always registered
// ============================================================

add_action( 'rest_api_init', 'ks_cal_register_routes' );

// Prevent LiteSpeed (and any other opcode/proxy cache) from caching our REST responses.
add_filter( 'rest_pre_dispatch', 'ks_cal_rest_set_nocache', 10, 3 );

/**
 * Tell LiteSpeed Cache not to cache /ks/v1/ REST requests.
 *
 * @param mixed            $result  Short-circuit value (null = normal flow).
 * @param WP_REST_Server   $server
 * @param WP_REST_Request  $request
 * @return mixed
 */
function ks_cal_rest_set_nocache( $result, $server, $request ) {
	if ( 0 === strpos( $request->get_route(), '/ks/v1/' ) ) {
		// WordPress built-in: sets Pragma, Expires, Cache-Control headers.
		nocache_headers();
		// LiteSpeed Cache plugin hook – marks this request as non-cacheable.
		do_action( 'litespeed_control_set_nocache', 'ks-calendar REST API' );
	}
	return $result;
}

add_filter( 'rest_post_dispatch', 'ks_cal_rest_add_nocache_headers', 10, 3 );

/**
 * Append explicit Cache-Control / LiteSpeed no-cache headers to calendar responses.
 *
 * @param WP_REST_Response $response
 * @param WP_REST_Server   $server
 * @param WP_REST_Request  $request
 * @return WP_REST_Response
 */
function ks_cal_rest_add_nocache_headers( $response, $server, $request ) {
	if ( 0 === strpos( $request->get_route(), '/ks/v1/' ) ) {
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
		$response->header( 'Pragma', 'no-cache' );
		$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
	}
	return $response;
}

/**
 * Invalidate LiteSpeed page cache for the serwisant dashboard whenever a
 * calendar event is created, updated, or deleted.
 *
 * @param int $post_id  Post ID of the event (0 = skip post-level purge).
 */
function ks_cal_purge_litespeed( $post_id = 0 ) {
	if ( $post_id > 0 ) {
		// Purge cached variants of this specific post.
		do_action( 'litespeed_purge_post', $post_id );
	}
	// Also purge the dashboard page so the legacy view is fresh too.
	ks_purge_user_cache( get_current_user_id() );
}

/**
 * Also invalidate our REST transients whenever the legacy save handlers fire.
 * This ensures view-switches see the newly added appointment immediately.
 */
add_action( 'admin_post_ks_save_appointment',  'ks_cal_invalidate_on_legacy_save', 1 );
add_action( 'admin_post_ks_save_custom_app',   'ks_cal_invalidate_on_legacy_save', 1 );
add_action( 'admin_post_ks_delete_entry',      'ks_cal_invalidate_on_legacy_save', 1 );
add_action( 'admin_post_ks_delete_device',     'ks_cal_invalidate_on_legacy_save', 1 );
add_action( 'admin_post_ks_complete_app',      'ks_cal_invalidate_on_legacy_save', 1 );
add_action( 'admin_post_ks_log_service',       'ks_cal_invalidate_on_legacy_save', 1 );

function ks_cal_invalidate_on_legacy_save() {
	ks_cal_invalidate_cache( get_current_user_id() );
}

/**
 * Register all new calendar REST routes under /wp-json/ks/v1/.
 */
function ks_cal_register_routes() {
	// GET /wp-json/ks/v1/events?start=YYYY-MM-DD&end=YYYY-MM-DD[&technician=id&status=...]
	register_rest_route(
		'ks/v1',
		'/events',
		array(
			'methods'             => 'GET',
			'callback'            => 'ks_cal_rest_get_events',
			'permission_callback' => 'ks_cal_rest_auth',
			'args'                => array(
				'start' => array(
					'required'          => true,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				),
				'end'   => array(
					'required'          => true,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				),
				'status' => array(
					'required'          => false,
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				),
			),
		)
	);

	// GET / PATCH / DELETE  /wp-json/ks/v1/events/{id}
	register_rest_route(
		'ks/v1',
		'/events/(?P<id>\d+)',
		array(
			array(
				'methods'             => 'GET',
				'callback'            => 'ks_cal_rest_get_event',
				'permission_callback' => 'ks_cal_rest_auth',
				'args'                => array(
					'id' => array( 'required' => true, 'type' => 'integer' ),
				),
			),
			array(
				'methods'             => 'PATCH',
				'callback'            => 'ks_cal_rest_patch_event',
				'permission_callback' => 'ks_cal_rest_auth',
				'args'                => array(
					'id' => array( 'required' => true, 'type' => 'integer' ),
				),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => 'ks_cal_rest_delete_event',
				'permission_callback' => 'ks_cal_rest_auth',
				'args'                => array(
					'id' => array( 'required' => true, 'type' => 'integer' ),
				),
			),
		)
	);

	// POST /wp-json/ks/v1/events/bulk-reschedule
	register_rest_route(
		'ks/v1',
		'/events/bulk-reschedule',
		array(
			'methods'             => 'POST',
			'callback'            => 'ks_cal_rest_bulk_reschedule',
			'permission_callback' => 'ks_cal_rest_auth',
		)
	);

	// POST /wp-json/ks/v1/events/quick-create
	register_rest_route(
		'ks/v1',
		'/events/quick-create',
		array(
			'methods'             => 'POST',
			'callback'            => 'ks_cal_rest_quick_create',
			'permission_callback' => 'ks_cal_rest_auth',
		)
	);
}

/**
 * Shared REST permission callback.
 * Nonce verification is handled automatically by WP REST API cookie auth
 * (client sends X-WP-Nonce header with the wp_rest nonce).
 *
 * @param WP_REST_Request $request
 * @return true|WP_Error
 */
function ks_cal_rest_auth( WP_REST_Request $request ) {
	if ( ! is_user_logged_in() ) {
		return new WP_Error( 'ks_unauthorized', 'Musisz być zalogowany.', array( 'status' => 401 ) );
	}
	if ( ! current_user_can( 'edit_posts' ) ) {
		return new WP_Error( 'ks_forbidden', 'Brak uprawnień.', array( 'status' => 403 ) );
	}
	return true;
}

// ============================================================
// HELPERS
// ============================================================

/**
 * Format a ks_urzadzenie post into the calendar event shape for REST responses.
 *
 * Phone numbers and sensitive PII are only included when the current user
 * is the event's owner or has manage_options capability.
 *
 * @param int $post_id
 * @return array|null  Null when the post is invalid.
 */
function ks_cal_format_event( $post_id ) {
	$post = get_post( $post_id );
	if ( ! $post || $post->post_type !== 'ks_urzadzenie' ) {
		return null;
	}

	$user_id   = get_current_user_id();
	$is_custom = get_post_meta( $post_id, 'ks_is_custom_app', true ) === 'true';
	$date      = get_post_meta( $post_id, 'ks_app_date', true );
	$time      = get_post_meta( $post_id, 'ks_app_time', true );
	$end_time  = get_post_meta( $post_id, 'ks_app_end_time', true );
	$status    = get_post_meta( $post_id, 'ks_app_status', true ) ?: 'scheduled';
	$address   = get_post_meta( $post_id, 'ks_adres_urzadzenia', true );
	$notes     = get_post_meta( $post_id, 'ks_notatki', true );

	// Build ISO datetime strings.
	if ( $date ) {
		$start_dt = $time ? $date . 'T' . $time . ':00' : $date;
		if ( $end_time ) {
			$end_dt = $date . 'T' . $end_time . ':00';
		} elseif ( $time ) {
			$end_dt = date( 'Y-m-d\TH:i:s', strtotime( $date . ' ' . $time ) + HOUR_IN_SECONDS );
		} else {
			$end_dt = $date;
		}
	} else {
		$start_dt = null;
		$end_dt   = null;
	}

	// Redact phone for users who are not the owner.
	$device_author = (int) $post->post_author;
	$phone         = '';
	$worker_name   = '';

	$current_viewer = get_userdata( $user_id );
	$is_manager     = $current_viewer && in_array( 'service_manager', (array) $current_viewer->roles, true );

	if ( $device_author === $user_id || current_user_can( 'manage_options' ) ) {
		$phone = get_post_meta( $post_id, 'ks_klient_tel', true );
	} elseif ( $is_manager ) {
		// Manager Serwisu widzi numer telefonu dla urządzeń swojego zespołu.
		$worker_ids = KS_Multi_Account::get_worker_ids_for_manager( $user_id );
		if ( in_array( $device_author, $worker_ids, true ) ) {
			$phone = get_post_meta( $post_id, 'ks_klient_tel', true );
		}
	}

	// For service_manager: always show who is responsible for each calendar entry
	// (own entries → manager's name, workers' entries → worker's name).
	if ( $is_manager ) {
		$author_data = get_userdata( $device_author );
		$worker_name = $author_data ? $author_data->display_name : '';
	}

	return array(
		'id'            => $post_id,
		'title'         => get_the_title( $post_id ),
		'start'         => $start_dt,
		'end'           => $end_dt,
		'technician_id' => $device_author,
		'device_id'     => $post_id,
		'status'        => $status,
		'is_custom'     => $is_custom,
		'worker_name'   => $worker_name,
		'meta'          => array(
			'phone'        => $phone,
			'address'      => $address,
			'notes'        => $notes,
			'has_protocol' => (bool) get_post_meta( $post_id, 'ks_has_protocol', true ),
			'parts_needed' => (bool) get_post_meta( $post_id, 'ks_parts_needed', true ),
			'sms_sent'     => get_post_meta( $post_id, 'ks_status_sms', true ) === 'Wysłano',
		),
	);
}

/**
 * Detect scheduling conflicts for a technician within a time range.
 *
 * Returns events belonging to $user_id that overlap [start, end).
 *
 * @param int    $user_id    Technician user ID.
 * @param string $start      ISO datetime string (e.g. "2025-03-15T10:00:00").
 * @param string $end        ISO datetime string.
 * @param int    $exclude_id Post ID to exclude (the event being rescheduled).
 * @return array  Array of conflicting event arrays (may be empty).
 */
function ks_cal_detect_conflicts( $user_id, $start, $end, $exclude_id = 0 ) {
	$start_ts = strtotime( $start );
	$end_ts   = strtotime( $end );

	if ( ! $start_ts || ! $end_ts || $start_ts >= $end_ts ) {
		return array();
	}

	$start_date = date( 'Y-m-d', $start_ts );

	$posts = get_posts(
		array(
			'post_type'              => 'ks_urzadzenie',
			'author'                 => $user_id,
			'meta_key'               => 'ks_app_date',
			'meta_value'             => $start_date,
			'posts_per_page'         => 50,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'suppress_filters'       => false,
		)
	);

	$conflicts = array();
	foreach ( $posts as $post ) {
		if ( (int) $post->ID === (int) $exclude_id ) {
			continue;
		}

		$ev_date = get_post_meta( $post->ID, 'ks_app_date', true );
		$ev_time = get_post_meta( $post->ID, 'ks_app_time', true );
		$ev_end  = get_post_meta( $post->ID, 'ks_app_end_time', true );

		if ( ! $ev_date || ! $ev_time ) {
			continue;
		}

		$ev_start_ts = strtotime( $ev_date . ' ' . $ev_time );
		$ev_end_ts   = $ev_end
			? strtotime( $ev_date . ' ' . $ev_end )
			: $ev_start_ts + HOUR_IN_SECONDS;

		// Standard overlap test: A.start < B.end && A.end > B.start
		if ( $start_ts < $ev_end_ts && $end_ts > $ev_start_ts ) {
			$formatted = ks_cal_format_event( $post->ID );
			if ( $formatted ) {
				$conflicts[] = $formatted;
			}
		}
	}

	return $conflicts;
}

/**
 * Append an immutable audit entry to the event's post meta.
 *
 * Uses add_post_meta with $unique = false so each call creates a new row
 * (pure append – no existing entries are modified or deleted).
 *
 * @param int    $event_id    Post ID.
 * @param string $change_type Semantic type: 'create', 'update', 'bulk_reschedule', 'status_change', 'delete'.
 * @param mixed  $old_data    Snapshot of previous values.
 * @param mixed  $new_data    Snapshot of new values.
 * @param string $note        Optional free-text note (e.g. "forced conflict override").
 */
function ks_cal_audit_log( $event_id, $change_type, $old_data, $new_data, $note = '' ) {
	$entry = array(
		'event_id'    => $event_id,
		'changed_by'  => get_current_user_id(),
		'change_type' => $change_type,
		'old'         => $old_data,
		'new'         => $new_data,
		'note'        => $note,
		'timestamp'   => current_time( 'c' ),
	);

	// add_post_meta with $unique = false appends a new meta row each time.
	add_post_meta( $event_id, 'ks_audit_entries', wp_json_encode( $entry ) );

	ks_log(
		'[KS-Cal Audit] event=' . $event_id
		. ' type=' . $change_type
		. ' by=' . $entry['changed_by']
		. ( $note ? ' note=' . $note : '' )
	);
}

/**
 * Delete all cached event-list transients for a user.
 *
 * @param int $user_id
 */
function ks_cal_invalidate_cache( $user_id ) {
	global $wpdb;

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options}
			 WHERE option_name LIKE %s
			    OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_ks_cal_events_' . $user_id . '_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_ks_cal_events_' . $user_id . '_' ) . '%'
		)
	);
}

// ============================================================
// REST CALLBACKS
// ============================================================

/**
 * GET /wp-json/ks/v1/events
 *
 * Returns a list of calendar events for the current user within the requested
 * date range. Always returns fresh data (no server-side caching) so that
 * newly added appointments are immediately visible when switching views.
 *
 * Example response:
 * [
 *   {
 *     "id": 123,
 *     "title": "Pralka Samsung – Jan Kowalski",
 *     "start": "2025-03-15T10:00:00",
 *     "end":   "2025-03-15T11:00:00",
 *     "technician_id": 42,
 *     "device_id": 123,
 *     "status": "scheduled",
 *     "is_custom": false,
 *     "meta": { "phone": "+48123456789", "address": "...", "has_protocol": false, ... }
 *   }
 * ]
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function ks_cal_rest_get_events( WP_REST_Request $request ) {
	$user_id = get_current_user_id();
	$start   = $request->get_param( 'start' );
	$end     = $request->get_param( 'end' );
	$status  = $request->get_param( 'status' );

	// Require YYYY-MM-DD prefix.
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}/', $start )
		|| ! preg_match( '/^\d{4}-\d{2}-\d{2}/', $end ) ) {
		return new WP_Error( 'ks_invalid_dates', 'Nieprawidłowy format dat (wymagany YYYY-MM-DD).', array( 'status' => 400 ) );
	}

	$start_date = substr( $start, 0, 10 );
	$end_date   = substr( $end, 0, 10 );

	// Clamp to 90-day window to prevent expensive DB queries.
	if ( strtotime( $end_date ) - strtotime( $start_date ) > 90 * DAY_IN_SECONDS ) {
		return new WP_Error( 'ks_range_too_large', 'Maksymalny zakres to 90 dni.', array( 'status' => 400 ) );
	}

	$meta_query = array(
		'relation' => 'AND',
		array(
			'key'     => 'ks_app_date',
			'value'   => $start_date,
			'compare' => '>=',
			'type'    => 'DATE',
		),
		array(
			'key'     => 'ks_app_date',
			'value'   => $end_date,
			'compare' => '<=',
			'type'    => 'DATE',
		),
	);

	// Optional status filter.
	// "scheduled" must also match events where ks_app_status was never saved
	// (the legacy save handler doesn't write this meta, so it defaults to 'scheduled').
	if ( $status ) {
		if ( 'scheduled' === $status ) {
			$meta_query[] = array(
				'relation' => 'OR',
				array(
					'key'     => 'ks_app_status',
					'value'   => 'scheduled',
					'compare' => '=',
				),
				array(
					'key'     => 'ks_app_status',
					'compare' => 'NOT EXISTS',
				),
			);
		} elseif ( in_array( $status, array( 'completed', 'cancelled' ), true ) ) {
			$meta_query[] = array(
				'key'     => 'ks_app_status',
				'value'   => $status,
				'compare' => '=',
			);
		}
	}

	$posts = get_posts(
		array(
			'post_type'              => 'ks_urzadzenie',
			'author'                 => $user_id,
			'meta_query'             => $meta_query,
			'posts_per_page'         => 500,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'suppress_filters'       => false,
		)
	);

	$events = array_values(
		array_filter(
			array_map(
				'ks_cal_format_event',
				array_column( $posts, 'ID' )
			)
		)
	);

	return rest_ensure_response( $events );
}

/**
 * GET /wp-json/ks/v1/events/{id}
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function ks_cal_rest_get_event( WP_REST_Request $request ) {
	$user_id  = get_current_user_id();
	$event_id = (int) $request->get_param( 'id' );

	if ( ! ks_verify_device_ownership( $event_id, $user_id ) ) {
		return new WP_Error( 'ks_forbidden', 'Brak dostępu do tego wpisu.', array( 'status' => 403 ) );
	}

	$event = ks_cal_format_event( $event_id );
	if ( ! $event ) {
		return new WP_Error( 'ks_not_found', 'Wpis nie istnieje.', array( 'status' => 404 ) );
	}

	return rest_ensure_response( $event );
}

/**
 * PATCH /wp-json/ks/v1/events/{id}
 *
 * Accepts:
 *   start  – ISO datetime string
 *   end    – ISO datetime string
 *   status – "scheduled" | "completed" | "cancelled"
 *   meta   – { notes, has_protocol, parts_needed }
 *   force  – boolean – skip conflict guard
 *   note   – audit note string
 *
 * Returns 409 with conflict list when force=false and an overlap is detected.
 *
 * Example success response:
 * {
 *   "event": { ... },
 *   "forced": false,
 *   "audit": { "change_type": "update", "timestamp": "..." }
 * }
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function ks_cal_rest_patch_event( WP_REST_Request $request ) {
	$user_id  = get_current_user_id();
	$event_id = (int) $request->get_param( 'id' );

	// Ownership check (same function used everywhere in the plugin).
	if ( ! ks_verify_device_ownership( $event_id, $user_id ) ) {
		return new WP_Error( 'ks_forbidden', 'Brak dostępu do tego wpisu.', array( 'status' => 403 ) );
	}

	$body  = $request->get_json_params();
	$force = ! empty( $body['force'] );
	$note  = isset( $body['note'] ) ? sanitize_textarea_field( wp_unslash( $body['note'] ) ) : '';

	// Snapshot old state for audit.
	$old_date     = get_post_meta( $event_id, 'ks_app_date', true );
	$old_time     = get_post_meta( $event_id, 'ks_app_time', true );
	$old_end_time = get_post_meta( $event_id, 'ks_app_end_time', true );
	$old_status   = get_post_meta( $event_id, 'ks_app_status', true ) ?: 'scheduled';

	$new_date     = $old_date;
	$new_time     = $old_time;
	$new_end_time = $old_end_time;
	$new_status   = $old_status;

	// Parse and validate new datetime if provided.
	if ( isset( $body['start'], $body['end'] ) ) {
		$start_ts = strtotime( $body['start'] );
		$end_ts   = strtotime( $body['end'] );

		if ( ! $start_ts || ! $end_ts ) {
			return new WP_Error( 'ks_invalid_dates', 'Nieprawidłowy format dat.', array( 'status' => 400 ) );
		}
		if ( $start_ts >= $end_ts ) {
			return new WP_Error(
				'ks_invalid_range',
				'Data rozpoczęcia musi być wcześniejsza niż zakończenia.',
				array( 'status' => 400 )
			);
		}

		$new_date     = date( 'Y-m-d', $start_ts );
		$new_time     = date( 'H:i', $start_ts );
		$new_end_time = date( 'H:i', $end_ts );

		// Conflict detection (server-side re-check even after optimistic UI).
		if ( ! $force ) {
			$conflicts = ks_cal_detect_conflicts(
				$user_id,
				$body['start'],
				$body['end'],
				$event_id
			);
			if ( ! empty( $conflicts ) ) {
				return new WP_REST_Response(
					array(
						'code'      => 'ks_conflict',
						'message'   => 'Wykryto nakładające się wizyty. Użyj force=true z notą aby kontynuować.',
						'conflicts' => $conflicts,
					),
					409
				);
			}
		}
	}

	// Status update.
	if ( isset( $body['status'] ) ) {
		$allowed = array( 'scheduled', 'completed', 'cancelled' );
		if ( in_array( $body['status'], $allowed, true ) ) {
			$new_status = $body['status'];
		}
	}

	// Apply updates.
	update_post_meta( $event_id, 'ks_app_date', $new_date );
	update_post_meta( $event_id, 'ks_app_time', $new_time );
	update_post_meta( $event_id, 'ks_app_end_time', $new_end_time );
	update_post_meta( $event_id, 'ks_app_status', $new_status );

	// Optional meta sub-fields.
	if ( isset( $body['meta'] ) && is_array( $body['meta'] ) ) {
		if ( array_key_exists( 'has_protocol', $body['meta'] ) ) {
			update_post_meta( $event_id, 'ks_has_protocol', $body['meta']['has_protocol'] ? '1' : '' );
		}
		if ( array_key_exists( 'parts_needed', $body['meta'] ) ) {
			update_post_meta( $event_id, 'ks_parts_needed', $body['meta']['parts_needed'] ? '1' : '' );
		}
		if ( isset( $body['meta']['notes'] ) ) {
			update_post_meta(
				$event_id,
				'ks_notatki',
				sanitize_textarea_field( wp_unslash( $body['meta']['notes'] ) )
			);
		}
	}

	// Audit log.
	ks_cal_audit_log(
		$event_id,
		'update',
		array(
			'date'     => $old_date,
			'time'     => $old_time,
			'end_time' => $old_end_time,
			'status'   => $old_status,
		),
		array(
			'date'     => $new_date,
			'time'     => $new_time,
			'end_time' => $new_end_time,
			'status'   => $new_status,
		),
		$force ? 'forced' . ( $note ? ': ' . $note : '' ) : $note
	);

	// Purge caches.
	ks_cal_invalidate_cache( $user_id );
	ks_cal_purge_litespeed( $event_id );

	$event = ks_cal_format_event( $event_id );

	return rest_ensure_response(
		array(
			'event'  => $event,
			'forced' => $force,
			'audit'  => array(
				'change_type' => 'update',
				'timestamp'   => current_time( 'c' ),
			),
		)
	);
}

/**
 * POST /wp-json/ks/v1/events/bulk-reschedule
 *
 * Body: { "ids": [1,2,3], "delta": { "days": 1, "hours": 0 }, "force": false }
 *
 * Returns per-event results; conflicting events are reported in the response
 * and skipped (set force=true to override).
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function ks_cal_rest_bulk_reschedule( WP_REST_Request $request ) {
	$user_id = get_current_user_id();
	$body    = $request->get_json_params();

	$ids         = isset( $body['ids'] ) && is_array( $body['ids'] ) ? array_map( 'intval', $body['ids'] ) : array();
	$delta       = isset( $body['delta'] ) && is_array( $body['delta'] ) ? $body['delta'] : array();
	$force       = ! empty( $body['force'] );
	$note        = isset( $body['note'] ) ? sanitize_text_field( wp_unslash( $body['note'] ) ) : '';

	if ( empty( $ids ) ) {
		return new WP_Error( 'ks_missing_ids', 'Brak identyfikatorów wizyt.', array( 'status' => 400 ) );
	}
	if ( count( $ids ) > 100 ) {
		return new WP_Error( 'ks_too_many', 'Maksymalnie 100 wizyt w jednym żądaniu.', array( 'status' => 400 ) );
	}

	$delta_days  = isset( $delta['days'] )  ? intval( $delta['days'] )  : 0;
	$delta_hours = isset( $delta['hours'] ) ? intval( $delta['hours'] ) : 0;
	$delta_secs  = ( $delta_days * DAY_IN_SECONDS ) + ( $delta_hours * HOUR_IN_SECONDS );

	if ( 0 === $delta_secs ) {
		return new WP_Error( 'ks_zero_delta', 'Delta nie może wynosić 0.', array( 'status' => 400 ) );
	}

	$results = array();

	foreach ( $ids as $event_id ) {
		if ( ! ks_verify_device_ownership( $event_id, $user_id ) ) {
			$results[] = array( 'id' => $event_id, 'status' => 'error', 'message' => 'Brak uprawnień.' );
			continue;
		}

		$old_date = get_post_meta( $event_id, 'ks_app_date', true );
		$old_time = get_post_meta( $event_id, 'ks_app_time', true );
		$old_end  = get_post_meta( $event_id, 'ks_app_end_time', true );

		if ( ! $old_date || ! $old_time ) {
			$results[] = array( 'id' => $event_id, 'status' => 'skipped', 'message' => 'Brak daty lub godziny.' );
			continue;
		}

		$start_ts     = strtotime( $old_date . ' ' . $old_time ) + $delta_secs;
		$end_ts       = $old_end
			? strtotime( $old_date . ' ' . $old_end ) + $delta_secs
			: $start_ts + HOUR_IN_SECONDS;
		$new_date     = date( 'Y-m-d', $start_ts );
		$new_time     = date( 'H:i', $start_ts );
		$new_end_time = date( 'H:i', $end_ts );

		if ( ! $force ) {
			$conflicts = ks_cal_detect_conflicts(
				$user_id,
				date( 'Y-m-d\TH:i:s', $start_ts ),
				date( 'Y-m-d\TH:i:s', $end_ts ),
				$event_id
			);
			if ( ! empty( $conflicts ) ) {
				$results[] = array(
					'id'        => $event_id,
					'status'    => 'conflict',
					'conflicts' => $conflicts,
				);
				continue;
			}
		}

		update_post_meta( $event_id, 'ks_app_date', $new_date );
		update_post_meta( $event_id, 'ks_app_time', $new_time );
		update_post_meta( $event_id, 'ks_app_end_time', $new_end_time );

		ks_cal_audit_log(
			$event_id,
			'bulk_reschedule',
			array( 'date' => $old_date, 'time' => $old_time ),
			array( 'date' => $new_date, 'time' => $new_time ),
			'days=' . $delta_days . ' hours=' . $delta_hours . ( $force ? ' (forced)' : '' ) . ( $note ? ' ' . $note : '' )
		);

		$results[] = array(
			'id'    => $event_id,
			'status' => 'ok',
			'event' => ks_cal_format_event( $event_id ),
		);
	}

	ks_cal_invalidate_cache( $user_id );

	return rest_ensure_response( array( 'results' => $results ) );
}

/**
 * POST /wp-json/ks/v1/events/quick-create
 *
 * Body: { "title": "...", "start": "2025-03-15T10:00:00", "end": "...",
 *         "device_id": 0, "address": "...", "notes": "..." }
 *
 * When device_id is provided the appointment meta is set on the existing device;
 * otherwise a new custom appointment (ks_is_custom_app = 'true') is created.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function ks_cal_rest_quick_create( WP_REST_Request $request ) {
	$user_id   = get_current_user_id();
	$body      = $request->get_json_params();

	$title            = isset( $body['title'] )            ? sanitize_text_field( wp_unslash( $body['title'] ) )            : '';
	$start_raw        = isset( $body['start'] )            ? sanitize_text_field( wp_unslash( $body['start'] ) )            : '';
	$end_raw          = isset( $body['end'] )              ? sanitize_text_field( wp_unslash( $body['end'] ) )              : '';
	$device_id        = isset( $body['device_id'] )        ? intval( $body['device_id'] )                                   : 0;
	$address          = isset( $body['address'] )          ? sanitize_text_field( wp_unslash( $body['address'] ) )          : '';
	$notes            = isset( $body['notes'] )            ? sanitize_textarea_field( wp_unslash( $body['notes'] ) )        : '';
	$target_worker_id = isset( $body['target_worker_id'] ) ? intval( $body['target_worker_id'] )                            : 0;

	// Validate target_worker_id: only a service_manager can assign to a worker,
	// and only to a worker that belongs to them.
	$post_author = $user_id;
	if ( $target_worker_id > 0 && $target_worker_id !== $user_id ) {
		$current_viewer = get_userdata( $user_id );
		if ( ! $current_viewer || ! in_array( 'service_manager', (array) $current_viewer->roles, true ) ) {
			return new WP_Error( 'ks_forbidden', 'Tylko Manager Serwisu może przydzielać wizyty pracownikom.', array( 'status' => 403 ) );
		}
		$allowed_workers = KS_Multi_Account::get_worker_ids_for_manager( $user_id );
		if ( ! in_array( $target_worker_id, $allowed_workers, true ) ) {
			return new WP_Error( 'ks_forbidden', 'Wybrany pracownik nie należy do Twojego zespołu.', array( 'status' => 403 ) );
		}
		$post_author = $target_worker_id;
	}

	if ( ! $start_raw ) {
		return new WP_Error( 'ks_missing_start', 'Wymagany parametr: start.', array( 'status' => 400 ) );
	}

	$start_ts = strtotime( $start_raw );
	$end_ts   = $end_raw ? strtotime( $end_raw ) : $start_ts + HOUR_IN_SECONDS;

	if ( ! $start_ts ) {
		return new WP_Error( 'ks_invalid_dates', 'Nieprawidłowy format daty start.', array( 'status' => 400 ) );
	}
	if ( $start_ts >= $end_ts ) {
		return new WP_Error(
			'ks_invalid_range',
			'Data rozpoczęcia musi być wcześniejsza niż zakończenia.',
			array( 'status' => 400 )
		);
	}

	$new_date     = date( 'Y-m-d', $start_ts );
	$new_time     = date( 'H:i', $start_ts );
	$new_end_time = date( 'H:i', $end_ts );

	// Update existing device's appointment.
	if ( $device_id > 0 ) {
		if ( ! ks_verify_device_ownership( $device_id, $user_id ) ) {
			return new WP_Error( 'ks_forbidden', 'Brak dostępu do urządzenia.', array( 'status' => 403 ) );
		}

		// Detect whether there is already a scheduled appointment so the audit
		// log reflects 'update' (reschedule) rather than 'create'.
		$existing_date = get_post_meta( $device_id, 'ks_app_date', true );
		$audit_type    = $existing_date ? 'update' : 'create';
		$old_snapshot  = $existing_date ? array( 'date' => $existing_date, 'time' => get_post_meta( $device_id, 'ks_app_time', true ) ) : array();

		update_post_meta( $device_id, 'ks_app_date', $new_date );
		update_post_meta( $device_id, 'ks_app_time', $new_time );
		update_post_meta( $device_id, 'ks_app_end_time', $new_end_time );
		update_post_meta( $device_id, 'ks_app_status', 'scheduled' );

		ks_cal_audit_log(
			$device_id,
			$audit_type,
			$old_snapshot,
			array( 'date' => $new_date, 'time' => $new_time )
		);
		ks_cal_invalidate_cache( $user_id );
		ks_cal_purge_litespeed( $device_id );

		return rest_ensure_response(
			array(
				'id'    => $device_id,
				'event' => ks_cal_format_event( $device_id ),
			)
		);
	}

	// Create a new custom appointment.
	if ( ! $title ) {
		return new WP_Error( 'ks_missing_title', 'Wymagany tytuł dla nowego wpisu.', array( 'status' => 400 ) );
	}

	$new_id = wp_insert_post(
		array(
			'post_type'   => 'ks_urzadzenie',
			'post_title'  => $title,
			'post_status' => 'publish',
			'post_author' => $post_author,
		),
		true
	);

	if ( is_wp_error( $new_id ) ) {
		return new WP_Error( 'ks_create_failed', 'Nie udało się utworzyć wpisu: ' . $new_id->get_error_message(), array( 'status' => 500 ) );
	}

	update_post_meta( $new_id, 'ks_is_custom_app', 'true' );
	update_post_meta( $new_id, 'ks_app_date', $new_date );
	update_post_meta( $new_id, 'ks_app_time', $new_time );
	update_post_meta( $new_id, 'ks_app_end_time', $new_end_time );
	update_post_meta( $new_id, 'ks_app_status', 'scheduled' );

	if ( $address ) {
		update_post_meta( $new_id, 'ks_adres_urzadzenia', $address );
	}
	if ( $notes ) {
		update_post_meta( $new_id, 'ks_notatki', $notes );
	}

	ks_cal_audit_log(
		$new_id,
		'create',
		array(),
		array( 'date' => $new_date, 'time' => $new_time, 'title' => $title )
	);
	ks_cal_invalidate_cache( $user_id );
	// If the appointment was assigned to a worker, also invalidate the worker's cache.
	if ( $post_author !== $user_id ) {
		ks_cal_invalidate_cache( $post_author );
	}
	ks_cal_purge_litespeed( $new_id );

	return new WP_REST_Response(
		array(
			'id'    => $new_id,
			'event' => ks_cal_format_event( $new_id ),
		),
		201
	);
}

/**
 * DELETE /wp-json/ks/v1/events/{id}
 *
 * For custom appointments (ks_is_custom_app = 'true') permanently deletes the
 * post.  For device-linked appointments only clears the scheduling meta so the
 * device record is preserved in the database.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function ks_cal_rest_delete_event( WP_REST_Request $request ) {
	$user_id  = get_current_user_id();
	$event_id = (int) $request->get_param( 'id' );

	if ( ! ks_verify_device_ownership( $event_id, $user_id ) ) {
		return new WP_Error( 'ks_forbidden', 'Brak dostępu do tego wpisu.', array( 'status' => 403 ) );
	}

	// Snapshot before changes so the audit entry is meaningful.
	$snapshot  = ks_cal_format_event( $event_id );
	$is_custom = get_post_meta( $event_id, 'ks_is_custom_app', true ) === 'true';

	if ( $is_custom ) {
		// Custom appointments are standalone posts – safe to permanently delete.
		$result = wp_delete_post( $event_id, true ); // true = force delete (skip trash).
		if ( ! $result ) {
			return new WP_Error( 'ks_delete_failed', 'Nie udało się usunąć wpisu.', array( 'status' => 500 ) );
		}
	} else {
		// Device-linked appointments: only clear the scheduling meta fields.
		// This removes the event from the calendar without deleting the device record.
		delete_post_meta( $event_id, 'ks_app_date' );
		delete_post_meta( $event_id, 'ks_app_time' );
		delete_post_meta( $event_id, 'ks_app_end_time' );
		delete_post_meta( $event_id, 'ks_app_status' );
	}

	ks_cal_audit_log( $event_id, 'delete', $snapshot, array() );

	ks_cal_invalidate_cache( $user_id );
	ks_cal_purge_litespeed( $event_id );

	return rest_ensure_response( array( 'deleted' => true, 'id' => $event_id ) );
}
