<?php
/**
 * PHPUnit bootstrap for KiedySerwis calendar tests.
 *
 * Requires a local WordPress test suite (wp-tests-config.php + WordPress
 * testing framework at $WORDPRESS_TESTS_DIR). Set environment variables:
 *
 *   WP_TESTS_DIR  – path to wordpress-develop/tests/phpunit
 *   WP_TESTS_DB_*  – database credentials (see wp-tests-config.php)
 *
 * Run with: vendor/bin/phpunit --config phpunit.xml.dist
 */

$_tests_dir = getenv( 'WP_TESTS_DIR' );
if ( ! $_tests_dir ) {
    $_tests_dir = rtrim( sys_get_temp_dir(), '/\\' ) . '/wordpress-tests-lib';
}

if ( ! file_exists( "$_tests_dir/includes/functions.php" ) ) {
    echo "Could not find $_tests_dir/includes/functions.php. " .
         "Set WP_TESTS_DIR to the WordPress test suite directory.\n";
    exit( 1 );
}

// Load WordPress test functions & bootstrap.
require_once "$_tests_dir/includes/functions.php";

tests_add_filter( 'muplugins_loaded', function () {
    // Load the plugin under test.
    require_once dirname( dirname( __FILE__ ) ) . '/kiedyserwis-core.php';
} );

require_once "$_tests_dir/includes/bootstrap.php";
