<?php
/**
 * Unit tests for the KiedySerwis Referral System.
 *
 * Tests cover:
 *  - Referral code generation (uniqueness, format)
 *  - get_or_create returns the same code on repeat calls
 *  - Registration links referred_by when a valid code is provided
 *  - Award bonus only once (idempotency via ks_referral_rewarded flag)
 *  - Award upgrades free referrer to premium
 *  - Award extends existing premium expiry
 *  - Admin column filter exposes ks_referral_code column
 *  - Premium14 trial is granted to referred user on activation
 *  - ks_is_premium_active() returns true for premium14
 *  - ks_award_referral_bonus() does NOT fire for premium14 users (only real payment)
 *  - Admin column displays "Premium14" for premium14 status
 *
 * @package KiedySerwis
 */

class Test_KS_Referral extends WP_UnitTestCase {

	/** @var int */
	private $referrer_id;

	/** @var int */
	private $referred_id;

	public function setUp(): void {
		parent::setUp();

		$this->referrer_id = $this->factory->user->create( array( 'role' => 'author' ) );
		$this->referred_id = $this->factory->user->create( array( 'role' => 'author' ) );
	}

	public function tearDown(): void {
		wp_delete_user( $this->referrer_id );
		wp_delete_user( $this->referred_id );
		parent::tearDown();
	}

	// =========================================================
	// Code generation
	// =========================================================

	public function test_generated_code_is_5_chars() {
		$code = ks_generate_referral_code();
		$this->assertEquals( 5, strlen( $code ) );
	}

	public function test_generated_code_is_lowercase_alnum() {
		$code = ks_generate_referral_code();
		$this->assertMatchesRegularExpression( '/^[a-z0-9]{5}$/', $code );
	}

	public function test_get_or_create_stores_code() {
		$code = ks_get_or_create_referral_code( $this->referrer_id );
		$stored = get_user_meta( $this->referrer_id, 'ks_referral_code', true );
		$this->assertEquals( $code, $stored );
	}

	public function test_get_or_create_returns_same_code_on_repeat_call() {
		$code1 = ks_get_or_create_referral_code( $this->referrer_id );
		$code2 = ks_get_or_create_referral_code( $this->referrer_id );
		$this->assertEquals( $code1, $code2 );
	}

	// =========================================================
	// Premium14 trial plan
	// =========================================================

	public function test_premium14_is_active_plan() {
		update_user_meta( $this->referred_id, 'ks_plan_status', 'premium14' );
		update_user_meta( $this->referred_id, 'ks_plan_expiry', time() + 14 * DAY_IN_SECONDS );

		$this->assertTrue( ks_is_premium_active( $this->referred_id ), 'premium14 should be treated as an active premium plan.' );
	}

	public function test_expired_premium14_is_not_active() {
		update_user_meta( $this->referred_id, 'ks_plan_status', 'premium14' );
		update_user_meta( $this->referred_id, 'ks_plan_expiry', time() - 1 );

		$this->assertFalse( ks_is_premium_active( $this->referred_id ), 'Expired premium14 should not be active.' );
	}

	public function test_premium14_does_not_trigger_referral_bonus_by_itself() {
		// Simulate a referred user who got premium14 at registration (before paying)
		update_user_meta( $this->referred_id, 'ks_referred_by', $this->referrer_id );
		update_user_meta( $this->referred_id, 'ks_plan_status', 'premium14' );
		update_user_meta( $this->referred_id, 'ks_plan_expiry', time() + 14 * DAY_IN_SECONDS );

		// ks_award_referral_bonus is ONLY called from the payment webhook (not on activation).
		// Directly verify the referrer has NOT received a bonus.
		$referrer_status = get_user_meta( $this->referrer_id, 'ks_plan_status', true );
		$this->assertEmpty( $referrer_status, 'Referrer should not receive bonus just because referred user has premium14.' );
	}

	public function test_get_plan_data_auto_expires_premium14() {
		update_user_meta( $this->referred_id, 'ks_plan_status', 'premium14' );
		update_user_meta( $this->referred_id, 'ks_plan_expiry', time() - 1 );

		$data = ks_get_plan_data( $this->referred_id );
		$this->assertEquals( 'free', $data['status'], 'Expired premium14 should auto-downgrade to free.' );
	}

	// =========================================================
	// Referral bonus award
	// =========================================================

	public function test_award_does_nothing_when_no_referrer() {
		// referred_id has no ks_referred_by meta.
		ks_award_referral_bonus( $this->referred_id );
		// Referrer plan should be unchanged.
		$status = get_user_meta( $this->referrer_id, 'ks_plan_status', true );
		$this->assertEmpty( $status, 'Plan status should not be set when no referral link exists.' );
	}

	public function test_award_upgrades_free_referrer_to_premium() {
		update_user_meta( $this->referred_id, 'ks_referred_by', $this->referrer_id );

		$before = time();
		ks_award_referral_bonus( $this->referred_id );

		$status = get_user_meta( $this->referrer_id, 'ks_plan_status', true );
		$expiry = (int) get_user_meta( $this->referrer_id, 'ks_plan_expiry', true );

		$this->assertEquals( 'premium', $status );
		$this->assertGreaterThan( $before + 29 * DAY_IN_SECONDS, $expiry );
	}

	public function test_award_extends_existing_premium_expiry() {
		$existing_expiry = time() + 10 * DAY_IN_SECONDS;
		update_user_meta( $this->referrer_id, 'ks_plan_status', 'premium' );
		update_user_meta( $this->referrer_id, 'ks_plan_expiry', $existing_expiry );
		update_user_meta( $this->referred_id, 'ks_referred_by', $this->referrer_id );

		ks_award_referral_bonus( $this->referred_id );

		$new_expiry = (int) get_user_meta( $this->referrer_id, 'ks_plan_expiry', true );
		$this->assertGreaterThan( $existing_expiry, $new_expiry, 'Expiry should be extended beyond the existing premium expiry.' );
	}

	public function test_award_accumulates_bonus_days() {
		update_user_meta( $this->referred_id, 'ks_referred_by', $this->referrer_id );

		ks_award_referral_bonus( $this->referred_id );

		$bonus = (int) get_user_meta( $this->referrer_id, 'ks_referral_bonus_days', true );
		$this->assertEquals( 30, $bonus );
	}

	public function test_award_is_idempotent_on_repeat_calls() {
		update_user_meta( $this->referred_id, 'ks_referred_by', $this->referrer_id );

		ks_award_referral_bonus( $this->referred_id );
		$expiry_after_first = (int) get_user_meta( $this->referrer_id, 'ks_plan_expiry', true );

		// Second call must not add more days.
		ks_award_referral_bonus( $this->referred_id );
		$expiry_after_second = (int) get_user_meta( $this->referrer_id, 'ks_plan_expiry', true );

		$this->assertEquals( $expiry_after_first, $expiry_after_second, 'Second award call must not extend expiry again.' );

		$bonus = (int) get_user_meta( $this->referrer_id, 'ks_referral_bonus_days', true );
		$this->assertEquals( 30, $bonus, 'Bonus days must not be doubled on second call.' );
	}

	public function test_award_sets_rewarded_flag() {
		update_user_meta( $this->referred_id, 'ks_referred_by', $this->referrer_id );

		ks_award_referral_bonus( $this->referred_id );

		$flag = get_user_meta( $this->referred_id, 'ks_referral_rewarded', true );
		$this->assertEquals( '1', $flag );
	}

	// =========================================================
	// Multi-plan (Manager Serwisu) referral scenarios
	// =========================================================

	/**
	 * When the referrer already has plan_status='multi', the bonus must extend
	 * the expiry but MUST NOT downgrade the status to 'premium'.
	 */
	public function test_award_preserves_multi_status_for_service_manager() {
		$existing_expiry = time() + 20 * DAY_IN_SECONDS;
		update_user_meta( $this->referrer_id, 'ks_plan_status', 'multi' );
		update_user_meta( $this->referrer_id, 'ks_plan_expiry', $existing_expiry );
		update_user_meta( $this->referred_id, 'ks_referred_by', $this->referrer_id );

		ks_award_referral_bonus( $this->referred_id );

		$status     = get_user_meta( $this->referrer_id, 'ks_plan_status', true );
		$new_expiry = (int) get_user_meta( $this->referrer_id, 'ks_plan_expiry', true );

		$this->assertEquals( 'multi', $status, 'Multi plan status must not be downgraded to premium by a referral bonus.' );
		$this->assertGreaterThan( $existing_expiry, $new_expiry, 'Multi plan expiry must be extended by the bonus.' );
	}

	/**
	 * When a service_worker shares their referral code and a new user buys premium,
	 * the bonus must be credited to the worker's parent service_manager (not the worker).
	 */
	public function test_award_credits_manager_when_worker_is_referrer() {
		// Create manager and worker.
		$manager_id = $this->factory->user->create( array( 'role' => 'author' ) );
		$worker_id  = $this->factory->user->create( array( 'role' => 'author' ) );

		// Assign service_worker role and link to manager.
		$worker_user = new WP_User( $worker_id );
		$worker_user->set_role( 'service_worker' );
		update_user_meta( $worker_id, '_parent_manager_id', $manager_id );

		// Manager has active multi plan.
		$existing_expiry = time() + 15 * DAY_IN_SECONDS;
		update_user_meta( $manager_id, 'ks_plan_status', 'multi' );
		update_user_meta( $manager_id, 'ks_plan_expiry', $existing_expiry );

		// New user was referred by the worker.
		update_user_meta( $this->referred_id, 'ks_referred_by', $worker_id );

		ks_award_referral_bonus( $this->referred_id );

		// Manager's expiry should be extended and status preserved.
		$mgr_status  = get_user_meta( $manager_id, 'ks_plan_status', true );
		$mgr_expiry  = (int) get_user_meta( $manager_id, 'ks_plan_expiry', true );

		$this->assertEquals( 'multi', $mgr_status, 'Manager multi status must be preserved when worker referred someone.' );
		$this->assertGreaterThan( $existing_expiry, $mgr_expiry, 'Manager multi expiry must be extended via worker referral.' );

		// Worker's own plan must remain untouched.
		$worker_status = get_user_meta( $worker_id, 'ks_plan_status', true );
		$this->assertEmpty( $worker_status, 'Worker should not receive the bonus directly; it belongs to the manager.' );

		wp_delete_user( $manager_id );
		wp_delete_user( $worker_id );
	}

	/**
	 * If a service_worker has no parent manager linked, the bonus falls back to the worker.
	 */
	public function test_award_falls_back_to_worker_when_no_manager() {
		$worker_id = $this->factory->user->create( array( 'role' => 'author' ) );
		$worker_user = new WP_User( $worker_id );
		$worker_user->set_role( 'service_worker' );
		// No _parent_manager_id set.

		update_user_meta( $this->referred_id, 'ks_referred_by', $worker_id );

		ks_award_referral_bonus( $this->referred_id );

		// Worker should receive premium as fallback.
		$status = get_user_meta( $worker_id, 'ks_plan_status', true );
		$this->assertEquals( 'premium', $status, 'Worker with no manager should receive premium bonus as fallback.' );

		wp_delete_user( $worker_id );
	}

	// =========================================================
	// Admin column registration
	// =========================================================

	public function test_admin_column_is_registered() {
		$admin = new KS_Admin_Users();
		$columns = $admin->add_premium_columns( array() );
		$this->assertArrayHasKey( 'ks_referral_code', $columns );
		$this->assertEquals( 'KOD', $columns['ks_referral_code'] );
	}

	public function test_admin_column_shows_premium14_label() {
		// premium14 status within expiry
		update_user_meta( $this->referred_id, 'ks_plan_status', 'premium14' );
		update_user_meta( $this->referred_id, 'ks_plan_expiry', time() + 14 * DAY_IN_SECONDS );

		// Grant manage_options so the column renders.
		$admin_user = $this->factory->user->create( array( 'role' => 'administrator' ) );
		wp_set_current_user( $admin_user );

		$admin   = new KS_Admin_Users();
		$output  = $admin->render_premium_columns( '', 'ks_plan_status', $this->referred_id );

		$this->assertStringContainsString( 'Premium14', $output );

		wp_delete_user( $admin_user );
	}
}
