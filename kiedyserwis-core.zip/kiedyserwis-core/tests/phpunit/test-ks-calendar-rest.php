<?php
/**
 * Unit tests for the KiedySerwis Enhanced Calendar REST endpoints.
 *
 * Tests cover:
 *  - Authentication / permission checks
 *  - Date validation
 *  - Conflict detection
 *  - Audit log creation
 *  - Bulk reschedule logic
 *  - Quick-create (new custom app + device update)
 *
 * @package KiedySerwis
 * @since   1.0.0
 */

class Test_KS_Calendar_REST extends WP_UnitTestCase {

    /** @var int */
    private $user_id;

    /** @var int */
    private $device_id;

    /** @var int */
    private $other_user_id;

    public function setUp(): void {
        parent::setUp();

        // Create a serwisant user.
        $this->user_id = $this->factory->user->create( array(
            'role' => 'author',
        ) );

        // Create another user for cross-user isolation tests.
        $this->other_user_id = $this->factory->user->create( array(
            'role' => 'author',
        ) );

        // Create a device (ks_urzadzenie post) owned by $user_id.
        $this->device_id = $this->factory->post->create( array(
            'post_type'   => 'ks_urzadzenie',
            'post_author' => $this->user_id,
            'post_title'  => 'Test Device',
            'post_status' => 'publish',
        ) );

        // Set appointment meta.
        update_post_meta( $this->device_id, 'ks_app_date', '2025-06-15' );
        update_post_meta( $this->device_id, 'ks_app_time', '10:00' );
        update_post_meta( $this->device_id, 'ks_app_end_time', '11:00' );
        update_post_meta( $this->device_id, 'ks_klient_tel', '+48123456789' );
        update_post_meta( $this->device_id, 'ks_adres_urzadzenia', 'ul. Testowa 1, Gdańsk' );
    }

    public function tearDown(): void {
        wp_delete_post( $this->device_id, true );
        wp_delete_user( $this->user_id );
        wp_delete_user( $this->other_user_id );
        parent::tearDown();
    }

    // =========================================================
    // Permission check tests
    // =========================================================

    public function test_get_events_requires_login() {
        // Guest request.
        $request  = new WP_REST_Request( 'GET', '/ks/v1/events' );
        $request->set_param( 'start', '2025-06-01' );
        $request->set_param( 'end', '2025-06-30' );

        $result = ks_cal_rest_auth( $request );

        $this->assertWPError( $result );
        $this->assertEquals( 'ks_unauthorized', $result->get_error_code() );
    }

    public function test_get_events_requires_edit_posts_cap() {
        // Subscriber has no edit_posts.
        $subscriber_id = $this->factory->user->create( array( 'role' => 'subscriber' ) );
        wp_set_current_user( $subscriber_id );

        $request = new WP_REST_Request( 'GET', '/ks/v1/events' );
        $result  = ks_cal_rest_auth( $request );

        $this->assertWPError( $result );
        $this->assertEquals( 'ks_forbidden', $result->get_error_code() );

        wp_delete_user( $subscriber_id );
    }

    public function test_get_events_allowed_for_author() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'GET', '/ks/v1/events' );
        $result  = ks_cal_rest_auth( $request );

        $this->assertTrue( $result );
    }

    // =========================================================
    // GET /events validation
    // =========================================================

    public function test_get_events_rejects_invalid_date_format() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'GET', '/ks/v1/events' );
        $request->set_param( 'start', 'not-a-date' );
        $request->set_param( 'end', '2025-06-30' );

        $response = ks_cal_rest_get_events( $request );

        $this->assertWPError( $response );
        $this->assertEquals( 'ks_invalid_dates', $response->get_error_code() );
    }

    public function test_get_events_rejects_range_over_90_days() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'GET', '/ks/v1/events' );
        $request->set_param( 'start', '2025-01-01' );
        $request->set_param( 'end', '2025-12-31' );

        $response = ks_cal_rest_get_events( $request );

        $this->assertWPError( $response );
        $this->assertEquals( 'ks_range_too_large', $response->get_error_code() );
    }

    public function test_get_events_returns_event_in_range() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'GET', '/ks/v1/events' );
        $request->set_param( 'start', '2025-06-01' );
        $request->set_param( 'end', '2025-06-30' );

        $response = ks_cal_rest_get_events( $request );
        $data     = $response->get_data();

        $this->assertIsArray( $data );
        $ids = array_column( $data, 'id' );
        $this->assertContains( $this->device_id, $ids );
    }

    public function test_get_events_excludes_other_users_events() {
        wp_set_current_user( $this->other_user_id );

        $request = new WP_REST_Request( 'GET', '/ks/v1/events' );
        $request->set_param( 'start', '2025-06-01' );
        $request->set_param( 'end', '2025-06-30' );

        $response = ks_cal_rest_get_events( $request );
        $data     = $response->get_data();

        $this->assertIsArray( $data );
        $ids = array_column( $data, 'id' );
        $this->assertNotContains( $this->device_id, $ids );
    }

    public function test_get_events_redacts_phone_for_non_owner() {
        // Create event owned by user_id; fetch as other_user_id (same admin).
        // To see phone, the requester must be the author or manage_options.
        wp_set_current_user( $this->other_user_id );

        $request = new WP_REST_Request( 'GET', '/ks/v1/events' );
        $request->set_param( 'start', '2025-06-01' );
        $request->set_param( 'end', '2025-06-30' );

        // Since other_user can't see user_id's events at all in normal flow,
        // directly test ks_cal_format_event with non-owner context.
        $event = ks_cal_format_event( $this->device_id );
        $this->assertSame( '', $event['meta']['phone'], 'Phone must be redacted for non-owner.' );
    }

    public function test_get_events_exposes_phone_for_owner() {
        wp_set_current_user( $this->user_id );

        $event = ks_cal_format_event( $this->device_id );
        $this->assertEquals( '+48123456789', $event['meta']['phone'] );
    }

    // =========================================================
    // PATCH /events/{id}
    // =========================================================

    public function test_patch_event_rejects_non_owner() {
        wp_set_current_user( $this->other_user_id );

        $request = new WP_REST_Request( 'PATCH', '/ks/v1/events/' . $this->device_id );
        $request->set_url_params( array( 'id' => $this->device_id ) );
        $request->set_body( wp_json_encode( array( 'status' => 'completed' ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_patch_event( $request );

        $this->assertWPError( $response );
        $this->assertEquals( 'ks_forbidden', $response->get_error_code() );
    }

    public function test_patch_event_rejects_start_after_end() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'PATCH', '/ks/v1/events/' . $this->device_id );
        $request->set_url_params( array( 'id' => $this->device_id ) );
        $request->set_body( wp_json_encode( array(
            'start' => '2025-06-15T12:00:00',
            'end'   => '2025-06-15T10:00:00',
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_patch_event( $request );

        $this->assertWPError( $response );
        $this->assertEquals( 'ks_invalid_range', $response->get_error_code() );
    }

    public function test_patch_event_updates_date_and_time() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'PATCH', '/ks/v1/events/' . $this->device_id );
        $request->set_url_params( array( 'id' => $this->device_id ) );
        $request->set_body( wp_json_encode( array(
            'start' => '2025-06-20T14:00:00',
            'end'   => '2025-06-20T15:30:00',
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_patch_event( $request );
        $data     = $response->get_data();

        $this->assertEquals( '2025-06-20', get_post_meta( $this->device_id, 'ks_app_date', true ) );
        $this->assertEquals( '14:00', get_post_meta( $this->device_id, 'ks_app_time', true ) );
        $this->assertEquals( '15:30', get_post_meta( $this->device_id, 'ks_app_end_time', true ) );
        $this->assertEquals( '2025-06-20', $data['event']['start'] ? substr( $data['event']['start'], 0, 10 ) : '' );
    }

    public function test_patch_event_creates_audit_log() {
        wp_set_current_user( $this->user_id );

        $before_meta = get_post_meta( $this->device_id, 'ks_audit_entries' );

        $request = new WP_REST_Request( 'PATCH', '/ks/v1/events/' . $this->device_id );
        $request->set_url_params( array( 'id' => $this->device_id ) );
        $request->set_body( wp_json_encode( array( 'status' => 'completed' ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        ks_cal_rest_patch_event( $request );

        $after_meta = get_post_meta( $this->device_id, 'ks_audit_entries' );
        $this->assertGreaterThan( count( $before_meta ), count( $after_meta ),
            'An audit entry should be created on PATCH.' );

        $last_entry = json_decode( end( $after_meta ), true );
        $this->assertEquals( 'update', $last_entry['change_type'] );
        $this->assertEquals( $this->user_id, $last_entry['changed_by'] );
    }

    // =========================================================
    // Conflict detection
    // =========================================================

    public function test_conflict_detection_returns_overlapping_event() {
        wp_set_current_user( $this->user_id );

        // Second device with same time slot.
        $device2 = $this->factory->post->create( array(
            'post_type'   => 'ks_urzadzenie',
            'post_author' => $this->user_id,
            'post_title'  => 'Conflicting Device',
            'post_status' => 'publish',
        ) );
        update_post_meta( $device2, 'ks_app_date', '2025-06-15' );
        update_post_meta( $device2, 'ks_app_time', '10:30' );
        update_post_meta( $device2, 'ks_app_end_time', '11:30' );

        // Try patching device_id to overlap device2.
        $request = new WP_REST_Request( 'PATCH', '/ks/v1/events/' . $this->device_id );
        $request->set_url_params( array( 'id' => $this->device_id ) );
        $request->set_body( wp_json_encode( array(
            'start' => '2025-06-15T10:00:00',
            'end'   => '2025-06-15T11:30:00',
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_patch_event( $request );

        // Should return 409.
        $this->assertInstanceOf( WP_REST_Response::class, $response );
        $this->assertEquals( 409, $response->get_status() );
        $data = $response->get_data();
        $this->assertEquals( 'ks_conflict', $data['code'] );
        $this->assertNotEmpty( $data['conflicts'] );

        wp_delete_post( $device2, true );
    }

    public function test_conflict_force_flag_bypasses_conflict_check() {
        wp_set_current_user( $this->user_id );

        $device2 = $this->factory->post->create( array(
            'post_type'   => 'ks_urzadzenie',
            'post_author' => $this->user_id,
            'post_title'  => 'Conflicting Device 2',
            'post_status' => 'publish',
        ) );
        update_post_meta( $device2, 'ks_app_date', '2025-06-15' );
        update_post_meta( $device2, 'ks_app_time', '10:30' );
        update_post_meta( $device2, 'ks_app_end_time', '11:30' );

        $request = new WP_REST_Request( 'PATCH', '/ks/v1/events/' . $this->device_id );
        $request->set_url_params( array( 'id' => $this->device_id ) );
        $request->set_body( wp_json_encode( array(
            'start' => '2025-06-15T10:00:00',
            'end'   => '2025-06-15T11:30:00',
            'force' => true,
            'note'  => 'Emergency override',
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_patch_event( $request );

        // Should succeed (2xx).
        $this->assertNotWPError( $response );
        $this->assertLessThan( 300, $response->get_status() );
        $data = $response->get_data();
        $this->assertTrue( $data['forced'] );

        wp_delete_post( $device2, true );
    }

    // =========================================================
    // POST /events/quick-create
    // =========================================================

    public function test_quick_create_creates_custom_appointment() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'POST', '/ks/v1/events/quick-create' );
        $request->set_body( wp_json_encode( array(
            'title'   => 'Nowa Wizyta',
            'start'   => '2025-07-10T09:00:00',
            'end'     => '2025-07-10T10:00:00',
            'address' => 'ul. Nowa 5, Sopot',
            'notes'   => 'Testowe notatki',
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_quick_create( $request );
        $this->assertEquals( 201, $response->get_status() );

        $data = $response->get_data();
        $this->assertArrayHasKey( 'id', $data );
        $new_id = $data['id'];

        $this->assertEquals( 'true', get_post_meta( $new_id, 'ks_is_custom_app', true ) );
        $this->assertEquals( '2025-07-10', get_post_meta( $new_id, 'ks_app_date', true ) );
        $this->assertEquals( '09:00', get_post_meta( $new_id, 'ks_app_time', true ) );
        $this->assertEquals( 'Nowa Wizyta', get_the_title( $new_id ) );

        wp_delete_post( $new_id, true );
    }

    public function test_quick_create_rejects_start_after_end() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'POST', '/ks/v1/events/quick-create' );
        $request->set_body( wp_json_encode( array(
            'title' => 'Bad Times',
            'start' => '2025-07-10T11:00:00',
            'end'   => '2025-07-10T09:00:00',
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_quick_create( $request );

        $this->assertWPError( $response );
        $this->assertEquals( 'ks_invalid_range', $response->get_error_code() );
    }

    public function test_quick_create_updates_existing_device_appointment() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'POST', '/ks/v1/events/quick-create' );
        $request->set_body( wp_json_encode( array(
            'device_id' => $this->device_id,
            'start'     => '2025-08-05T08:00:00',
            'end'       => '2025-08-05T09:00:00',
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_quick_create( $request );
        $this->assertNotWPError( $response );

        $data = $response->get_data();
        $this->assertEquals( $this->device_id, $data['id'] );
        $this->assertEquals( '2025-08-05', get_post_meta( $this->device_id, 'ks_app_date', true ) );
    }

    public function test_quick_create_rejects_foreign_device() {
        wp_set_current_user( $this->other_user_id );

        $request = new WP_REST_Request( 'POST', '/ks/v1/events/quick-create' );
        $request->set_body( wp_json_encode( array(
            'device_id' => $this->device_id, // owned by $user_id, not $other_user_id
            'start'     => '2025-08-05T08:00:00',
            'end'       => '2025-08-05T09:00:00',
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_quick_create( $request );

        $this->assertWPError( $response );
        $this->assertEquals( 'ks_forbidden', $response->get_error_code() );
    }

    // =========================================================
    // POST /events/bulk-reschedule
    // =========================================================

    public function test_bulk_reschedule_shifts_events() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'POST', '/ks/v1/events/bulk-reschedule' );
        $request->set_body( wp_json_encode( array(
            'ids'   => array( $this->device_id ),
            'delta' => array( 'days' => 1, 'hours' => 0 ),
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_bulk_reschedule( $request );
        $this->assertNotWPError( $response );

        $data    = $response->get_data();
        $results = $data['results'];
        $this->assertCount( 1, $results );
        $this->assertEquals( 'ok', $results[0]['status'] );
        $this->assertEquals( '2025-06-16', get_post_meta( $this->device_id, 'ks_app_date', true ) );
    }

    public function test_bulk_reschedule_rejects_empty_ids() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'POST', '/ks/v1/events/bulk-reschedule' );
        $request->set_body( wp_json_encode( array(
            'ids'   => array(),
            'delta' => array( 'days' => 1 ),
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_bulk_reschedule( $request );
        $this->assertWPError( $response );
        $this->assertEquals( 'ks_missing_ids', $response->get_error_code() );
    }

    public function test_bulk_reschedule_rejects_zero_delta() {
        wp_set_current_user( $this->user_id );

        $request = new WP_REST_Request( 'POST', '/ks/v1/events/bulk-reschedule' );
        $request->set_body( wp_json_encode( array(
            'ids'   => array( $this->device_id ),
            'delta' => array( 'days' => 0, 'hours' => 0 ),
        ) ) );
        $request->set_header( 'Content-Type', 'application/json' );

        $response = ks_cal_rest_bulk_reschedule( $request );
        $this->assertWPError( $response );
        $this->assertEquals( 'ks_zero_delta', $response->get_error_code() );
    }

    // =========================================================
    // Helpers
    // =========================================================

    private function assertWPError( $result, string $msg = '' ) {
        $this->assertInstanceOf( WP_Error::class, $result, $msg ?: 'Expected WP_Error' );
    }

    private function assertNotWPError( $result, string $msg = '' ) {
        $this->assertNotInstanceOf( WP_Error::class, $result, $msg ?: 'Expected non-WP_Error' );
    }
}
