/**
 * Cypress E2E tests for the KiedySerwis Enhanced Calendar.
 *
 * These tests assume:
 *  - WordPress site running at Cypress.env('BASE_URL') (or CYPRESS_BASE_URL)
 *  - Feature flag ks_use_new_calendar is enabled
 *  - Test user has at least one upcoming appointment in the next 7 days
 *
 * Run: npx cypress run --config-file tests/cypress/cypress.config.js
 */

const DASHBOARD = Cypress.env('DASHBOARD_PATH') || '/panel-serwisanta/';
const WP_USER   = Cypress.env('WP_USERNAME');
const WP_PASS   = Cypress.env('WP_PASSWORD');

// ---------------------------------------------------------------------------
// Helper: log in via wp-login.php form
// ---------------------------------------------------------------------------
function wpLogin() {
    cy.visit('/wp-login.php');
    cy.get('#user_login').clear().type(WP_USER);
    cy.get('#user_pass').clear().type(WP_PASS);
    cy.get('#wp-submit').click();
    cy.url().should('not.include', 'wp-login.php');
}

// ---------------------------------------------------------------------------
// Helper: navigate to the calendar tab
// ---------------------------------------------------------------------------
function openCalendarTab() {
    cy.visit(DASHBOARD + '?ks_tab=calendar');
    // Wait for FullCalendar to render.
    cy.get('#ks-new-calendar .fc', { timeout: 15000 }).should('be.visible');
}

// ===========================================================================
// Suite 1: Desktop – week view
// ===========================================================================
describe('Desktop Calendar – Week View', { viewportWidth: 1280, viewportHeight: 800 }, () => {

    before(() => { wpLogin(); });

    it('renders the week view by default on desktop', () => {
        openCalendarTab();
        cy.get('#ks-new-calendar .fc-timeGridWeek-view, #ks-new-calendar .fc-timegrid')
            .should('exist');
    });

    it('shows event blocks on the time grid', () => {
        openCalendarTab();
        // At least one event block must exist (test data prerequisite).
        cy.get('#ks-new-calendar .ks-fc-event', { timeout: 8000 }).should('have.length.gte', 1);
    });

    it('navigates to the next week and back', () => {
        openCalendarTab();
        cy.get('.fc-next-button').click();
        cy.get('.fc-toolbar-title').should('not.be.empty');
        cy.get('.fc-prev-button').click();
    });

    it('opens the event detail modal on click', () => {
        openCalendarTab();
        cy.get('#ks-new-calendar .ks-fc-event').first().click();
        cy.get('#ks-cal-modal').should('be.visible');
        cy.get('#ks-cal-modal .ks-detail-title').should('not.be.empty');
    });

    it('closes the detail modal with the Escape key', () => {
        openCalendarTab();
        cy.get('#ks-new-calendar .ks-fc-event').first().click();
        cy.get('#ks-cal-modal').should('be.visible');
        cy.get('body').type('{esc}');
        cy.get('#ks-cal-modal').should('not.be.visible');
    });

    it('closes the detail modal with the ✕ close button', () => {
        openCalendarTab();
        cy.get('#ks-new-calendar .ks-fc-event').first().click();
        cy.get('#ks-cal-modal .ks-close-btn').click();
        cy.get('#ks-cal-modal').should('not.be.visible');
    });
});

// ===========================================================================
// Suite 2: Desktop – drag & drop
// ===========================================================================
describe('Desktop Calendar – Drag & Drop', { viewportWidth: 1280, viewportHeight: 800 }, () => {

    before(() => { wpLogin(); });

    it('intercepts PATCH request on event drop and shows no JS errors', () => {
        openCalendarTab();

        cy.intercept('PATCH', '**/ks/v1/events/*').as('patchEvent');

        // Drag first event block by one row (30 min slot height).
        cy.get('#ks-new-calendar .ks-fc-event').first().then(($event) => {
            const rect = $event[0].getBoundingClientRect();
            cy.wrap($event)
                .trigger('mousedown', { button: 0, clientX: rect.x + 10, clientY: rect.y + 10 })
                .trigger('mousemove', { clientX: rect.x + 10, clientY: rect.y + 40 })
                .trigger('mouseup',   { clientX: rect.x + 10, clientY: rect.y + 40 });
        });

        cy.wait('@patchEvent', { timeout: 10000 }).its('request.body').should('have.property', 'start');
    });
});

// ===========================================================================
// Suite 3: Quick-create (FAB)
// ===========================================================================
describe('Desktop Calendar – Quick-Create', { viewportWidth: 1280, viewportHeight: 800 }, () => {

    before(() => { wpLogin(); });

    it('opens the quick-create modal when FAB is clicked', () => {
        openCalendarTab();
        cy.get('#ks-cal-fab').click();
        cy.get('#ks-cal-quick-modal').should('be.visible');
        cy.get('#ks-qc-title').should('be.visible');
    });

    it('creates a new appointment via quick-create form', () => {
        openCalendarTab();

        cy.intercept('POST', '**/ks/v1/events/quick-create').as('quickCreate');

        cy.get('#ks-cal-fab').click();
        cy.get('#ks-qc-title').type('E2E Test Wizyta');
        cy.get('#ks-qc-start').type('2099-03-15T10:00');
        cy.get('#ks-qc-end').type('2099-03-15T11:00');
        cy.get('#ks-qc-address').type('ul. E2E 1, Testowo');
        cy.get('#ks-cal-quick-form').submit();

        cy.wait('@quickCreate').then((interception) => {
            expect(interception.response.statusCode).to.eq(201);
            expect(interception.response.body).to.have.property('id');
        });

        // Modal should close.
        cy.get('#ks-cal-quick-modal').should('not.be.visible');
        // Toast should confirm success.
        cy.get('.ks-toast-success').should('be.visible');
    });
});

// ===========================================================================
// Suite 4: Conflict detection
// ===========================================================================
describe('Desktop Calendar – Conflict Detection', { viewportWidth: 1280, viewportHeight: 800 }, () => {

    before(() => { wpLogin(); });

    it('shows conflict dialog when PATCH returns 409', () => {
        openCalendarTab();

        // Stub PATCH to return a 409 conflict.
        cy.intercept('PATCH', '**/ks/v1/events/*', {
            statusCode: 409,
            body: {
                code:      'ks_conflict',
                message:   'Wykryto nakładające się wizyty.',
                conflicts: [
                    { id: 99999, title: 'Istniejąca Wizyta', start: '2025-06-15T10:00:00' }
                ]
            }
        }).as('conflictPatch');

        cy.get('#ks-new-calendar .ks-fc-event').first().then(($event) => {
            const rect = $event[0].getBoundingClientRect();
            cy.wrap($event)
                .trigger('mousedown', { button: 0, clientX: rect.x + 10, clientY: rect.y + 10 })
                .trigger('mousemove', { clientX: rect.x + 10, clientY: rect.y + 60 })
                .trigger('mouseup',   { clientX: rect.x + 10, clientY: rect.y + 60 });
        });

        cy.get('#ks-cal-conflict-modal').should('be.visible');
        cy.get('.ks-conflict-list li').should('have.length.gte', 1);
    });

    it('cancels the conflict and reverts the event', () => {
        cy.get('#ks-conflict-cancel').click();
        cy.get('#ks-cal-conflict-modal').should('not.be.visible');
    });

    it('forces the conflict and sends force=true to PATCH', () => {
        openCalendarTab();

        cy.intercept('PATCH', '**/ks/v1/events/*', (req) => {
            if (!req.body.force) {
                req.reply({
                    statusCode: 409,
                    body: {
                        code:      'ks_conflict',
                        message:   'Conflict',
                        conflicts: [{ id: 99999, title: 'Conflicting', start: '2025-06-15T10:00:00' }]
                    }
                });
            } else {
                req.reply({
                    statusCode: 200,
                    body: { event: { id: 1, status: 'scheduled' }, forced: true }
                });
            }
        }).as('forcedPatch');

        cy.get('#ks-new-calendar .ks-fc-event').first().then(($event) => {
            const rect = $event[0].getBoundingClientRect();
            cy.wrap($event)
                .trigger('mousedown', { button: 0, clientX: rect.x + 10, clientY: rect.y + 10 })
                .trigger('mousemove', { clientX: rect.x + 10, clientY: rect.y + 60 })
                .trigger('mouseup',   { clientX: rect.x + 10, clientY: rect.y + 60 });
        });

        cy.get('#ks-cal-conflict-modal').should('be.visible');
        cy.get('#ks-conflict-note').type('Awaryjne nadpisanie');
        cy.get('#ks-conflict-force').click();

        cy.wait('@forcedPatch').then((interception) => {
            if (interception.request.body.force) {
                expect(interception.request.body.force).to.eq(true);
            }
        });
    });
});

// ===========================================================================
// Suite 5: Bulk reschedule
// ===========================================================================
describe('Desktop Calendar – Bulk Reschedule', { viewportWidth: 1280, viewportHeight: 800 }, () => {

    before(() => { wpLogin(); });

    it('sends bulk-reschedule request with correct delta', () => {
        openCalendarTab();

        cy.intercept('POST', '**/ks/v1/events/bulk-reschedule').as('bulkReschedule');

        // Manually trigger bulkReschedule via exposed function (workaround without event selection UI).
        cy.window().then((win) => {
            // Inject a selected ID into the module (testing via triggering the button if visible).
            // If the bulk bar is hidden, skip this test gracefully.
            win.document.getElementById('ks-cal-bulk-bar').style.display = 'flex';
            win.document.querySelector('.ks-bulk-count').textContent = '1 zaznaczone';
        });

        cy.get('#ks-bulk-next-day').click();

        cy.wait('@bulkReschedule', { timeout: 8000 }).then((interception) => {
            expect(interception.request.body).to.have.property('delta');
            expect(interception.request.body.delta.days).to.eq(1);
        });
    });
});

// ===========================================================================
// Suite 6: Mobile – list view + bottom-sheet + swipe-to-done
// ===========================================================================
describe('Mobile Calendar – List View', { viewportWidth: 390, viewportHeight: 844 }, () => {

    before(() => { wpLogin(); });

    it('renders the list view on mobile', () => {
        openCalendarTab();
        cy.get('#ks-new-calendar .fc-listWeek-view, #ks-new-calendar .fc-list')
            .should('exist');
    });

    it('opens the bottom-sheet on event click (mobile)', () => {
        openCalendarTab();
        cy.get('#ks-new-calendar .ks-fc-list-item').first().click({ force: true });
        cy.get('#ks-cal-sheet').should('have.class', 'open');
        cy.get('#ks-cal-sheet .ks-detail-title').should('not.be.empty');
    });

    it('closes the bottom-sheet with the close button', () => {
        cy.get('#ks-cal-sheet .ks-sheet-close').click();
        cy.get('#ks-cal-sheet').should('not.have.class', 'open');
    });

    it('marks event done via swipe-right gesture', () => {
        openCalendarTab();

        cy.intercept('PATCH', '**/ks/v1/events/*').as('markDone');

        // Simulate swipe-right on the first list item.
        cy.get('#ks-new-calendar .ks-fc-list-item').first().then(($el) => {
            const rect = $el[0].getBoundingClientRect();
            cy.wrap($el)
                .trigger('touchstart', { touches: [{ clientX: rect.left + 20, clientY: rect.top + 20 }] })
                .trigger('touchend',   { changedTouches: [{ clientX: rect.left + 20 + 120, clientY: rect.top + 20 }] });
        });

        cy.wait('@markDone', { timeout: 8000 }).then((interception) => {
            expect(interception.request.body).to.have.property('status', 'completed');
        });

        // Success toast should appear.
        cy.get('.ks-toast-success').should('be.visible');
    });

    it('shows FAB on mobile', () => {
        openCalendarTab();
        cy.get('#ks-cal-fab').should('be.visible');
    });

    it('opens quick-create modal when FAB tapped on mobile', () => {
        openCalendarTab();
        cy.get('#ks-cal-fab').click();
        cy.get('#ks-cal-quick-modal').should('be.visible');
    });
});

// ===========================================================================
// Suite 7: ICS export
// ===========================================================================
describe('Calendar – ICS Export', { viewportWidth: 1280, viewportHeight: 800 }, () => {

    before(() => { wpLogin(); });

    it('triggers a file download when "Pobierz ICS" is clicked', () => {
        openCalendarTab();
        cy.get('#ks-new-calendar .ks-fc-event').first().click();
        cy.get('#ks-cal-modal').should('be.visible');

        // ICS download is a blob URL click – verify the button exists and is clickable.
        cy.get('#ks-cal-modal .ks-btn-ics').should('be.visible').click();
        // No assertion on the file itself (Cypress doesn't assert blob downloads easily),
        // but we verify no error toast appears.
        cy.get('.ks-toast-error').should('not.exist');
    });
});

// ===========================================================================
// Suite 8: Feature flag toggle
// ===========================================================================
describe('Feature Flag Toggle', { viewportWidth: 1280, viewportHeight: 800 }, () => {

    before(() => { wpLogin(); });

    it('legacy calendar is hidden when new calendar is active', () => {
        openCalendarTab();
        // Legacy container should not exist.
        cy.get('.ks-calendar-container').should('not.exist');
        cy.get('#ks-new-calendar-root').should('be.visible');
    });
});

// ===========================================================================
// Suite 9: Accessibility
// ===========================================================================
describe('Calendar – Accessibility', { viewportWidth: 1280, viewportHeight: 800 }, () => {

    before(() => { wpLogin(); });

    it('modal has aria-modal and role=dialog attributes', () => {
        openCalendarTab();
        cy.get('#ks-cal-modal').should('have.attr', 'role', 'dialog');
        cy.get('#ks-cal-modal').should('have.attr', 'aria-modal', 'true');
    });

    it('FAB has aria-label', () => {
        openCalendarTab();
        cy.get('#ks-cal-fab').should('have.attr', 'aria-label');
    });

    it('filter controls have aria-label', () => {
        openCalendarTab();
        cy.get('#ks-cal-filters').should('have.attr', 'aria-label');
    });
});
