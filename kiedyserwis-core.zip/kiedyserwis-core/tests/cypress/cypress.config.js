/**
 * Cypress configuration for KiedySerwis calendar E2E tests.
 *
 * Set these environment variables before running:
 *   CYPRESS_BASE_URL      – WordPress site URL (e.g. http://localhost:8080)
 *   CYPRESS_WP_USERNAME   – Test user login
 *   CYPRESS_WP_PASSWORD   – Test user password
 *   CYPRESS_DASHBOARD_URL – URL of the serwisant dashboard page (e.g. /panel-serwisanta/)
 */
const { defineConfig } = require('cypress');

module.exports = defineConfig({
    e2e: {
        baseUrl:           process.env.CYPRESS_BASE_URL || 'http://localhost:8080',
        specPattern:       'tests/cypress/e2e/**/*.cy.js',
        supportFile:       false,
        viewportWidth:     1280,
        viewportHeight:    800,
        video:             false,
        screenshotOnRunFailure: true,
        defaultCommandTimeout: 10000,
        env: {
            WP_USERNAME:    process.env.CYPRESS_WP_USERNAME    || 'admin',
            WP_PASSWORD:    process.env.CYPRESS_WP_PASSWORD    || 'password',
            DASHBOARD_PATH: process.env.CYPRESS_DASHBOARD_PATH || '/panel-serwisanta/',
        }
    }
});
