<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$action = isset( $_GET['ks_action'] ) ? sanitize_text_field( $_GET['ks_action'] ) : 'login';
$reg_status = isset( $_GET['reg_status'] ) ? sanitize_text_field( $_GET['reg_status'] ) : '';
$reg_error = isset( $_GET['reg_error'] ) ? sanitize_text_field( $_GET['reg_error'] ) : '';
$login_error = isset( $_GET['login_error'] ) ? sanitize_text_field( $_GET['login_error'] ) : '';
?>

<style>
	:root {
		--ks-primary: #4F46E5;
		--ks-primary-hover: #4338CA;
		--ks-bg: #F9FAFB;
		--ks-text-main: #111827;
		--ks-text-muted: #6B7280;
	}
	.ks-auth-container {
		max-width: 440px;
		margin: 60px auto;
		padding: 40px;
		background: #ffffff;
		border-radius: 20px;
		box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
		font-family: 'Inter', system-ui, -apple-system, sans-serif;
	}
	.ks-auth-header {
		text-align: center;
		margin-bottom: 32px;
	}
	.ks-auth-header i {
		color: var(--ks-primary);
		margin-bottom: 16px;
	}
	.ks-auth-container h2 {
		color: var(--ks-text-main);
		font-size: 1.875rem;
		font-weight: 800;
		letter-spacing: -0.025em;
		margin: 0;
	}
	.ks-auth-container p {
		color: var(--ks-text-muted);
		margin-top: 8px;
		font-size: 0.875rem;
	}
	.ks-auth-form .form-group {
		margin-bottom: 20px;
	}
	.ks-auth-form label {
		display: block;
		margin-bottom: 6px;
		font-weight: 600;
		font-size: 0.875rem;
		color: var(--ks-text-main);
	}
	.ks-auth-form input[type="text"],
	.ks-auth-form input[type="email"],
	.ks-auth-form input[type="password"] {
		width: 100%;
		padding: 12px 16px;
		border: 1px solid #D1D5DB;
		border-radius: 10px;
		box-sizing: border-box;
		font-size: 1rem;
		transition: border-color 0.2s, ring 0.2s;
	}
	.ks-auth-form input:focus {
		outline: none;
		border-color: var(--ks-primary);
		box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
	}
	.ks-auth-btn {
		width: 100%;
		padding: 12px;
		background: var(--ks-primary);
		color: #fff;
		border: none;
		border-radius: 10px;
		font-weight: 600;
		font-size: 1rem;
		cursor: pointer;
		margin-top: 8px;
		transition: background 0.2s;
	}
	.ks-auth-btn:hover {
		background: var(--ks-primary-hover);
	}
	.ks-auth-switch {
		text-align: center;
		margin-top: 24px;
		font-size: 0.875rem;
		color: var(--ks-text-muted);
	}
	.ks-auth-switch a {
		color: var(--ks-primary);
		text-decoration: none;
		font-weight: 600;
	}
	.ks-alert {
		padding: 16px;
		border-radius: 12px;
		margin-bottom: 24px;
		font-size: 0.875rem;
		line-height: 1.5;
		display: flex;
		gap: 12px;
		align-items: flex-start;
	}
	.ks-alert-success { background: #ECFDF5; color: #065F46; border: 1px solid #A7F3D0; }
	.ks-alert-error { background: #FEF2F2; color: #991B1B; border: 1px solid #FECACA; }
	.ks-alert-info { background: #EFF6FF; color: #1E40AF; border: 1px solid #BFDBFE; }
</style>

<div class="ks-auth-container">
	<?php
	// Global Messages Display
	if ( $reg_status === 'check_email' ) : ?>
		<div class="ks-alert ks-alert-info">
			<i data-lucide="info" style="flex-shrink:0; width:20px; height:20px;"></i>
			<span><strong>Rejestracja prawie gotowa!</strong> Wysłaliśmy link potwierdzający na Twój e-mail. Sprawdź skrzynkę i kliknij w link, aby ustawić hasło.</span>
		</div>
	<?php elseif ( $reg_status === 'activated' ) : ?>
		<div class="ks-alert ks-alert-success">
			<i data-lucide="check-circle" style="flex-shrink:0; width:20px; height:20px;"></i>
			<span><strong>Konto aktywne!</strong> Twoje konto zostało aktywowane. Możesz się teraz zalogować.</span>
		</div>
	<?php elseif ( $reg_status === 'error' || $reg_error ) : ?>
		<div class="ks-alert ks-alert-error">
			<i data-lucide="alert-circle" style="flex-shrink:0; width:20px; height:20px;"></i>
			<span><strong>Wystąpił błąd!</strong>
			<?php
			if ( $reg_error === 'no_terms' ) {
				echo 'Musisz zaakceptować Regulamin oraz Politykę Prywatności, aby się zarejestrować.';
			} elseif ( $reg_error === 'email_exists' ) {
				echo 'Podany adres e-mail jest już zarejestrowany. Zaloguj się lub użyj innego e-maila.';
			} elseif ( $reg_error === 'invalid_data' ) {
				echo 'Wprowadzone dane są nieprawidłowe. Sprawdź poprawność e-maila i nazwy firmy.';
			} else {
				echo 'Wystąpił błąd podczas rejestracji. Spróbuj ponownie lub skontaktuj się z nami.';
			}
			?>
			</span>
		</div>
	<?php endif; ?>

	<?php if ( $action === 'verify' ) :
		$key = sanitize_text_field( $_GET['ks_key'] );
		?>
		<div class="ks-auth-header">
			<i data-lucide="key-round" style="width:48px; height:48px;"></i>
			<h2>Ustaw hasło</h2>
			<p>Dokończ konfigurację konta ustawiając bezpieczne hasło.</p>
		</div>

		<?php if ( isset($_GET['error']) && $_GET['error'] === 'mismatch' ) : ?>
			<div class="ks-alert ks-alert-error">
				<i data-lucide="x-circle" style="flex-shrink:0; width:20px; height:20px;"></i>
				<span>Hasła nie są identyczne. Spróbuj ponownie.</span>
			</div>
		<?php endif; ?>

		<form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post" class="ks-auth-form">
			<input type="hidden" name="action" value="ks_activate">
			<input type="hidden" name="activation_key" value="<?php echo esc_attr( $key ); ?>">
			<?php wp_nonce_field( 'ks_set_password', 'ks_activation_nonce' ); ?>

			<div class="form-group">
				<label>Nowe hasło</label>
				<input type="password" name="pass1" required placeholder="••••••••">
			</div>
			<div class="form-group">
				<label>Powtórz hasło</label>
				<input type="password" name="pass2" required placeholder="••••••••">
			</div>
			<button type="submit" class="ks-auth-btn">AKTYWUJ KONTO</button>
		</form>

	<?php elseif ( $action === 'register' ) : ?>
		<div class="ks-auth-header">
			<i data-lucide="user-plus" style="width:48px; height:48px;"></i>
			<h2>Dołącz do nas</h2>
			<p>Zarejestruj swoją firmę i zacznij zarządzać serwisami.</p>
		</div>

		<?php if ( $reg_status !== 'check_email' ) : ?>
		<form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post" class="ks-auth-form">
			<input type="hidden" name="action" value="ks_register">
			<?php wp_nonce_field( 'ks_user_registration', 'ks_reg_nonce' ); ?>

			<div class="form-group">
				<label>Nazwa Twojej firmy</label>
				<input type="text" name="user_company_name" required placeholder="np. Hydro-Serwis">
			</div>
			<div class="form-group">
				<label>Firmowy numer telefonu</label>
				<input type="tel" name="user_company_phone" required placeholder="np. 500 100 200">
				<small style="color:var(--ks-text-muted, #6B7280); font-size:0.8125rem; margin-top:4px; display:block;">*Numer służący do kontaktu z Twoją firmą w celu umawiania serwisów.</small>
			</div>
			<div class="form-group">
				<label>Adres E-mail</label>
				<input type="email" name="user_email" required placeholder="jan@przyklad.pl">
			</div>
			<div class="form-group">
				<label>Kod polecającego <span style="font-weight:400; color:var(--ks-text-muted);">(opcjonalny)</span></label>
				<input type="text" name="ks_referral_code" placeholder="np. ab92d" maxlength="5" autocomplete="off" style="text-transform:lowercase;">
				<small style="color:var(--ks-text-muted, #6B7280); font-size:0.8125rem; margin-top:4px; display:block;">*Wpisz jeśli posiadasz kod od innego serwisanta.</small>
			</div>
			<div class="form-group" style="margin-top:8px;">
				<label style="display:flex; align-items:flex-start; gap:10px; font-weight:400; cursor:pointer; line-height:1.5;">
					<input type="checkbox" name="ks_terms_consent" value="1" required style="margin-top:3px; flex-shrink:0; accent-color:#4F46E5; width:16px; height:16px;">
					<span style="font-size:0.8125rem; color:var(--ks-text-main);">Akceptuję <a href="https://kiedyserwis.pl/regulamin" target="_blank" rel="noopener noreferrer" style="color:#4F46E5; font-weight:600;">Regulamin</a> oraz <a href="https://kiedyserwis.pl/polityka-prywatnosci" target="_blank" rel="noopener noreferrer" style="color:#4F46E5; font-weight:600;">Politykę Prywatności</a>, której integralną częścią jest umowa powierzenia przetwarzania danych osobowych. Oświadczam, że chcę korzystać z KiedySerwis.pl w celach związanych z moją działalnością gospodarczą. <span style="color:#DC2626; font-weight:700;">(wymagane)</span></span>
				</label>
			</div>
			<div class="form-group" style="margin-top:4px;">
				<label style="display:flex; align-items:flex-start; gap:10px; font-weight:400; cursor:pointer; line-height:1.5;">
					<input type="checkbox" name="ks_newsletter_consent" value="1" style="margin-top:3px; flex-shrink:0; accent-color:#4F46E5; width:16px; height:16px;">
					<span style="font-size:0.8125rem; color:var(--ks-text-muted);">Chcę otrzymywać newsletter KiedySerwis.pl z informacjami o nowych funkcjach i promocjach na podany adres e-mail podczas rejestracji. <span style="color:var(--ks-text-muted);">(opcjonalne)</span></span>
				</label>
			</div>
			<button type="submit" class="ks-auth-btn">ZAREJESTRUJ SIĘ</button>
		</form>
		<?php endif; ?>

		<div class="ks-auth-switch">
			Masz już konto? <a href="?ks_action=login">Zaloguj się</a>
		</div>

	<?php else : // Login by default ?>
		<div class="ks-auth-header">
			<i data-lucide="wrench" style="width:48px; height:48px;"></i>
			<h2>Witaj ponownie</h2>
			<p>Zaloguj się do swojego panelu serwisanta.</p>
		</div>

		<?php if ( $login_error ) : ?>
			<div class="ks-alert ks-alert-error">
				<i data-lucide="alert-circle" style="flex-shrink:0; width:20px; height:20px;"></i>
				<span>
					<?php
					if ( $login_error === 'pending' ) {
						echo 'Konto nieaktywne. Sprawdź e-mail z linkiem aktywacyjnym.';
					} else {
						echo 'Nieprawidłowy e-mail lub hasło.';
					}
					?>
				</span>
			</div>
		<?php endif; ?>

		<form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post" class="ks-auth-form">
			<input type="hidden" name="action" value="ks_login">
			<?php wp_nonce_field( 'ks_user_login', 'ks_login_nonce' ); ?>

			<div class="form-group">
				<label>E-mail</label>
				<input type="text" name="log" required placeholder="jan@przyklad.pl">
			</div>
			<div class="form-group">
				<label>Hasło</label>
				<input type="password" name="pwd" required placeholder="••••••••">
			</div>
			<div class="form-group" style="display: flex; align-items: center; justify-content: space-between;">
				<label style="display: flex; align-items: center; gap: 8px; font-weight: 500; cursor: pointer;">
					<input name="rememberme" type="checkbox" value="forever"> Zapamiętaj mnie
				</label>
				<a href="<?php echo wp_lostpassword_url(); ?>" style="font-size: 0.8125rem; color: var(--ks-primary); text-decoration: none; font-weight: 600;">Zapomniałeś hasła?</a>
			</div>
			<button type="submit" class="ks-auth-btn">ZALOGUJ SIĘ</button>
		</form>

		<div class="ks-auth-switch">
			Nie masz jeszcze konta? <a href="?ks_action=register">Załóż konto za darmo</a>
		</div>
	<?php endif; ?>
</div>
