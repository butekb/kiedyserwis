<?php
/**
 * Template for Premium Service Protocol module.
 * Displayed in the technician dashboard under "Protokół serwisowy".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_premium = ks_is_premium_active( $current_user_id );

if ( ! $is_premium ) :
?>
<style>
	.ks-proto-upsell { background:#fff; padding:48px; border-radius:24px; border:1px solid var(--ks-border); box-shadow:0 10px 15px -3px rgba(0,0,0,0.1); max-width:800px; margin:0 auto; }
	.ks-proto-upsell h2 { font-size:2rem; font-weight:800; letter-spacing:-0.025em; margin-bottom:16px; }
	.ks-proto-feature-grid { display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:40px; }
	@media(max-width:768px){
		.ks-proto-upsell { padding:24px; }
		.ks-proto-feature-grid { grid-template-columns:1fr; gap:16px; }
		.ks-proto-upsell h2 { font-size:1.5rem; }
	}
</style>
<div class="ks-proto-upsell">
	<div style="text-align:center; margin-bottom:40px;">
		<div style="width:80px; height:80px; background:rgba(79,70,229,0.1); border-radius:20px; display:flex; align-items:center; justify-content:center; margin:0 auto 24px;">
			<i data-lucide="file-text" style="color:var(--ks-primary); width:40px; height:40px;"></i>
		</div>
		<h2>📋 Protokół Serwisowy Premium</h2>
		<p style="font-size:1.125rem; color:var(--ks-text-muted); line-height:1.6; max-width:600px; margin:0 auto;">Generuj profesjonalne protokoły serwisowe z podpisem klienta i wysyłaj je e-mailem bezpośrednio z panelu.</p>
	</div>
	<div class="ks-proto-feature-grid">
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="check-square" style="color:var(--ks-primary);"></i> Konfigurowalna checklista</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Zdefiniuj własną listę czynności serwisowych. Każdy protokół odhaczy wykonane punkty i wydrukuje je dla klienta.</p>
		</div>
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="pen-tool" style="color:var(--ks-primary);"></i> Podpis palcem</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Klient podpisuje protokół bezpośrednio na ekranie telefonu lub tabletu – podpis trafia do e-maila.</p>
		</div>
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="mail" style="color:var(--ks-primary);"></i> Wysyłka e-mailem</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Gotowy protokół trafia na e-mail klienta w ciągu sekund – bez drukowania, bez papieru.</p>
		</div>
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="package" style="color:var(--ks-primary);"></i> Integracja z Magazynem</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Oznacz zużyte części – stan magazynu aktualizuje się automatycznie po wysłaniu protokołu.</p>
		</div>
	</div>
	<div style="text-align:center;">
		<a href="?ks_tab=plan" class="ks-btn-primary" style="padding:16px 40px; font-size:1.125rem; border-radius:12px; max-width:100%; box-sizing:border-box;">AKTYWUJ PAKIET PREMIUM</a>
	</div>
</div>
<?php else :
	// ─── Premium: Protocol module ───
	$protokol_saved  = isset( $_GET['protokol_saved'] );
	$proto_sent      = isset( $_GET['proto_sent'] );
	$proto_error     = isset( $_GET['proto_error'] );

	// Read settings from plain-text meta (no JSON)
	$is_enabled      = get_user_meta( $current_user_id, 'ks_protocol_enabled', true ) === '1';
	$checklist_raw   = get_user_meta( $current_user_id, 'ks_protocol_checklist', true );
	$checklist       = $checklist_raw
		? array_values( array_filter( array_map( 'trim', explode( "\n", $checklist_raw ) ) ) )
		: array();
	$footer_note     = get_user_meta( $current_user_id, 'ks_protocol_footer', true );
	$company_logo_id = get_user_meta( $current_user_id, 'ks_company_logo', true );
	$company_logo    = $company_logo_id ? wp_get_attachment_image_url( (int) $company_logo_id, 'medium' ) : '';

	// Protocol company stamp data (ks_protokol_* prefix for new fields)
	$proto_company_name    = get_user_meta( $current_user_id, 'ks_protokol_company_name', true )
		?: get_user_meta( $current_user_id, 'ks_company_name', true );
	$proto_company_address = get_user_meta( $current_user_id, 'ks_protokol_company_address', true );
	$proto_company_nip     = get_user_meta( $current_user_id, 'ks_protokol_company_nip', true );
	$proto_company_email   = get_user_meta( $current_user_id, 'ks_protokol_company_email', true )
		?: get_the_author_meta( 'user_email', $current_user_id );
	$proto_company_phone   = get_user_meta( $current_user_id, 'ks_protokol_company_phone', true )
		?: get_user_meta( $current_user_id, 'ks_company_phone', true );
	$proto_company_contact = get_user_meta( $current_user_id, 'ks_protokol_company_contact', true );
	$technician_email      = get_the_author_meta( 'user_email', $current_user_id );

	// Devices – newest first; carry phone for search
	$user_devices = get_posts( array(
		'post_type'        => 'ks_urzadzenie',
		'author'           => $current_user_id,
		'post_status'      => 'publish',
		'posts_per_page'   => -1,
		'orderby'          => 'date',
		'order'            => 'DESC',
		'meta_query'       => array(
			array( 'key' => 'ks_is_custom_app', 'compare' => 'NOT EXISTS' ),
		),
		'suppress_filters' => false, // Allow pre_get_posts isolation to run.
	) );

	// Build device → parts-history map for smart protocol display.
	// All historically used parts (all services) are shown under "Wykonane czynności"
	// when the technician selects a device, so they appear in the email body.
	$device_parts_history = array();
	$device_extra_fields  = array(); // serial, year, phone per device
	foreach ( $user_devices as $dev ) {
		// New format: ks_parts_history (cumulative, dated entries)
		$raw = get_post_meta( $dev->ID, 'ks_parts_history', true );
		if ( $raw ) {
			$decoded = json_decode( $raw, true );
			if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) && ! empty( $decoded ) ) {
				$device_parts_history[ $dev->ID ] = $decoded;
			}
		}
		// Extra device fields for protocol (serial, year) + phone for auto-fill
		$device_extra_fields[ $dev->ID ] = array(
			'serial' => get_post_meta( $dev->ID, 'ks_device_serial', true ),
			'year'   => get_post_meta( $dev->ID, 'ks_device_year', true ),
			'phone'  => get_post_meta( $dev->ID, 'ks_klient_tel', true ),
		);
	}

	// Protocol always enabled; $can_send depends only on whether checklist has items
	$can_send = ! empty( $checklist );
	// Confirmation screen: show email address the protocol was sent to
	$proto_sent_to = isset( $_GET['proto_sent_to'] ) ? sanitize_email( wp_unslash( $_GET['proto_sent_to'] ) ) : '';
?>
<h2 class="ks-page-title" style="margin-bottom:6px;">Protokół Serwisowy</h2>
<p class="ks-page-subtitle" style="margin-bottom:28px;">Skonfiguruj wzór protokołu np. dodając najczęściej wykonywane czynności serwisowe i wysyłaj protokoły do klientów na e-mail</p>

<style>
.ks-proto-grid { display:grid; grid-template-columns:1fr 1fr; gap:28px; max-width:1100px; }
@media(max-width:900px){
	.ks-proto-grid { grid-template-columns:1fr; }
}
.ks-proto-card { min-width:0; }
.ks-proto-inner-2col { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.ks-checklist-builder { display:flex; flex-direction:column; gap:0; }
.ks-checklist-row { display:flex; align-items:center; gap:8px; padding:6px 0; border-bottom:1px solid var(--ks-border); }
.ks-checklist-row:last-child { border-bottom:none; }
.ks-checklist-row input[type="text"] { flex:1; min-width:0; border:none; outline:none; background:transparent; font-size:0.9375rem; color:var(--ks-text); padding:2px 0; }
.ks-checklist-row button { flex-shrink:0; background:none; border:none; cursor:pointer; color:var(--ks-text-muted); padding:4px; border-radius:6px; }
.ks-checklist-row button:hover { color:var(--ks-danger); background:#FFF1F2; }
.ks-add-item-row { display:flex; gap:8px; margin-top:10px; flex-wrap:wrap; }
.ks-add-item-row input[type="text"] { flex:1; min-width:160px; }
.ks-proto-section-divider { border:none; border-top:1px solid var(--ks-border); margin:20px 0; }
.ks-proto-send-btns { display:flex; gap:10px; margin-bottom:0; }
.ks-proto-settings-header { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-bottom:20px; }
.ks-proto-settings-header h3 { margin:0; }
#ks-proto-edit-btn { display:none; align-items:center; gap:6px; background:var(--ks-primary); color:#fff; border:none; border-radius:8px; padding:8px 14px; cursor:pointer; font-size:0.875rem; font-weight:600; white-space:nowrap; }
@media(max-width:600px){
	.ks-proto-card { padding:20px !important; }
	.ks-proto-inner-2col { grid-template-columns:1fr !important; gap:0 !important; }
	.ks-add-item-row input[type="text"] { min-width:0; }
	.ks-proto-send-btns { flex-direction:column; }
	.ks-proto-send-btns > button { flex:none !important; width:100% !important; }
}
/* Preview modal — horizontal scroll + full-screen on mobile */
#ks-preview-body { overflow-x:auto; -webkit-overflow-scrolling:touch; }
@media(max-width:599px){
	#ks-preview-modal { padding:0 !important; }
	#ks-preview-modal > div { border-radius:0 !important; min-height:100svh; min-height:100vh; }
}
</style>

<?php if ( $protokol_saved ) : ?>
	<div class="ks-alert-banner" style="background:var(--ks-success-light); color:var(--ks-success); border-color:var(--ks-success); margin-bottom:24px;">
		<span style="display:flex; align-items:center; gap:8px;"><i data-lucide="check-circle" style="width:18px; height:18px; flex-shrink:0;"></i> Ustawienia protokołu zostały zapisane.</span>
	</div>
<?php endif; ?>
<?php if ( $proto_sent ) : ?>
	<div class="ks-alert-banner" style="background:var(--ks-success-light); color:var(--ks-success); border-color:var(--ks-success); margin-bottom:24px;">
		<span style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
			<i data-lucide="send" style="width:18px; height:18px; flex-shrink:0;"></i>
			<strong>Protokół wysłany<?php if ( $proto_sent_to ) : ?> na: <?php echo esc_html( $proto_sent_to ); ?><?php endif; ?>!</strong>
		</span>
	</div>
<?php endif; ?>
<?php if ( $proto_error ) : ?>
	<div class="ks-alert-banner ks-alert-banner-danger" style="margin-bottom:24px;">
		<?php $proto_error_msg = isset( $_GET['proto_error'] ) ? sanitize_text_field( wp_unslash( $_GET['proto_error'] ) ) : ''; ?>
		<span style="display:flex; align-items:center; gap:8px;">
			<i data-lucide="alert-circle" style="width:18px; height:18px; flex-shrink:0;"></i>
			<?php if ( 'invalid_email' === $proto_error_msg ) : ?>
				Nieprawidłowy adres e-mail klienta. Sprawdź adres i spróbuj ponownie.
			<?php else : ?>
				Wystąpił błąd. Sprawdź dane i spróbuj ponownie.
			<?php endif; ?>
		</span>
	</div>
<?php endif; ?>

<div class="ks-proto-grid">

	<!-- SETTINGS CARD -->
	<div class="ks-proto-card" style="background:#fff; padding:32px; border-radius:20px; border:1px solid var(--ks-border); box-shadow:var(--ks-shadow);">
		<div class="ks-proto-settings-header">
			<h3 style="font-size:1.125rem; font-weight:700; display:flex; align-items:center; gap:8px;">
				<i data-lucide="settings" style="color:var(--ks-primary);"></i> Ustawienia wzorca
			</h3>
			<button type="button" id="ks-proto-edit-btn" onclick="ksToggleProtoSettings()" aria-expanded="false">
				<i data-lucide="edit" style="width:14px; height:14px;" aria-hidden="true"></i> Edytuj wzorzec
			</button>
		</div>
		<div id="ks-proto-settings-body">
		<form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">
			<input type="hidden" name="action" value="ks_save_protocol_settings">
			<?php wp_nonce_field( 'ks_save_protocol_settings', 'ks_protocol_settings_nonce' ); ?>

			<!-- Logo serwisanta -->
				<div class="ks-form-group" style="margin-bottom:20px;">
					<label style="margin-bottom:10px; display:block; font-weight:600;">Logo na protokole</label>
					<?php if ( $company_logo ) : ?>
						<div style="display:flex; align-items:center; gap:12px; padding:12px; background:#F9FAFB; border-radius:12px; border:1px solid var(--ks-border);">
							<img src="<?php echo esc_url( $company_logo ); ?>" style="height:52px; width:auto; max-width:120px; object-fit:contain; border-radius:8px;" alt="Logo firmy">
							<div style="flex:1;">
								<p style="font-size:0.875rem; color:var(--ks-text-muted); margin:0 0 6px;">Logo z Twojej wizytówki</p>
								<a href="?ks_tab=wizytowka" style="font-size:0.8125rem; color:var(--ks-primary); text-decoration:none; font-weight:600;">Zmień logo w wizytówce →</a>
							</div>
						</div>
					<?php else : ?>
						<div style="padding:14px; background:#FFF7ED; border-radius:12px; border:1px solid #FED7AA; font-size:0.875rem; color:#92400E;">
							<i data-lucide="alert-triangle" style="width:16px; height:16px; vertical-align:middle; margin-right:6px;"></i>
							Logo nie jest ustawione. <a href="?ks_tab=wizytowka" style="color:var(--ks-primary); font-weight:600;">Dodaj logo w wizytówce →</a>
						</div>
					<?php endif; ?>
				</div>

				<!-- Pełne dane firmy serwisanta (pieczątka) -->
				<hr class="ks-proto-section-divider">
				<p style="font-size:0.8125rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--ks-text-muted); margin:0 0 14px;">Pełne dane Twojej firmy</p>
				<p style="font-size:0.8125rem; color:var(--ks-text-muted); margin:-8px 0 14px;">Zastępuje papierową pieczątkę w protokole,<br>dane pojawią się w wysyłanym e-mailu.</p>
				<div class="ks-form-group">
					<label>Pełna nazwa firmy</label>
					<input type="text" name="ks_protokol_company_name" class="ks-input" value="<?php echo esc_attr( $proto_company_name ); ?>" placeholder="np. Jan Kowalski Serwis AGD">
				</div>
				<div class="ks-form-group">
					<label>Adres (ulica, kod, miasto)</label>
					<input type="text" name="ks_protokol_company_address" class="ks-input" value="<?php echo esc_attr( $proto_company_address ); ?>" placeholder="np. ul. Przykładowa 1, 00-001 Warszawa">
				</div>
				<div class="ks-proto-inner-2col">
					<div class="ks-form-group">
						<label>NIP</label>
						<input type="text" name="ks_protokol_company_nip" class="ks-input" value="<?php echo esc_attr( $proto_company_nip ); ?>" placeholder="np. 123-456-78-90">
					</div>
					<div class="ks-form-group">
						<label>Osoba kontaktowa</label>
						<input type="text" name="ks_protokol_company_contact" class="ks-input" value="<?php echo esc_attr( $proto_company_contact ); ?>" placeholder="np. Jan Kowalski">
					</div>
				</div>
				<div class="ks-proto-inner-2col">
					<div class="ks-form-group">
						<label>E-mail serwisanta</label>
						<input type="email" name="ks_protokol_company_email" class="ks-input" value="<?php echo esc_attr( $proto_company_email ); ?>" placeholder="biuro@twojafirma.pl">
					</div>
					<div class="ks-form-group">
						<label>Telefon serwisanta</label>
						<input type="text" name="ks_protokol_company_phone" class="ks-input" value="<?php echo esc_attr( $proto_company_phone ); ?>" placeholder="np. +48 123 456 789">
					</div>
				</div>

				<hr class="ks-proto-section-divider">

				<div class="ks-form-group">
					<label>Lista czynności serwisowych <span style="font-weight:400; color:var(--ks-text-muted);">(zamiast wpisywać ręcznie, będziesz mógł w protokole zaznaczyć jakie czynności zostały wykonane)</span></label>
					<div class="ks-checklist-builder" id="ks-checklist-builder">
						<?php foreach ( $checklist as $item ) : ?>
						<div class="ks-checklist-row">
							<i data-lucide="grip-vertical" style="color:var(--ks-text-muted); width:16px; height:16px; flex-shrink:0;"></i>
							<input type="text" name="ks_protocol_checklist[]" value="<?php echo esc_attr( $item ); ?>" aria-label="Czynność serwisowa: <?php echo esc_attr( $item ); ?>" required>
							<button type="button" onclick="ksRemoveChecklistRow(this)" title="Usuń czynność" aria-label="Usuń czynność"><i data-lucide="x" style="width:16px; height:16px;" aria-hidden="true"></i></button>
						</div>
						<?php endforeach; ?>
					</div>
					<div class="ks-add-item-row">
						<input type="text" id="ks-new-item" class="ks-input" placeholder="Wpisz czynność i naciśnij Dodaj…">
						<button type="button" class="ks-btn-primary" onclick="ksAddChecklistRow()" style="white-space:nowrap; padding:10px 16px; flex-shrink:0;">
							<i data-lucide="plus" style="width:16px; height:16px;" aria-hidden="true"></i> Dodaj
						</button>
					</div>
				</div>

				<div class="ks-form-group">
					<label>Stopka protokołu</label>
					<textarea name="ks_protocol_footer" class="ks-input" rows="3" placeholder="Np. Dziękujemy za skorzystanie z naszych usług. Gwarancja na wykonaną pracę: 12 miesięcy."><?php echo esc_textarea( $footer_note ); ?></textarea>
				</div>

			<button type="submit" class="ks-btn-primary" style="width:100%; justify-content:center; padding:13px;">
				<i data-lucide="save"></i> ZAPISZ WZORZEC
			</button>
		</form>
		</div><!-- /#ks-proto-settings-body -->
	</div>

	<!-- SEND PROTOCOL CARD -->
	<div class="ks-proto-card" style="background:#fff; padding:32px; border-radius:20px; border:1px solid var(--ks-border); box-shadow:var(--ks-shadow);">
		<h3 style="font-size:1.125rem; font-weight:700; margin-bottom:20px; display:flex; align-items:center; gap:8px;">
			<i data-lucide="send" style="color:var(--ks-primary);"></i> Wyślij protokół
		</h3>

		<?php if ( ! $can_send ) : ?>
			<div style="text-align:center; padding:40px 20px; color:var(--ks-text-muted);">
				<i data-lucide="list-checks" style="width:40px; height:40px; margin-bottom:16px; opacity:.4;"></i>
				<p style="font-size:0.9375rem;">Zdefiniuj listę czynności w ustawieniach wzorca i zapisz.</p>
			</div>
		<?php else : ?>
		<form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">
			<input type="hidden" name="action" value="ks_send_protocol">
			<?php wp_nonce_field( 'ks_send_protocol', 'ks_send_protocol_nonce' ); ?>

			<!-- Device selector with phone search -->
			<div class="ks-form-group">
				<label>Urządzenie <span style="font-weight:400; color:var(--ks-text-muted);">(aby wysłać protokół musisz mieć dodane urządzenie klienta w sekcji "urządzenia")</span></label>
				<input type="text" id="ks-dev-search" placeholder="Szukaj po numerze telefonu…" class="ks-input" style="margin-bottom:8px;">
				<select name="device_id" id="ks-dev-select" class="ks-input" required>
					<option value="">Wybierz urządzenie…</option>
					<?php foreach ( $user_devices as $dev ) :
						$dev_phone = get_post_meta( $dev->ID, 'ks_klient_tel', true );
						$label = esc_html( $dev->post_title );
						if ( $dev_phone ) {
							$label .= ' (' . esc_html( $dev_phone ) . ')';
						}
					?>
						<option value="<?php echo $dev->ID; ?>" data-search="<?php echo esc_attr( $dev_phone ); ?>" data-name="<?php echo esc_attr( $dev->post_title ); ?>"><?php echo $label; ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<!-- Additional device fields (auto-filled when device is selected) -->
			<div id="ks-device-extra-fields" style="display:none; margin-bottom:0;">
				<hr class="ks-proto-section-divider">
				<p style="font-size:0.8125rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--ks-text-muted); margin:0 0 10px;">Dane techniczne urządzenia <span style="font-weight:400;">(opcjonalnie)</span></p>
				<div class="ks-proto-inner-2col" style="gap:12px;">
					<div class="ks-form-group">
						<label>Numer fabryczny</label>
						<input type="text" name="ks_device_serial" id="ks-field-serial" class="ks-input" placeholder="S/N">
					</div>
					<div class="ks-form-group">
						<label>Rok produkcji</label>
						<input type="text" name="ks_device_year" id="ks-field-year" class="ks-input" placeholder="np. 2019">
					</div>
				</div>
				<hr class="ks-proto-section-divider">
			</div>

			<!-- Client data -->
			<div class="ks-form-group">
				<label>Imię i nazwisko klienta <span style="font-weight:400; color:var(--ks-text-muted);">(opcjonalnie)</span></label>
				<input type="text" name="ks_client_name" class="ks-input" placeholder="np. Anna Nowak">
			</div>
			<div class="ks-form-group">
				<label>E-mail klienta <span style="color:var(--ks-danger);">*</span></label>
				<input type="email" name="protocol_email" class="ks-input" required placeholder="emailklienta@gmail.com">
			</div>
			<div class="ks-form-group">
				<label>Telefon klienta <span style="font-weight:400; color:var(--ks-text-muted);">(opcjonalnie)</span></label>
				<input type="tel" name="ks_client_phone" id="ks-client-phone" class="ks-input" placeholder="np. +48 123 456 789">
			</div>

			<div class="ks-form-group">
				<label style="margin-bottom:10px; display:block;">Wykonane czynności</label>
				<?php foreach ( $checklist as $item ) : ?>
					<label style="display:flex; align-items:center; gap:8px; margin-bottom:8px; font-weight:400; cursor:pointer;">
						<input type="checkbox" name="proto_items[]" value="<?php echo esc_attr( $item ); ?>" style="width:16px; height:16px; accent-color:var(--ks-primary);">
						<?php echo esc_html( $item ); ?>
					</label>
				<?php endforeach; ?>
				<!-- Device-specific used parts are injected here when a device is selected -->
				<div id="ks-proto-parts-inject"></div>
				<!-- Custom (one-off) items added by technician -->
				<div id="ks-custom-items-list"></div>
				<div class="ks-add-item-row" style="margin-top:10px;">
					<input type="text" id="ks-custom-item-input" class="ks-input" placeholder="Dodaj niestandardową czynność…">
					<button type="button" onclick="ksAddCustomProtoItem()" style="white-space:nowrap; padding:10px 16px; flex-shrink:0; display:inline-flex; align-items:center; gap:6px; background:var(--ks-primary); color:#fff; border:none; border-radius:10px; cursor:pointer; font-weight:600;">
						<i data-lucide="plus" style="width:16px; height:16px;" aria-hidden="true"></i> Dodaj
					</button>
				</div>
			</div>

			<!-- Notes field -->
			<div class="ks-form-group">
				<label>Uwagi <span style="font-weight:400; color:var(--ks-text-muted);">(opcjonalnie)</span></label>
				<textarea name="ks_protokol_notes" class="ks-input" rows="3" placeholder="Dodatkowe uwagi dla klienta…"></textarea>
			</div>

			<div class="ks-form-group">
				<label style="margin-bottom:10px; display:block;">Podpis klienta <span style="font-weight:400; color:var(--ks-text-muted);">(opcjonalnie)</span></label>
				<canvas id="ks-sig-canvas" style="width:100%; height:160px; border:2px solid var(--ks-border); border-radius:12px; cursor:crosshair; touch-action:none; background:#fafafa;"></canvas>
				<input type="hidden" name="proto_signature" id="ks-sig-data">
				<button type="button" onclick="ksClearSig()" style="margin-top:6px; font-size:0.8125rem; color:var(--ks-text-muted); background:none; border:none; cursor:pointer; text-decoration:underline;">Wyczyść podpis</button>
			</div>

			<!-- Send copy to technician -->
			<div class="ks-form-group" style="margin-bottom:20px;">
				<label style="display:flex; align-items:flex-start; gap:10px; font-weight:400; cursor:pointer;">
					<input type="checkbox" name="ks_send_copy_to_tech" id="ks-copy-to-tech" value="1" checked style="width:16px; height:16px; flex-shrink:0; margin-top:2px; accent-color:var(--ks-primary);">
					<span>Wyślij kopię protokołu na mój e-mail</span>
				</label>
				<div style="margin-top:8px; padding-left:26px;">
					<input type="email" name="ks_tech_copy_email" id="ks-tech-copy-email" class="ks-input" value="<?php echo esc_attr( $technician_email ); ?>" placeholder="email serwisanta" style="font-size:0.875rem;">
					<p style="font-size:0.8125rem; color:var(--ks-text-muted); margin:4px 0 0;">Możesz zmienić adres przed wysłaniem.</p>
				</div>
			</div>

			<!-- RODO consent for electronic sending -->
			<div class="ks-form-group" style="margin-bottom:20px;">
				<label style="display:flex; align-items:flex-start; gap:10px; font-weight:400; cursor:pointer; line-height:1.4;">
					<input type="checkbox" name="ks_proto_send_consent" value="1" required style="width:16px; height:16px; flex-shrink:0; margin-top:2px; accent-color:var(--ks-primary);">
					<span style="font-size:0.8125rem; color:var(--ks-text-muted);">Potwierdzam, że posiadam zgodę odbiorcy na przesłanie informacji drogą elektroniczną zgodnie z art. 398 PKE oraz RODO. <span style="color:var(--ks-danger); font-weight:700;">(wymagane)</span></span>
				</label>
			</div>

			<div class="ks-proto-send-btns">
				<button type="button" onclick="ksShowProtocolPreview()" class="ks-btn-secondary" style="flex:1; justify-content:center; padding:13px; display:inline-flex; align-items:center; gap:8px; border-radius:12px; background:#f1f5f9; border:1px solid var(--ks-border); color:var(--ks-text); font-weight:600; cursor:pointer;">
					<i data-lucide="eye" style="width:18px; height:18px;" aria-hidden="true"></i> Podgląd protokołu
				</button>
				<button type="submit" class="ks-btn-primary" style="flex:1; justify-content:center; padding:13px;">
					<i data-lucide="send"></i> WYŚLIJ PROTOKÓŁ
				</button>
			</div>
		</form>
		<?php endif; ?>
	</div>
</div>

<!-- Protocol preview modal -->
<div id="ks-preview-modal" role="dialog" aria-modal="true" aria-label="Podgląd protokołu" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.65); z-index:9999; overflow-y:auto; padding:24px 12px;">
	<div style="max-width:720px; width:100%; margin:auto; background:#f8fafc; border-radius:16px; overflow:visible; box-shadow:0 20px 60px rgba(0,0,0,0.35); position:relative;">
		<div style="background:#fff; padding:14px 24px; border-bottom:1px solid #e2e8f0; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:2; border-radius:16px 16px 0 0;">
			<strong style="font-size:1rem; display:flex; align-items:center; gap:8px;"><i data-lucide="eye" style="width:18px; height:18px; color:var(--ks-primary);"></i> Podgląd protokołu</strong>
			<button type="button" onclick="ksClosePreview()" style="background:none; border:none; cursor:pointer; color:#64748b; padding:4px; border-radius:8px; line-height:0;" aria-label="Zamknij podgląd">
				<i data-lucide="x" style="width:22px; height:22px;"></i>
			</button>
		</div>
		<div id="ks-preview-body" style="padding:20px;"></div>
	</div>
</div>

<script>
// Static protocol settings (company stamp data) pre-loaded from PHP
var ksProtoSettings = {
	companyName:    <?php echo wp_json_encode( $proto_company_name ?: '' ); ?>,
	companyAddress: <?php echo wp_json_encode( $proto_company_address ?: '' ); ?>,
	companyNip:     <?php echo wp_json_encode( $proto_company_nip ?: '' ); ?>,
	companyEmail:   <?php echo wp_json_encode( $proto_company_email ?: '' ); ?>,
	companyPhone:   <?php echo wp_json_encode( $proto_company_phone ?: '' ); ?>,
	companyContact: <?php echo wp_json_encode( $proto_company_contact ?: '' ); ?>,
	companyLogo:    <?php echo wp_json_encode( $company_logo ?: '' ); ?>,
	footer:         <?php echo wp_json_encode( $footer_note ?: '' ); ?>
};
// Device → cumulative parts history map (pre-loaded from PHP)
// Format: { device_id: [ {date: "YYYY-MM-DD HH:ii", parts: [{id,name,qty}]}, ... ] }
var ksDevicePartsHistory = <?php echo wp_json_encode( $device_parts_history ); ?>;
// Device → extra fields (serial, year, phone) pre-loaded from PHP
var ksDeviceExtraFields = <?php echo wp_json_encode( $device_extra_fields ); ?>;

// ── Protocol toggle: show/hide settings body ──────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
	// ── Device list live-search by phone number or name ───────────────────
	var devSearch = document.getElementById('ks-dev-search');
	if (devSearch) {
		devSearch.addEventListener('input', function() { ksFilterDevices(this.value); });
	}

	// ── Allow pressing Enter to add checklist item ────────────────────────
	var newItemInput = document.getElementById('ks-new-item');
	if (newItemInput) {
		newItemInput.addEventListener('keydown', function(e) {
			if (e.key === 'Enter') { e.preventDefault(); ksAddChecklistRow(); }
		});
	}

	// ── Device selection: inject device parts into "Wykonane czynności" ───
	var devSelect = document.getElementById('ks-dev-select');
	if (devSelect) {
		devSelect.addEventListener('change', function() {
			ksInjectDeviceParts(this.value);
			ksPopulateDeviceExtraFields(this.value);
		});
	}

	// ── Mark phone as user-edited if technician types in it ──────────────
	var clientPhoneInput = document.getElementById('ks-client-phone');
	if (clientPhoneInput) {
		clientPhoneInput.addEventListener('input', function() {
			this.dataset.userEdited = '1';
		});
	}

	// ── Allow Enter key to add custom checklist item ──────────────────────
	var customItemInput = document.getElementById('ks-custom-item-input');
	if (customItemInput) {
		customItemInput.addEventListener('keydown', function(e) {
			if (e.key === 'Enter') { e.preventDefault(); ksAddCustomProtoItem(); }
		});
	}

	// ── Toggle send-copy email input based on checkbox ────────────────────
	var copyCheckbox = document.getElementById('ks-copy-to-tech');
	var techEmailInput = document.getElementById('ks-tech-copy-email');
	if (copyCheckbox && techEmailInput) {
		copyCheckbox.addEventListener('change', function() {
			techEmailInput.disabled = !this.checked;
			techEmailInput.style.opacity = this.checked ? '1' : '0.4';
		});
	}

	// ── Auto-collapse settings after save ────────────────────────────────
	if (<?php echo $protokol_saved ? 'true' : 'false'; ?>) {
		ksCollapseProtoSettings();
	}
});

// ── Protocol settings collapse/expand ────────────────────────────────────
function ksCollapseProtoSettings() {
	var body = document.getElementById('ks-proto-settings-body');
	var btn  = document.getElementById('ks-proto-edit-btn');
	if (body) body.style.display = 'none';
	if (btn)  { btn.style.display = 'inline-flex'; btn.setAttribute('aria-expanded', 'false'); }
}

function ksToggleProtoSettings() {
	var body = document.getElementById('ks-proto-settings-body');
	var btn  = document.getElementById('ks-proto-edit-btn');
	if (!body || !btn) return;
	var isHidden = body.style.display === 'none';
	body.style.display = isHidden ? '' : 'none';
	btn.setAttribute('aria-expanded', isHidden ? 'true' : 'false');
	if (isHidden) {
		btn.innerHTML = '<i data-lucide="x" style="width:14px; height:14px;" aria-hidden="true"></i> Zwiń ustawienia';
	} else {
		btn.innerHTML = '<i data-lucide="edit" style="width:14px; height:14px;" aria-hidden="true"></i> Edytuj wzorzec';
	}
	if (typeof lucide !== 'undefined') lucide.createIcons();
}

// Inject device's historical used-parts as proto_items[] inside "Wykonane czynności"
function ksInjectDeviceParts(deviceId) {
	var inject = document.getElementById('ks-proto-parts-inject');
	if (!inject) return;
	inject.innerHTML = '';

	var history = (deviceId && ksDevicePartsHistory[deviceId]) ? ksDevicePartsHistory[deviceId] : [];
	if (!history.length) return;

	// Gather all unique part entries across all service dates
	history.forEach(function(entry) {
		var date = entry.date || '';
		if (!Array.isArray(entry.parts)) return;
		entry.parts.forEach(function(part) {
			var label = 'Użyte części: ' + date + ' – ' + String(part.name);
			if (parseInt(part.qty, 10) > 1) {
				label += ' (szt. ' + parseInt(part.qty, 10) + ')';
			}

			var lbl = document.createElement('label');
			lbl.style.cssText = 'display:flex; align-items:center; gap:8px; margin-bottom:8px; font-weight:400; cursor:pointer; color:var(--ks-text-muted);';

			var cb = document.createElement('input');
			cb.type = 'checkbox';
			cb.name = 'proto_items[]';
			cb.value = label;
			cb.checked = true;
			cb.style.cssText = 'width:16px; height:16px; accent-color:var(--ks-primary);';

			lbl.appendChild(cb);
			lbl.appendChild(document.createTextNode(label));
			inject.appendChild(lbl);
		});
	});
}

// Device filter helper
function ksFilterDevices(query) {
	var sel = document.getElementById('ks-dev-select');
	if (!sel) return;
	var q = query.trim().toLowerCase();
	var opts = sel.querySelectorAll('option');
	opts.forEach(function(opt) {
		if (!opt.value) return; // keep placeholder
		var search = (opt.dataset.search || '').toLowerCase();
		opt.hidden = q.length > 0 && search.indexOf(q) === -1;
	});
	// Reset selection if current choice is now hidden
	if (sel.selectedOptions.length && sel.selectedOptions[0].hidden) {
		sel.value = '';
	}
}

// Populate extra device fields (serial, year) and client phone from the pre-loaded map
function ksPopulateDeviceExtraFields(deviceId) {
	var container = document.getElementById('ks-device-extra-fields');
	var serialField = document.getElementById('ks-field-serial');
	var yearField = document.getElementById('ks-field-year');
	var phoneField = document.getElementById('ks-client-phone');
	if (!container) return;

	var extra = (deviceId && ksDeviceExtraFields[deviceId]) ? ksDeviceExtraFields[deviceId] : {};
	if (serialField) serialField.value = extra.serial || '';
	if (yearField) yearField.value = extra.year || '';
	// Auto-fill client phone from device, but only if the technician hasn't manually edited it
	if (phoneField && !phoneField.dataset.userEdited) {
		phoneField.value = extra.phone || '';
	}
	container.style.display = deviceId ? 'block' : 'none';
}

// ── Checklist builder ─────────────────────────────────────────────────────
function ksAddChecklistRow() {
	var input = document.getElementById('ks-new-item');
	var val = input ? input.value.trim() : '';
	if (!val) return;
	var builder = document.getElementById('ks-checklist-builder');
	if (!builder) return;

	var row = document.createElement('div');
	row.className = 'ks-checklist-row';

	var icon = document.createElement('i');
	icon.setAttribute('data-lucide', 'grip-vertical');
	icon.style.cssText = 'color:var(--ks-text-muted); width:16px; height:16px; flex-shrink:0;';
	icon.setAttribute('aria-hidden', 'true');

	var textInput = document.createElement('input');
	textInput.type = 'text';
	textInput.name = 'ks_protocol_checklist[]';
	textInput.value = val;
	textInput.required = true;
	textInput.setAttribute('aria-label', 'Czynność serwisowa: ' + val);

	var removeBtn = document.createElement('button');
	removeBtn.type = 'button';
	removeBtn.title = 'Usuń czynność';
	removeBtn.setAttribute('aria-label', 'Usuń czynność');
	removeBtn.onclick = function() { ksRemoveChecklistRow(removeBtn); };

	var xIcon = document.createElement('i');
	xIcon.setAttribute('data-lucide', 'x');
	xIcon.style.cssText = 'width:16px; height:16px;';
	xIcon.setAttribute('aria-hidden', 'true');
	removeBtn.appendChild(xIcon);

	row.appendChild(icon);
	row.appendChild(textInput);
	row.appendChild(removeBtn);
	builder.appendChild(row);

	input.value = '';
	if (typeof lucide !== 'undefined') lucide.createIcons();
	input.focus();
}

function ksRemoveChecklistRow(btn) {
	var row = btn.closest('.ks-checklist-row');
	if (row) row.remove();
}

// ── Custom (one-off) items in send checklist ──────────────────────────────
function ksAddCustomProtoItem() {
	var input = document.getElementById('ks-custom-item-input');
	var val = input ? input.value.trim() : '';
	if (!val) return;
	var list = document.getElementById('ks-custom-items-list');
	if (!list) return;

	var lbl = document.createElement('label');
	lbl.style.cssText = 'display:flex; align-items:center; gap:8px; margin-bottom:8px; font-weight:400; cursor:pointer;';

	var cb = document.createElement('input');
	cb.type = 'checkbox';
	cb.name = 'proto_items[]';
	cb.value = val;
	cb.checked = true;
	cb.style.cssText = 'width:16px; height:16px; accent-color:var(--ks-primary); flex-shrink:0;';

	var span = document.createElement('span');
	span.style.flex = '1';
	span.textContent = val;

	var removeBtn = document.createElement('button');
	removeBtn.type = 'button';
	removeBtn.style.cssText = 'background:none; border:none; cursor:pointer; color:var(--ks-text-muted); padding:2px; border-radius:4px; line-height:0;';
	removeBtn.setAttribute('aria-label', 'Usuń czynność');
	removeBtn.onclick = function() { lbl.remove(); };
	var xI = document.createElement('i');
	xI.setAttribute('data-lucide', 'x');
	xI.style.cssText = 'width:14px; height:14px;';
	removeBtn.appendChild(xI);

	lbl.appendChild(cb);
	lbl.appendChild(span);
	lbl.appendChild(removeBtn);
	list.appendChild(lbl);

	if (typeof lucide !== 'undefined') lucide.createIcons();
	input.value = '';
	input.focus();
}

// ── Protocol preview modal ────────────────────────────────────────────────
function ksShowProtocolPreview() {
	var devSelect = document.getElementById('ks-dev-select');
	var deviceId  = devSelect ? devSelect.value : '';
	var selectedOpt = devSelect && deviceId ? devSelect.options[devSelect.selectedIndex] : null;
	var deviceName  = selectedOpt ? (selectedOpt.dataset.name || selectedOpt.text) : '';

	var extra    = (deviceId && ksDeviceExtraFields[deviceId]) ? ksDeviceExtraFields[deviceId] : {};
	var serial   = (document.getElementById('ks-field-serial')  || {}).value || '';
	var year     = (document.getElementById('ks-field-year')    || {}).value || '';

	var clientName  = (document.querySelector('[name="ks_client_name"]')   || {}).value || '';
	var clientEmail = (document.querySelector('[name="protocol_email"]')   || {}).value || '';
	var clientPhone = (document.getElementById('ks-client-phone')          || {}).value || '';
	var notes       = (document.querySelector('[name="ks_protokol_notes"]') || {}).value || '';

	// Collect checked items (template + injected + custom)
	var checkedItems = [];
	document.querySelectorAll('[name="proto_items[]"]:checked').forEach(function(cb) {
		checkedItems.push(cb.value);
	});

	// Signature (inline data URI for preview only)
	var canvas   = document.getElementById('ks-sig-canvas');
	var sigData  = '';
	if (canvas && canvas.getContext) {
		var buf = new Uint32Array(canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data.buffer);
		if (buf.some(Boolean)) { sigData = canvas.toDataURL('image/png'); }
	}

	var modal = document.getElementById('ks-preview-modal');
	if (!modal) return;
	document.getElementById('ks-preview-body').innerHTML = ksBuildPreviewHtml({
		deviceName: deviceName, serial: serial, year: year,
		clientName: clientName, clientEmail: clientEmail, clientPhone: clientPhone,
		checkedItems: checkedItems, notes: notes, sigData: sigData
	});
	modal.style.display = 'block';
	modal.scrollTop = 0;
	document.body.style.overflow = 'hidden';
	if (typeof lucide !== 'undefined') lucide.createIcons();
}

function ksClosePreview() {
	var modal = document.getElementById('ks-preview-modal');
	if (modal) modal.style.display = 'none';
	document.body.style.overflow = '';
}

// Close preview when clicking outside the inner panel
document.addEventListener('click', function(e) {
	var modal = document.getElementById('ks-preview-modal');
	if (modal && e.target === modal) { ksClosePreview(); }
});

function ksEscHtml(str) {
	return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function ksBuildPreviewHtml(d) {
	var s = ksProtoSettings;
	var rows = function(label, value) {
		return value ? '<div style="display:flex;gap:12px;margin-bottom:6px;font-size:14px;"><span style="color:#64748b;min-width:160px;flex-shrink:0;">' + ksEscHtml(label) + '</span><span>' + ksEscHtml(value) + '</span></div>' : '';
	};
	var sectionTitle = function(t) {
		return '<div style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#64748b;margin:24px 0 10px;border-bottom:1px solid #f1f5f9;padding-bottom:6px;">' + ksEscHtml(t) + '</div>';
	};

	// min-width keeps desktop layout intact on mobile; #ks-preview-body scrolls horizontally instead of wrapping.
	var html = '<div style="background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);font-family:Arial,sans-serif;color:#1e293b;min-width:580px;">';
	// Header
	html += '<div style="background:#4F46E5;color:#fff;padding:28px 40px;display:flex;align-items:center;gap:20px;">';
	if (s.companyLogo) { html += '<span style="background:#fff;border-radius:10px;padding:8px;flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;"><img src="' + ksEscHtml(s.companyLogo) + '" style="width:64px;height:64px;object-fit:contain;max-width:112px;display:block;" alt=""></span>'; }
	html += '<div><div style="font-size:22px;font-weight:700;margin-bottom:4px;">Protokół Serwisowy</div>';
	html += '<div style="opacity:.8;font-size:14px;">' + ksEscHtml(s.companyName) + (s.companyPhone ? ' &bull; ' + ksEscHtml(s.companyPhone) : '') + '</div></div>';
	html += '</div>';
	// Body
	html += '<div style="padding:32px 40px;">';
	// Company stamp
	if (s.companyName || s.companyAddress || s.companyNip || s.companyEmail || s.companyPhone || s.companyContact) {
		html += sectionTitle('Dane serwisanta');
		if (s.companyName)    html += rows('Firma:', s.companyName);
		if (s.companyAddress) html += rows('Adres:', s.companyAddress);
		if (s.companyNip)     html += rows('NIP:', s.companyNip);
		if (s.companyPhone)   html += rows('Telefon:', s.companyPhone);
		if (s.companyEmail)   html += rows('E-mail:', s.companyEmail);
		if (s.companyContact) html += rows('Osoba kontaktowa:', s.companyContact);
	}
	// Client data
	if (d.clientName || d.clientEmail || d.clientPhone) {
		html += sectionTitle('Dane klienta');
		if (d.clientName)  html += rows('Imię i nazwisko:', d.clientName);
		if (d.clientEmail) html += rows('E-mail:', d.clientEmail);
		if (d.clientPhone) html += rows('Telefon:', d.clientPhone);
	}
	// Device
	html += sectionTitle('Urządzenie');
	if (d.deviceName) html += rows('Nazwa / Model:', d.deviceName);
	if (d.serial)     html += rows('Numer fabryczny:', d.serial);
	if (d.year)       html += rows('Rok produkcji:', d.year);
	// Checklist
	if (d.checkedItems.length) {
		html += sectionTitle('Wykonane czynności');
		d.checkedItems.forEach(function(item) {
			html += '<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #f1f5f9;font-size:14px;"><span style="color:#10B981;font-weight:700;">&#10004;</span>' + ksEscHtml(item) + '</div>';
		});
	}
	// Notes
	if (d.notes) {
		html += sectionTitle('Uwagi');
		html += '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px 16px;font-size:14px;line-height:1.6;white-space:pre-wrap;">' + ksEscHtml(d.notes) + '</div>';
	}
	// Signature
	if (d.sigData) {
		html += '<div style="margin-top:24px;border-top:2px solid #e2e8f0;padding-top:20px;">';
		html += sectionTitle('Podpis klienta');
		html += '<img src="' + ksEscHtml(d.sigData) + '" style="max-width:240px;width:100%;border:1px solid #e2e8f0;border-radius:8px;margin-top:8px;display:block;" alt="Podpis klienta">';
		html += '</div>';
	}
	// Footer
	if (s.footer) {
		html += '<div style="margin-top:24px;font-size:12px;color:#94a3b8;border-top:1px solid #f1f5f9;padding-top:16px;">' + ksEscHtml(s.footer).replace(/\n/g,'<br>') + '</div>';
	}
	html += '</div></div>';
	return html;
}

// Simple signature pad implementation
(function() {
	var canvas, ctx, drawing = false, lastX = 0, lastY = 0;

	function getPos(e) {
		var r = canvas.getBoundingClientRect();
		var src = e.touches ? e.touches[0] : e;
		return { x: src.clientX - r.left, y: src.clientY - r.top };
	}

	function onMouseDown(e) { drawing = true; var p = getPos(e); lastX = p.x; lastY = p.y; }
	function onMouseMove(e) {
		if (!drawing) return;
		var p = getPos(e);
		ctx.beginPath(); ctx.moveTo(lastX, lastY); ctx.lineTo(p.x, p.y); ctx.stroke();
		lastX = p.x; lastY = p.y;
	}
	function onMouseUp()   { drawing = false; }
	function onTouchStart(e) { e.preventDefault(); drawing = true; var p = getPos(e); lastX = p.x; lastY = p.y; }
	function onTouchMove(e) {
		e.preventDefault();
		if (!drawing) return;
		var p = getPos(e);
		ctx.beginPath(); ctx.moveTo(lastX, lastY); ctx.lineTo(p.x, p.y); ctx.stroke();
		lastX = p.x; lastY = p.y;
	}
	function onTouchEnd()  { drawing = false; }

	function init() {
		canvas = document.getElementById('ks-sig-canvas');
		if (!canvas) return;
		ctx = canvas.getContext('2d');

		var rect = canvas.getBoundingClientRect();
		var dpr  = window.devicePixelRatio || 1;
		canvas.width  = rect.width  * dpr;
		canvas.height = rect.height * dpr;
		ctx.scale(dpr, dpr);
		ctx.strokeStyle = '#1e293b';
		ctx.lineWidth   = 2.5;
		ctx.lineCap     = 'round';
		ctx.lineJoin    = 'round';

		canvas.addEventListener('mousedown',  onMouseDown);
		canvas.addEventListener('mousemove',  onMouseMove);
		canvas.addEventListener('mouseup',    onMouseUp);
		canvas.addEventListener('mouseleave', onMouseUp);
		canvas.addEventListener('touchstart', onTouchStart, {passive: false});
		canvas.addEventListener('touchmove',  onTouchMove,  {passive: false});
		canvas.addEventListener('touchend',   onTouchEnd);

		// Capture signature into hidden field before form submits
		var form = canvas.closest('form');
		if (form) {
			form.addEventListener('submit', function() {
				var inp = document.getElementById('ks-sig-data');
				if (inp) inp.value = canvas.toDataURL('image/png');
			});
		}
	}

	window.ksClearSig = function() {
		if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
		var inp = document.getElementById('ks-sig-data');
		if (inp) inp.value = '';
	};

	document.addEventListener('DOMContentLoaded', init);
})();
</script>
<?php endif; ?>
