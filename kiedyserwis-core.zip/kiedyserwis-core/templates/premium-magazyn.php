<?php
/**
 * Template for Premium Magazyn (Warehouse) module.
 * Displayed in the technician dashboard under "Magazyn".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_premium = ks_is_premium_active( $current_user_id );

if ( ! $is_premium ) :
?>
<style>
	.ks-mag-upsell { background:#fff; padding:48px; border-radius:24px; border:1px solid var(--ks-border); box-shadow:0 10px 15px -3px rgba(0,0,0,0.1); max-width:800px; margin:0 auto; }
	.ks-mag-upsell h2 { font-size:2rem; font-weight:800; letter-spacing:-0.025em; margin-bottom:16px; }
	.ks-mag-feature-grid { display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:40px; }
	@media(max-width:768px){
		.ks-mag-upsell { padding:24px; }
		.ks-mag-feature-grid { grid-template-columns:1fr; gap:16px; }
		.ks-mag-upsell h2 { font-size:1.5rem; }
	}
</style>
<div class="ks-mag-upsell">
	<div style="text-align:center; margin-bottom:40px;">
		<div style="width:80px; height:80px; background:rgba(79,70,229,0.1); border-radius:20px; display:flex; align-items:center; justify-content:center; margin:0 auto 24px;">
			<i data-lucide="package" style="color:var(--ks-primary); width:40px; height:40px;"></i>
		</div>
		<h2>📦 Magazyn Premium</h2>
		<p style="font-size:1.125rem; color:var(--ks-text-muted); line-height:1.6; max-width:600px; margin:0 auto;">Zarządzaj częściami serwisowymi, śledź stany magazynowe i nigdy nie daj się zaskoczyć brakującą częścią.</p>
	</div>
	<div class="ks-mag-feature-grid">
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="list" style="color:var(--ks-primary);"></i> Lista części</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Prowadź cyfrowy magazyn – nazwa, stan i minimalna ilość dla każdej części.</p>
		</div>
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="bell" style="color:var(--ks-primary);"></i> Powiadomienia</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Otrzymuj e-mail gdy stan spada poniżej minimum. Ikona w menu miga, kiedy coś wymaga uzupełnienia.</p>
		</div>
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="link" style="color:var(--ks-primary);"></i> Integracja z protokołem</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Przy wysyłce protokołu serwisowego zaznacz zużyte części – stan magazynu aktualizuje się automatycznie.</p>
		</div>
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="bar-chart-2" style="color:var(--ks-primary);"></i> Przegląd stanów</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Czytelny widok wszystkich części z oznaczeniem krytycznie niskich stanów.</p>
		</div>
	</div>
	<div style="text-align:center;">
		<a href="?ks_tab=plan" class="ks-btn-primary" style="padding:16px 40px; font-size:1.125rem; border-radius:12px; max-width:100%; box-sizing:border-box;">AKTYWUJ PAKIET PREMIUM</a>
	</div>
</div>
<?php else :
	// ─── Premium: Magazyn module ───
	$mag_saved   = isset( $_GET['mag_saved'] );
	$mag_deleted = isset( $_GET['mag_deleted'] );
	$mag_error   = isset( $_GET['mag_error'] );
	$edit_id     = isset( $_GET['edit_part'] ) ? intval( $_GET['edit_part'] ) : 0;

	// Fetch all parts for this user
	$parts = get_posts( array(
		'post_type'        => 'ks_czesc',
		'author'           => $current_user_id,
		'post_status'      => 'publish',
		'posts_per_page'   => -1,
		'orderby'          => 'title',
		'order'            => 'ASC',
		'no_found_rows'    => true,
		'suppress_filters' => false, // Allow pre_get_posts isolation to run.
	) );

	// Count low-stock
	$low_stock_count = ks_get_low_stock_count( $current_user_id );

	// Editing an existing part?
	$edit_part = null;
	if ( $edit_id ) {
		// Use centralized ownership helper to prevent cross-tenant part access.
		if ( ks_verify_part_ownership( $edit_id, $current_user_id ) ) {
			$edit_part = get_post( $edit_id );
		}
	}
?>
<style>
/* Magazyn table – responsive card layout on mobile */
@media (max-width: 768px) {
	.ks-mag-table-wrap { overflow: visible !important; border-radius: 0 !important; border: none !important; background: transparent !important; box-shadow: none !important; }
	.ks-mag-table { display: block; }
	.ks-mag-table thead { display: none; }
	.ks-mag-table tbody { display: flex; flex-direction: column; gap: 12px; }
	.ks-mag-table tr { display: flex; flex-direction: column; background: #fff; border-radius: 16px; border: 1px solid var(--ks-border); box-shadow: var(--ks-shadow); padding: 16px; gap: 6px; }
	.ks-mag-table td { display: flex; align-items: center; justify-content: space-between; padding: 4px 0 !important; border: none !important; text-align: left !important; }
	.ks-mag-table td::before { content: attr(data-label); font-size: 0.6875rem; font-weight: 700; color: var(--ks-text-muted); text-transform: uppercase; letter-spacing: .06em; flex-shrink: 0; margin-right: 8px; }
	.ks-mag-table td.ks-mag-td-name { font-size: 1rem; font-weight: 700; flex-direction: column; align-items: flex-start; }
	.ks-mag-table td.ks-mag-td-name::before { display: none; }
	.ks-mag-table td.ks-mag-td-actions { justify-content: flex-end; gap: 8px; padding-top: 8px !important; border-top: 1px solid var(--ks-border) !important; }
	.ks-mag-table td.ks-mag-td-actions::before { display: none; }
}
</style>
<div style="display:flex; align-items:flex-start; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:20px;">
	<div>
		<h2 class="ks-page-title" style="margin-bottom:4px;">Magazyn części</h2>
		<p class="ks-page-subtitle">Łącznie: <?php echo count($parts); ?> pozycji<?php if ($low_stock_count > 0): ?> &bull; <span style="color:var(--ks-danger); font-weight:700;">⚠ <?php echo $low_stock_count; ?> osiągnęło minimum</span><?php endif; ?></p>
	</div>
	<button class="ks-btn-primary" onclick="document.getElementById('ks-add-part-modal').style.display='flex'">
		<i data-lucide="plus"></i> DODAJ CZĘŚĆ
	</button>
</div>

<?php if ( $mag_saved ) : ?>
	<div class="ks-alert-banner" style="background:var(--ks-success-light); color:var(--ks-success); border-color:var(--ks-success); margin-bottom:20px;">
		<span style="display:flex; align-items:center; gap:8px;"><i data-lucide="check-circle" style="width:18px; height:18px; flex-shrink:0;"></i> Część została zapisana.</span>
	</div>
<?php endif; ?>
<?php if ( $mag_deleted ) : ?>
	<div class="ks-alert-banner" style="background:var(--ks-danger-light); color:var(--ks-danger); border-color:var(--ks-danger); margin-bottom:20px;">
		<span style="display:flex; align-items:center; gap:8px;"><i data-lucide="trash-2" style="width:18px; height:18px; flex-shrink:0;"></i> Część została usunięta.</span>
	</div>
<?php endif; ?>
<?php if ( $mag_error ) : ?>
	<div class="ks-alert-banner ks-alert-banner-danger" style="margin-bottom:20px;">
		<span style="display:flex; align-items:center; gap:8px;"><i data-lucide="alert-circle" style="width:18px; height:18px; flex-shrink:0;"></i> Wypełnij wymagane pola i spróbuj ponownie.</span>
	</div>
<?php endif; ?>

<?php if ( empty( $parts ) ) : ?>
	<div style="text-align:center; padding:60px 20px; background:#fff; border-radius:20px; border:1px solid var(--ks-border);">
		<i data-lucide="package" style="width:48px; height:48px; color:var(--ks-text-muted); opacity:.4; margin-bottom:16px;"></i>
		<h3 style="margin-bottom:8px; color:var(--ks-text-muted); font-weight:600;">Magazyn jest pusty</h3>
		<p style="color:var(--ks-text-muted); font-size:0.9375rem;">Kliknij „Dodaj część", aby dodać pierwszą pozycję.</p>
		<p style="color:var(--ks-text-muted); font-size:0.9375rem;">Dodając nowe urządzenie będziesz mógł przypisać użyte części podczas montażu lub serwisu.</p>
		<p style="color:var(--ks-text-muted); font-size:0.9375rem;">Historia użytych części zostanie przypisana do urządzenia klienta oraz będzie widoczna w protokole serwisowym.</p>
		<p style="color:var(--ks-text-muted); font-size:0.9375rem;"><b>Określ minimum dla dodanych pozycji- powiadomimy Cię gdy stan części osiągnie minimum.</b></p>
	</div>
<?php else : ?>
	<div class="ks-mag-table-wrap" style="background:#fff; border-radius:20px; border:1px solid var(--ks-border); overflow:hidden; box-shadow:var(--ks-shadow);">
		<table class="ks-mag-table" style="width:100%; border-collapse:collapse; font-size:0.9375rem;">
			<thead>
				<tr style="background:#F8FAFC; border-bottom:2px solid var(--ks-border);">
					<th style="padding:14px 20px; text-align:left; font-weight:700; color:var(--ks-text-muted); font-size:0.75rem; text-transform:uppercase; letter-spacing:.06em;">Nazwa</th>
					<th style="padding:14px 20px; text-align:center; font-weight:700; color:var(--ks-text-muted); font-size:0.75rem; text-transform:uppercase; letter-spacing:.06em;">Stan</th>
					<th style="padding:14px 20px; text-align:center; font-weight:700; color:var(--ks-text-muted); font-size:0.75rem; text-transform:uppercase; letter-spacing:.06em;">Minimum</th>
					<th style="padding:14px 20px; text-align:center; font-weight:700; color:var(--ks-text-muted); font-size:0.75rem; text-transform:uppercase; letter-spacing:.06em;">Status</th>
					<th style="padding:14px 20px; text-align:right; font-weight:700; color:var(--ks-text-muted); font-size:0.75rem; text-transform:uppercase; letter-spacing:.06em;">Akcje</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $parts as $part ) :
				$stock   = (int) get_post_meta( $part->ID, 'ks_stan', true );
				$minimum = (int) get_post_meta( $part->ID, 'ks_minimum', true );
				$is_low  = $minimum > 0 && $stock <= $minimum;
			?>
				<tr style="border-bottom:1px solid var(--ks-border);">
					<td class="ks-mag-td-name" style="padding:14px 20px; font-weight:600;"><?php echo esc_html( $part->post_title ); ?></td>
					<td data-label="Stan" style="padding:14px 20px; text-align:center; font-size:1.125rem; font-weight:700; color:<?php echo $is_low ? 'var(--ks-danger)' : 'var(--ks-text-main)'; ?>;"><?php echo $stock; ?></td>
					<td data-label="Minimum" style="padding:14px 20px; text-align:center; color:var(--ks-text-muted);"><?php echo $minimum ?: '—'; ?></td>
					<td data-label="Status" style="padding:14px 20px; text-align:center;">
						<?php if ( $is_low ) : ?>
							<span style="background:var(--ks-danger-light); color:var(--ks-danger); padding:4px 10px; border-radius:20px; font-size:0.75rem; font-weight:700;">⚠ <?php echo $stock < $minimum ? 'Niski stan' : 'Osiągnięto min.'; ?></span>
						<?php else : ?>
							<span style="background:var(--ks-success-light); color:var(--ks-success); padding:4px 10px; border-radius:20px; font-size:0.75rem; font-weight:700;">OK</span>
						<?php endif; ?>
					</td>
					<td class="ks-mag-td-actions" style="padding:14px 20px; text-align:right; white-space:nowrap;">
						<a href="?ks_tab=magazyn&edit_part=<?php echo $part->ID; ?>" class="ks-btn-action" style="padding:7px 14px; font-size:0.8125rem; margin-right:6px;">
							<i data-lucide="pencil" style="width:14px; height:14px;"></i> Edytuj
						</a>
						<form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" style="display:inline;" onsubmit="return confirm('Usunąć tę część?')">
							<input type="hidden" name="action" value="ks_delete_czesc">
							<input type="hidden" name="part_id" value="<?php echo $part->ID; ?>">
							<?php wp_nonce_field( 'ks_delete_czesc', 'ks_delete_czesc_nonce' ); ?>
							<button type="submit" class="ks-btn-action" style="padding:7px 14px; font-size:0.8125rem; background:var(--ks-danger-light); color:var(--ks-danger); border:none; cursor:pointer; border-radius:10px; font-weight:600;">
								<i data-lucide="trash-2" style="width:14px; height:14px;"></i> Usuń
							</button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>

<!-- Add Part Modal -->
<div id="ks-add-part-modal" class="ks-overlay-form" style="<?php echo $edit_part ? 'display:flex;' : ''; ?>">
	<div class="ks-form-card" style="max-width:480px;">
		<button class="ks-close-form" onclick="document.getElementById('ks-add-part-modal').style.display='none'">&times;</button>
		<h3 style="margin-bottom:20px;"><?php echo $edit_part ? 'Edytuj część' : 'Dodaj część'; ?></h3>
		<form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">
			<input type="hidden" name="action" value="ks_save_czesc">
			<?php if ( $edit_part ) : ?>
				<input type="hidden" name="part_id" value="<?php echo $edit_part->ID; ?>">
			<?php endif; ?>
			<?php wp_nonce_field( 'ks_save_czesc', 'ks_czesc_nonce' ); ?>

			<div class="ks-form-group">
				<label>Nazwa części *</label>
				<input type="text" name="czesc_name" class="ks-input" required value="<?php echo $edit_part ? esc_attr( $edit_part->post_title ) : ''; ?>" placeholder="np. Filtr powietrza Bosch">
			</div>
			<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
				<div class="ks-form-group">
					<label>Stan (ilość)</label>
					<input type="number" name="czesc_stan" class="ks-input" min="0" value="<?php echo $edit_part ? (int) get_post_meta( $edit_part->ID, 'ks_stan', true ) : '0'; ?>">
				</div>
				<div class="ks-form-group">
					<label>Minimum</label>
					<input type="number" name="czesc_minimum" class="ks-input" min="0" value="<?php echo $edit_part ? (int) get_post_meta( $edit_part->ID, 'ks_minimum', true ) : '1'; ?>">
				</div>
			</div>
			<button type="submit" class="ks-btn-primary" style="width:100%; justify-content:center; padding:13px; margin-top:8px;">
				<i data-lucide="save"></i> ZAPISZ
			</button>
		</form>
	</div>
</div>
<?php endif; ?>
