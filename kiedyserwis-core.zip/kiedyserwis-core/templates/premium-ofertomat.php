<?php
/**
 * Template for Premium Ofertomat module.
 * Displayed in the technician dashboard under "Ofertomat".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_premium = ks_is_premium_active( $current_user_id );

if ( ! $is_premium ) :
?>
<style>
	.ks-ofert-upsell { background:#fff; padding:48px; border-radius:24px; border:1px solid var(--ks-border); box-shadow:0 10px 15px -3px rgba(0,0,0,0.1); max-width:800px; margin:0 auto; }
	.ks-ofert-upsell h2 { font-size:2rem; font-weight:800; letter-spacing:-0.025em; margin-bottom:16px; }
	.ks-ofert-feature-grid { display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:40px; }
	@media(max-width:768px){
		.ks-ofert-upsell { padding:24px; }
		.ks-ofert-feature-grid { grid-template-columns:1fr; gap:16px; }
		.ks-ofert-upsell h2 { font-size:1.5rem; }
	}
</style>
<div class="ks-ofert-upsell">
	<div style="text-align:center; margin-bottom:40px;">
		<div style="width:80px; height:80px; background:rgba(79,70,229,0.1); border-radius:20px; display:flex; align-items:center; justify-content:center; margin:0 auto 24px;">
			<i data-lucide="file-check" style="color:var(--ks-primary); width:40px; height:40px;"></i>
		</div>
		<h2>💼 Ofertomat Premium</h2>
		<p style="font-size:1.125rem; color:var(--ks-text-muted); line-height:1.6; max-width:600px; margin:0 auto;">Szybko przygotuj i wyślij profesjonalną ofertę e-mailem do klienta – bez zbędnych formalności.</p>
	</div>
	<div class="ks-ofert-feature-grid">
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="zap" style="color:var(--ks-primary);"></i> Błyskawiczna oferta</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Wypełnij formularz i wyślij ofertę w minutę. Bez drukarek, bez PDF, bez komplikacji.</p>
		</div>
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="calculator" style="color:var(--ks-primary);"></i> Auto-kalkulacje</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Netto, VAT, brutto – wyliczane automatycznie dla każdej pozycji i w podsumowaniu.</p>
		</div>
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="mail" style="color:var(--ks-primary);"></i> Wysyłka e-mailem</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Gotowa oferta HTML trafia na e-mail klienta w ciągu sekund. Możesz otrzymać kopię na swój adres.</p>
		</div>
		<div style="padding:24px; background:#F9FAFB; border-radius:16px;">
			<h3 style="font-size:1rem; font-weight:700; margin-bottom:10px; display:flex; align-items:center; gap:8px;"><i data-lucide="smartphone" style="color:var(--ks-primary);"></i> Działa na telefonie</h3>
			<p style="font-size:0.875rem; color:var(--ks-text-muted);">Responsywny formularz i e-mail – wygodne na każdym urządzeniu, u klienta na miejscu.</p>
		</div>
	</div>
	<div style="text-align:center;">
		<a href="?ks_tab=plan" class="ks-btn-primary" style="padding:16px 40px; font-size:1.125rem; border-radius:12px; max-width:100%; box-sizing:border-box;">AKTYWUJ PAKIET PREMIUM</a>
	</div>
</div>
<?php else : // ─── Premium: Ofertomat module ───

	$ofert_sent    = isset( $_GET['ofert_sent'] );
	$ofert_error   = isset( $_GET['ofert_error'] );
	$ofert_sent_to = isset( $_GET['ofert_sent_to'] ) ? sanitize_email( wp_unslash( $_GET['ofert_sent_to'] ) ) : '';
	$ofert_error_msg = isset( $_GET['ofert_error'] ) ? sanitize_text_field( wp_unslash( $_GET['ofert_error'] ) ) : '';

	$company_name    = get_user_meta( $current_user_id, 'ks_company_name', true )
		?: get_the_author_meta( 'display_name', $current_user_id );
	$company_phone   = get_user_meta( $current_user_id, 'ks_company_phone', true );
	$company_url     = get_user_meta( $current_user_id, 'ks_company_url', true );
	$company_city    = get_user_meta( $current_user_id, 'ks_company_city', true );
	$company_logo_id = get_user_meta( $current_user_id, 'ks_company_logo', true );
	$company_logo    = $company_logo_id ? wp_get_attachment_image_url( (int) $company_logo_id, 'medium' ) : '';
	$technician_email = get_the_author_meta( 'user_email', $current_user_id );
?>
<h2 class="ks-page-title" style="margin-bottom:6px;">Ofertomat</h2>
<p class="ks-page-subtitle" style="margin-bottom:28px;">Przygotuj i wyślij profesjonalną ofertę do klienta w kilka minut.</p>

<style>
/* ── Ofertomat styles ─────────────────────────── */
#ks-ofert-modal { display:none; position:fixed; inset:0; z-index:9000; background:rgba(15,23,42,0.55); overflow-y:auto; padding:16px; }
#ks-ofert-modal.open { display:flex; align-items:flex-start; justify-content:center; }
.ks-ofert-modal-box { background:#fff; border-radius:20px; box-shadow:0 20px 60px rgba(0,0,0,0.18); width:100%; max-width:860px; margin:auto; overflow:hidden; }
.ks-ofert-modal-header { background:var(--ks-primary); color:#fff; padding:20px 28px; display:flex; align-items:center; gap:12px; }
.ks-ofert-modal-header h3 { margin:0; font-size:1.125rem; font-weight:700; flex:1; color:#fff; }
.ks-ofert-modal-close { background:rgba(255,255,255,0.2); border:none; color:#fff; width:32px; height:32px; border-radius:8px; cursor:pointer; font-size:1.25rem; display:flex; align-items:center; justify-content:center; }
.ks-ofert-modal-body { padding:28px; overflow-y:auto; max-height:calc(100vh - 120px); }
.ks-ofert-section { margin-bottom:24px; }
.ks-ofert-section-title { font-size:0.75rem; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:var(--ks-text-muted); margin-bottom:12px; padding-bottom:6px; border-bottom:1px solid var(--ks-border); }
.ks-ofert-row { display:grid; gap:12px; margin-bottom:12px; }
.ks-ofert-row-2 { grid-template-columns:1fr 1fr; }
.ks-ofert-row-3 { grid-template-columns:1fr 1fr 1fr; }
.ks-ofert-label { display:block; font-size:0.8125rem; font-weight:600; color:var(--ks-text-muted); margin-bottom:4px; }
.ks-ofert-input { width:100%; box-sizing:border-box; border:1.5px solid var(--ks-border); border-radius:10px; padding:9px 12px; font-size:0.9375rem; color:var(--ks-text); background:#fff; transition:border-color .2s; }
.ks-ofert-input:focus { outline:none; border-color:var(--ks-primary); box-shadow:0 0 0 3px rgba(79,70,229,.1); }
/* Items table */
.ks-ofert-items-table { width:100%; border-collapse:collapse; }
.ks-ofert-items-table th { font-size:0.75rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--ks-text-muted); padding:6px 8px; text-align:left; border-bottom:2px solid var(--ks-border); }
.ks-ofert-items-table td { padding:6px 4px; vertical-align:top; }
.ks-ofert-items-table td input, .ks-ofert-items-table td select { border:1.5px solid var(--ks-border); border-radius:8px; padding:7px 8px; font-size:0.875rem; width:100%; box-sizing:border-box; background:#fff; color:var(--ks-text); }
.ks-ofert-items-table td input:focus, .ks-ofert-items-table td select:focus { outline:none; border-color:var(--ks-primary); }
.ks-ofert-items-table td.ks-ofert-calc { padding:7px 8px; font-size:0.875rem; color:var(--ks-text-muted); white-space:nowrap; }
.ks-ofert-row-actions { display:flex; gap:4px; }
.ks-ofert-btn-icon { background:none; border:none; cursor:pointer; border-radius:7px; padding:5px; color:var(--ks-text-muted); transition:background .15s,color .15s; }
.ks-ofert-btn-icon:hover { background:#F1F5F9; color:var(--ks-primary); }
.ks-ofert-btn-icon.delete:hover { background:#FFF1F2; color:var(--ks-danger); }
.ks-ofert-add-row-btn { display:inline-flex; align-items:center; gap:6px; background:none; border:1.5px dashed var(--ks-border); color:var(--ks-text-muted); font-size:0.875rem; font-weight:600; padding:8px 14px; border-radius:10px; cursor:pointer; margin-top:8px; transition:border-color .2s, color .2s; }
.ks-ofert-add-row-btn:hover { border-color:var(--ks-primary); color:var(--ks-primary); }
/* Summary */
.ks-ofert-summary { background:#F9FAFB; border:1px solid var(--ks-border); border-radius:12px; padding:16px 20px; margin-top:16px; }
.ks-ofert-summary-row { display:flex; justify-content:space-between; align-items:center; padding:5px 0; font-size:0.9375rem; }
.ks-ofert-summary-row.total { font-size:1.0625rem; font-weight:800; border-top:2px solid var(--ks-border); margin-top:6px; padding-top:10px; color:var(--ks-primary); }
/* Autocomplete */
.ks-ofert-autocomplete-wrap { position:relative; }
.ks-ofert-suggestions { position:absolute; top:100%; left:0; right:0; background:#fff; border:1.5px solid var(--ks-primary); border-top:none; border-radius:0 0 10px 10px; z-index:100; max-height:180px; overflow-y:auto; box-shadow:0 8px 20px rgba(0,0,0,0.1); }
.ks-ofert-suggestion-item { padding:9px 12px; font-size:0.9rem; cursor:pointer; }
.ks-ofert-suggestion-item:hover { background:#F5F3FF; color:var(--ks-primary); }
/* Ready notes */
.ks-ofert-ready-notes { display:flex; flex-wrap:wrap; gap:8px; margin-top:8px; }
.ks-ofert-note-chip { background:#F1F5F9; border:1.5px solid var(--ks-border); border-radius:20px; font-size:0.8125rem; padding:5px 14px; cursor:pointer; transition:background .15s, border-color .15s; }
.ks-ofert-note-chip:hover { background:#EEF2FF; border-color:var(--ks-primary); color:var(--ks-primary); }
/* Footer */
.ks-ofert-modal-footer { padding:20px 28px; border-top:1px solid var(--ks-border); display:flex; gap:12px; justify-content:flex-end; background:#FAFBFC; }
@media(max-width:600px){
	.ks-ofert-row-2 { grid-template-columns:1fr; }
	.ks-ofert-row-3 { grid-template-columns:1fr; }
	.ks-ofert-modal-body { padding:16px; }
	.ks-ofert-items-table { font-size:0.8rem; }
	.ks-ofert-modal-footer { flex-direction:column-reverse; }
	.ks-ofert-modal-footer button { width:100%; justify-content:center; }
}
/* Offer preview modal — full-screen iframe */
#ks-ofert-preview-modal { display:none; position:fixed; inset:0; z-index:9100; background:#000; flex-direction:column; }
#ks-ofert-preview-modal.open { display:flex; }
.ks-ofert-preview-header { background:#fff; padding:12px 20px; border-bottom:1px solid #e2e8f0; display:flex; align-items:center; justify-content:space-between; flex-shrink:0; }
.ks-ofert-preview-frame { flex:1; border:none; width:100%; display:block; background:#f8fafc; }
</style>

<?php if ( $ofert_sent ) : ?>
	<div class="ks-alert-banner" style="background:var(--ks-success-light); color:var(--ks-success); border-color:var(--ks-success); margin-bottom:24px;">
		<span style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
			<i data-lucide="send" style="width:18px; height:18px; flex-shrink:0;"></i>
			<strong>Oferta wysłana<?php if ( $ofert_sent_to ) : ?> na: <?php echo esc_html( $ofert_sent_to ); ?><?php endif; ?>!</strong>
		</span>
	</div>
<?php endif; ?>
<?php if ( $ofert_error ) : ?>
	<div class="ks-alert-banner ks-alert-banner-danger" style="margin-bottom:24px;">
		<span style="display:flex; align-items:center; gap:8px;">
			<i data-lucide="alert-circle" style="width:18px; height:18px; flex-shrink:0;"></i>
			<?php if ( 'invalid_email' === $ofert_error_msg ) : ?>
				Nieprawidłowy adres e-mail klienta. Sprawdź adres i spróbuj ponownie.
			<?php elseif ( 'no_items' === $ofert_error_msg ) : ?>
				Oferta musi zawierać co najmniej jedną pozycję.
			<?php else : ?>
				Wystąpił błąd. Sprawdź dane i spróbuj ponownie.
			<?php endif; ?>
		</span>
	</div>
<?php endif; ?>

<!-- Intro card -->
<div style="background:#fff; padding:40px; border-radius:20px; border:1px solid var(--ks-border); box-shadow:var(--ks-shadow); max-width:640px;">
	<div style="display:flex; align-items:center; gap:20px; margin-bottom:20px;">
		<div style="width:60px; height:60px; background:rgba(79,70,229,0.1); border-radius:16px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
			<i data-lucide="file-check" style="color:var(--ks-primary); width:30px; height:30px;"></i>
		</div>
		<div>
			<h3 style="font-size:1.125rem; font-weight:700; margin:0 0 4px;">Utwórz i wyślij ofertę</h3>
			<p style="font-size:0.9rem; color:var(--ks-text-muted); margin:0;">Wypełnij formularz i wyślij profesjonalną ofertę e-mailem do klienta.</p>
		</div>
	</div>
	<ul style="font-size:0.9rem; color:var(--ks-text-muted); line-height:1.8; margin:0 0 28px 20px; padding:0;">
		<li>Dane firmy pobierane automatycznie z wizytówki</li>
		<li>Automatyczne wyliczenia netto / VAT / brutto</li>
		<li>Opcjonalna kopia na Twój e-mail</li>
	</ul>
	<button type="button" onclick="ksOpenOfertModal()" class="ks-btn-primary" style="padding:14px 32px; font-size:1rem; border-radius:12px; display:inline-flex; align-items:center; gap:8px;">
		<i data-lucide="plus" style="width:20px; height:20px;"></i> Utwórz ofertę
	</button>
</div>

<!-- ── MODAL ──────────────────────────────────── -->
<div id="ks-ofert-modal" role="dialog" aria-modal="true" aria-label="Formularz oferty">
	<div class="ks-ofert-modal-box">
		<div class="ks-ofert-modal-header">
			<i data-lucide="file-check" style="width:22px; height:22px;"></i>
			<h3>Nowa oferta</h3>
			<button type="button" class="ks-ofert-modal-close" onclick="ksCloseOfertModal()" aria-label="Zamknij">&times;</button>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="ks-ofert-form">
			<input type="hidden" name="action" value="ks_send_ofertomat">
			<?php wp_nonce_field( 'ks_send_ofertomat', 'ks_send_ofertomat_nonce' ); ?>

			<div class="ks-ofert-modal-body">

				<!-- Company info (read-only) -->
				<div class="ks-ofert-section">
					<div class="ks-ofert-section-title">Dane serwisanta</div>
					<div style="display:flex; align-items:center; gap:12px; background:#F9FAFB; padding:12px 16px; border-radius:12px; border:1px solid var(--ks-border);">
						<?php if ( $company_logo ) : ?>
							<img src="<?php echo esc_url( $company_logo ); ?>" style="height:44px; width:auto; max-width:100px; object-fit:contain; border-radius:8px;" alt="Logo">
						<?php else : ?>
							<div style="width:44px; height:44px; background:#E2E8F0; border-radius:8px; flex-shrink:0;"></div>
						<?php endif; ?>
						<div style="flex:1; min-width:0;">
							<strong style="font-size:0.9375rem;"><?php echo esc_html( $company_name ); ?></strong>
							<?php if ( $company_phone ) : ?>
								<span style="color:var(--ks-text-muted); font-size:0.875rem;"> &bull; <?php echo esc_html( $company_phone ); ?></span>
							<?php endif; ?>
							<?php if ( $company_city ) : ?>
								<div style="font-size:0.8125rem; color:var(--ks-text-muted); margin-top:2px;"><?php echo esc_html( $company_city ); ?><?php if ( $company_url ) : ?> &bull; <a href="<?php echo esc_url( $company_url ); ?>" target="_blank" rel="noopener noreferrer" style="color:var(--ks-primary);"><?php echo esc_html( $company_url ); ?></a><?php endif; ?></div>
							<?php endif; ?>
						</div>
						<a href="?ks_tab=wizytowka" style="font-size:0.8125rem; color:var(--ks-primary); font-weight:600; white-space:nowrap; text-decoration:none;">Edytuj →</a>
					</div>
				</div>

				<!-- Client data -->
				<div class="ks-ofert-section">
					<div class="ks-ofert-section-title">Dane klienta</div>
					<div class="ks-ofert-row ks-ofert-row-2">
						<div>
							<label class="ks-ofert-label" for="ofert_client_name">Imię i nazwisko</label>
							<input type="text" id="ofert_client_name" name="ofert_client_name" class="ks-ofert-input" placeholder="Jan Kowalski">
						</div>
						<div>
							<label class="ks-ofert-label" for="ofert_client_email">E-mail klienta <span style="color:var(--ks-danger);">*</span></label>
							<input type="email" id="ofert_client_email" name="ofert_client_email" class="ks-ofert-input" required placeholder="klient@example.com">
						</div>
					</div>
					<div class="ks-ofert-row ks-ofert-row-2">
						<div>
							<label class="ks-ofert-label" for="ofert_client_phone">Telefon klienta</label>
							<input type="tel" id="ofert_client_phone" name="ofert_client_phone" class="ks-ofert-input" placeholder="+48 123 456 789">
						</div>
						<div>
							<label class="ks-ofert-label" for="ofert_client_address">Adres instalacji</label>
							<input type="text" id="ofert_client_address" name="ofert_client_address" class="ks-ofert-input" placeholder="ul. Przykładowa 1, Warszawa">
						</div>
					</div>
				</div>

				<!-- Offer title -->
				<div class="ks-ofert-section">
					<div class="ks-ofert-section-title">Tytuł oferty</div>
					<input type="text" name="ofert_title" class="ks-ofert-input" placeholder="np. Oferta montażu klimatyzacji" style="max-width:100%;">
				</div>

				<!-- Line items -->
				<div class="ks-ofert-section">
					<div class="ks-ofert-section-title">Pozycje oferty</div>
					<div style="overflow-x:auto;">
						<table class="ks-ofert-items-table" id="ks-ofert-items">
							<thead>
								<tr>
									<th style="min-width:180px;">Nazwa</th>
									<th style="min-width:120px;">Opis</th>
									<th style="width:60px;">Ilość</th>
									<th style="width:110px;">Jedn. cena netto</th>
									<th style="width:85px;">VAT</th>
									<th style="width:100px;">Wartość netto</th>
									<th style="width:90px;">Wartość VAT</th>
									<th style="width:110px;">Wartość brutto</th>
									<th style="width:64px;"></th>
								</tr>
							</thead>
							<tbody id="ks-ofert-rows">
								<!-- Rows injected by JS -->
							</tbody>
						</table>
					</div>
					<button type="button" class="ks-ofert-add-row-btn" onclick="ksOfertAddRow()">
						<i data-lucide="plus" style="width:16px;height:16px;"></i> Dodaj pozycję
					</button>
				</div>

				<!-- Summary -->
				<div class="ks-ofert-section">
					<div class="ks-ofert-section-title">Podsumowanie</div>
					<div class="ks-ofert-summary">
						<div class="ks-ofert-summary-row">
							<span>Suma netto</span>
							<span id="ks-ofert-sum-net">0,00 zł</span>
						</div>
						<div class="ks-ofert-summary-row">
							<span>Suma VAT</span>
							<span id="ks-ofert-sum-vat">0,00 zł</span>
						</div>
						<div class="ks-ofert-summary-row" style="margin-top:4px;">
							<label style="font-size:0.875rem; color:var(--ks-text-muted);">Rabat (zł)</label>
							<input type="number" name="ofert_discount" id="ofert_discount" min="0" step="0.01" class="ks-ofert-input" style="width:120px; text-align:right;" placeholder="0" oninput="ksOfertCalc()">
						</div>
						<div class="ks-ofert-summary-row total">
							<span>Suma brutto</span>
							<span id="ks-ofert-sum-gross"><strong>0,00 zł</strong></span>
						</div>
					</div>
					<!-- Hidden totals sent with form -->
					<input type="hidden" name="ofert_sum_net" id="ofert_sum_net_hidden" value="0">
					<input type="hidden" name="ofert_sum_vat" id="ofert_sum_vat_hidden" value="0">
					<input type="hidden" name="ofert_sum_gross" id="ofert_sum_gross_hidden" value="0">
				</div>

				<!-- Notes -->
				<div class="ks-ofert-section">
					<div class="ks-ofert-section-title">Uwagi do oferty</div>
					<textarea name="ofert_notes" id="ofert_notes" class="ks-ofert-input" rows="3" placeholder="Dodatkowe informacje dla klienta..." style="resize:vertical;"></textarea>
				</div>

				<!-- Validity date & conditions -->
				<div class="ks-ofert-row ks-ofert-row-2" style="margin-bottom:24px;">
					<div>
						<label class="ks-ofert-label" for="ofert_valid_until">Termin ważności oferty</label>
						<input type="date" id="ofert_valid_until" name="ofert_valid_until" class="ks-ofert-input">
					</div>
					<div>
						<label class="ks-ofert-label" for="ofert_conditions">Warunki realizacji</label>
						<input type="text" id="ofert_conditions" name="ofert_conditions" class="ks-ofert-input" placeholder="np. Płatność z góry">
					</div>
				</div>

				<!-- Send section -->
				<div class="ks-ofert-section" style="background:#F9FAFB; padding:20px; border-radius:14px; border:1px solid var(--ks-border);">
					<div class="ks-ofert-section-title" style="margin-bottom:14px;">Wysyłka</div>
					<div class="ks-ofert-row ks-ofert-row-2">
						<div>
							<label class="ks-ofert-label" for="ofert_send_email">E-mail klienta <span style="color:var(--ks-danger);">*</span></label>
							<input type="email" id="ofert_send_email" name="ofert_send_email" class="ks-ofert-input" required placeholder="klient@example.com">
						</div>
						<div style="display:flex; flex-direction:column; justify-content:flex-end; padding-bottom:2px;">
							<label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-size:0.9rem; font-weight:600;">
								<input type="checkbox" name="ofert_copy_to_me" value="1" checked style="width:18px; height:18px; accent-color:var(--ks-primary);">
								Wyślij kopię oferty na mój e-mail
							</label>
							<span style="font-size:0.8rem; color:var(--ks-text-muted); margin-top:4px; padding-left:28px;"><?php echo esc_html( $technician_email ); ?></span>
						</div>
					</div>
				</div>

			</div><!-- /.ks-ofert-modal-body -->

			<!-- RODO consent for electronic sending + VAT verification -->
			<div style="padding:16px 24px; border-top:1px solid var(--ks-border); background:#FFFBEB;">
				<label style="display:flex; align-items:flex-start; gap:10px; font-weight:400; cursor:pointer; line-height:1.4;">
					<input type="checkbox" name="ks_ofert_send_consent" value="1" required style="margin-top:3px; flex-shrink:0; accent-color:var(--ks-primary); width:16px; height:16px;">
					<span style="font-size:0.8125rem; color:var(--ks-text-muted);">Potwierdzam, że posiadam zgodę odbiorcy na przesłanie oferty drogą elektroniczną zgodnie z art. 398 PKE i RODO oraz że zweryfikowałem poprawność wyliczeń oraz stawek VAT w generowanej ofercie i akceptuję ich treść. <span style="color:var(--ks-danger); font-weight:700;">(wymagane)</span></span>
				</label>
			</div>

			<div class="ks-ofert-modal-footer">
				<button type="button" onclick="ksCloseOfertModal()" style="background:none; border:1.5px solid var(--ks-border); color:var(--ks-text-muted); padding:11px 24px; border-radius:10px; font-size:0.9375rem; font-weight:600; cursor:pointer;">Anuluj</button>
				<button type="button" onclick="ksOfertPreview()" style="background:none; border:1.5px solid var(--ks-primary); color:var(--ks-primary); padding:11px 24px; border-radius:10px; font-size:0.9375rem; font-weight:600; cursor:pointer; display:inline-flex; align-items:center; gap:8px;">
					<i data-lucide="eye" style="width:18px; height:18px;"></i> Podgląd oferty
				</button>
				<button type="submit" class="ks-btn-primary" style="padding:11px 28px; font-size:0.9375rem; display:inline-flex; align-items:center; gap:8px;">
					<i data-lucide="send" style="width:18px; height:18px;"></i> Wyślij ofertę
				</button>
			</div>

		</form>
	</div>
</div>

<!-- Offer preview modal -->
<div id="ks-ofert-preview-modal" role="dialog" aria-modal="true" aria-label="Podgląd oferty">
	<div class="ks-ofert-preview-header">
		<strong style="font-size:1rem; display:flex; align-items:center; gap:8px;"><i data-lucide="eye" style="width:18px; height:18px; color:var(--ks-primary);"></i> Podgląd oferty</strong>
		<button type="button" onclick="ksCloseOfertPreview()" style="background:none; border:none; cursor:pointer; color:#64748b; padding:4px; border-radius:8px; line-height:0;" aria-label="Zamknij podgląd">
			<i data-lucide="x" style="width:22px; height:22px;"></i>
		</button>
	</div>
	<iframe id="ks-ofert-preview-frame" class="ks-ofert-preview-frame" title="Podgląd oferty"></iframe>
</div>

<script>
(function(){
/* ── Ofertomat JS ─────────────────────────────── */
var LS_KEY = 'ks_ofert_suggestions_<?php echo (int) $current_user_id; ?>';

// ── Company data (from PHP) for preview ──
var KS_CO = {
	name:  <?php echo wp_json_encode( $company_name, JSON_UNESCAPED_UNICODE ); ?>,
	phone: <?php echo wp_json_encode( $company_phone, JSON_UNESCAPED_UNICODE ); ?>,
	city:  <?php echo wp_json_encode( $company_city, JSON_UNESCAPED_UNICODE ); ?>,
	url:   <?php echo wp_json_encode( $company_url, JSON_UNESCAPED_UNICODE ); ?>,
	logo:  <?php echo wp_json_encode( $company_logo ?: '', JSON_UNESCAPED_UNICODE ); ?>
};

// ── Modal open/close ──
window.ksOpenOfertModal = function() {
	var modal = document.getElementById('ks-ofert-modal');
	modal.classList.add('open');
	document.body.style.overflow = 'hidden';
	// Sync client e-mail field with send field
	document.getElementById('ofert_client_email').addEventListener('input', function(){
		document.getElementById('ofert_send_email').value = this.value;
	});
	// Ensure at least one row
	if ( document.getElementById('ks-ofert-rows').children.length === 0 ) {
		ksOfertAddRow();
	}
	if (typeof lucide !== 'undefined') { lucide.createIcons(); }
};
window.ksCloseOfertModal = function() {
	document.getElementById('ks-ofert-modal').classList.remove('open');
	document.body.style.overflow = '';
};
// Close on backdrop click
document.getElementById('ks-ofert-modal').addEventListener('click', function(e){
	if (e.target === this) { ksCloseOfertModal(); }
});

// ── Suggestions (localStorage) ──
function getSuggestions() {
	try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); } catch(e){ return []; }
}
function saveSuggestion(name) {
	if (!name || name.length < 2) return;
	var arr = getSuggestions().filter(function(s){ return s !== name; });
	arr.unshift(name);
	arr = arr.slice(0, 30);
	try { localStorage.setItem(LS_KEY, JSON.stringify(arr)); } catch(e){}
}

// ── Row counter ──
var ksOfertRowIdx = 0;

window.ksOfertAddRow = function(data) {
	data = data || {};
	var idx = ksOfertRowIdx++;
	var tbody = document.getElementById('ks-ofert-rows');
	var tr = document.createElement('tr');
	tr.dataset.idx = idx;
	var vatOpts = ['23','8','5','0','zw'];
	var vatSel = '<select name="ofert_items['+idx+'][vat]" onchange="ksOfertCalc()" style="min-width:76px;">';
	vatOpts.forEach(function(v){
		vatSel += '<option value="'+v+'"'+(data.vat===v?' selected':'')+'>'+v+'%</option>';
	});
	vatSel += '</select>';
	tr.innerHTML =
		'<td><div class="ks-ofert-autocomplete-wrap">'
		+'<input type="text" name="ofert_items['+idx+'][name]" value="'+ksEsc(data.name||'')+'" placeholder="Nazwa pozycji" autocomplete="off" '
		+'oninput="ksOfertSuggest(this,'+idx+')" onblur="ksHideSuggest('+idx+')" style="min-width:150px;">'
		+'<div class="ks-ofert-suggestions" id="ks-sug-'+idx+'" style="display:none;"></div>'
		+'</div></td>'
		+'<td><input type="text" name="ofert_items['+idx+'][desc]" value="'+ksEsc(data.desc||'')+'" placeholder="Opis (opcjonalnie)" style="min-width:100px;"></td>'
		+'<td><input type="number" name="ofert_items['+idx+'][qty]" value="'+ksEsc(data.qty||'1')+'" min="1" step="1" oninput="ksOfertCalc()" style="width:60px; text-align:right;"></td>'
		+'<td><input type="number" name="ofert_items['+idx+'][price_net]" value="'+ksEsc(data.price_net||'')+'" min="0" step="0.01" oninput="ksOfertCalc()" placeholder="0.00" style="width:85px; text-align:right;"></td>'
		+'<td>'+vatSel+'</td>'
		+'<td class="ks-ofert-calc" id="ks-row-net-'+idx+'">–</td>'
		+'<td class="ks-ofert-calc" id="ks-row-vat-'+idx+'">–</td>'
		+'<td class="ks-ofert-calc" id="ks-row-gross-'+idx+'">–</td>'
		+'<td><div class="ks-ofert-row-actions">'
		+'<button type="button" class="ks-ofert-btn-icon" title="Duplikuj" onclick="ksOfertDuplicate('+idx+')" aria-label="Duplikuj pozycję"><i data-lucide="copy" style="width:16px;height:16px;pointer-events:none;"></i></button>'
		+'<button type="button" class="ks-ofert-btn-icon delete" title="Usuń" onclick="ksOfertRemoveRow(this)" aria-label="Usuń pozycję"><i data-lucide="trash-2" style="width:16px;height:16px;pointer-events:none;"></i></button>'
		+'</div></td>';
	tbody.appendChild(tr);
	if (typeof lucide !== 'undefined') { lucide.createIcons(); }
	ksOfertCalc();
	return tr;
};

window.ksOfertRemoveRow = function(btn) {
	var tr = btn.closest('tr');
	if (tr) { tr.remove(); ksOfertCalc(); }
};

window.ksOfertDuplicate = function(idx) {
	var tr = document.querySelector('#ks-ofert-rows tr[data-idx="'+idx+'"]');
	if (!tr) return;
	var name   = tr.querySelector('[name$="[name]"]').value;
	var desc   = tr.querySelector('[name$="[desc]"]').value;
	var qty    = tr.querySelector('[name$="[qty]"]').value;
	var net    = tr.querySelector('[name$="[price_net]"]').value;
	var vat    = tr.querySelector('select[name$="[vat]"]').value;
	var newTr  = ksOfertAddRow({name:name, desc:desc, qty:qty, price_net:net, vat:vat});
	// Insert directly after current row
	tr.parentNode.insertBefore(newTr, tr.nextSibling);
};

// ── Calculations ──
function ksPlFmt(val) {
	return val.toLocaleString('pl-PL', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' zł';
}
window.ksOfertCalc = function() {
	var rows = document.querySelectorAll('#ks-ofert-rows tr');
	var sumNet = 0, sumVat = 0;
	rows.forEach(function(tr){
		var idx      = tr.dataset.idx;
		var qty      = parseFloat(tr.querySelector('[name$="[qty]"]').value) || 0;
		var net      = parseFloat(tr.querySelector('[name$="[price_net]"]').value) || 0;
		var vatStr   = tr.querySelector('select[name$="[vat]"]').value;
		var vatRate  = (vatStr === 'zw' || vatStr === '0') ? 0 : (parseFloat(vatStr) / 100);
		var rowNet   = qty * net;
		var rowVat   = rowNet * vatRate;
		var rowGross = rowNet + rowVat;
		sumNet  += rowNet;
		sumVat  += rowVat;
		var elNet   = document.getElementById('ks-row-net-'+idx);
		var elVat   = document.getElementById('ks-row-vat-'+idx);
		var elGross = document.getElementById('ks-row-gross-'+idx);
		if (elNet)   elNet.textContent   = ksPlFmt(rowNet);
		if (elVat)   elVat.textContent   = ksPlFmt(rowVat);
		if (elGross) elGross.textContent = ksPlFmt(rowGross);
	});
	var discount = parseFloat(document.getElementById('ofert_discount').value) || 0;
	var gross    = sumNet + sumVat - discount;
	document.getElementById('ks-ofert-sum-net').textContent   = ksPlFmt(sumNet);
	document.getElementById('ks-ofert-sum-vat').textContent   = ksPlFmt(sumVat);
	document.getElementById('ks-ofert-sum-gross').innerHTML   = '<strong>' + ksPlFmt(gross) + '</strong>';
	document.getElementById('ofert_sum_net_hidden').value     = sumNet.toFixed(2);
	document.getElementById('ofert_sum_vat_hidden').value     = sumVat.toFixed(2);
	document.getElementById('ofert_sum_gross_hidden').value   = gross.toFixed(2);
};

// ── Autocomplete ──
window.ksOfertSuggest = function(input, idx) {
	var q    = input.value.trim().toLowerCase();
	var box  = document.getElementById('ks-sug-'+idx);
	if (!box) return;
	if (q.length < 1) { box.style.display='none'; return; }
	var all  = getSuggestions().filter(function(s){ return s.toLowerCase().indexOf(q) !== -1; });
	if (!all.length) { box.style.display='none'; return; }
	box.innerHTML = '';
	all.slice(0,8).forEach(function(s){
		var div = document.createElement('div');
		div.className = 'ks-ofert-suggestion-item';
		div.textContent = s;
		div.onmousedown = function(e){
			e.preventDefault();
			input.value = s;
			box.style.display='none';
			ksOfertCalc();
		};
		box.appendChild(div);
	});
	box.style.display = 'block';
};
window.ksHideSuggest = function(idx) {
	var box = document.getElementById('ks-sug-'+idx);
	if (box) { setTimeout(function(){ box.style.display='none'; }, 150); }
};

// ── Ready notes ──
window.ksInsertNote = function(note) {
	var ta = document.getElementById('ofert_notes');
	if (!ta) return;
	var sep = ta.value && ta.value[ta.value.length-1] !== '\n' ? '\n' : '';
	ta.value += sep + note;
};

// ── Save suggestions on submit ──
document.getElementById('ks-ofert-form').addEventListener('submit', function(){
	document.querySelectorAll('#ks-ofert-rows [name$="[name]"]').forEach(function(inp){
		if (inp.value.trim()) saveSuggestion(inp.value.trim());
	});
});

// ── Preview ──
window.ksOfertPreview = function() {
	var title       = document.querySelector('[name="ofert_title"]').value.trim() || 'Oferta handlowa';
	var clientName  = document.querySelector('[name="ofert_client_name"]').value.trim();
	var clientEmail = document.getElementById('ofert_send_email').value.trim();
	var clientPhone = document.querySelector('[name="ofert_client_phone"]').value.trim();
	var clientAddr  = document.querySelector('[name="ofert_client_address"]').value.trim();
	var notes       = document.getElementById('ofert_notes').value.trim();
	var validUntil  = document.getElementById('ofert_valid_until').value;
	var conditions  = document.getElementById('ofert_conditions').value.trim();
	var discount    = parseFloat(document.getElementById('ofert_discount').value) || 0;
	var today       = new Date().toLocaleDateString('pl-PL', {day:'2-digit',month:'2-digit',year:'numeric'});

	// Collect items
	var rows = document.querySelectorAll('#ks-ofert-rows tr');
	var itemRows = '';
	var sumNet = 0, sumVat = 0;
	rows.forEach(function(tr){
		var name = tr.querySelector('[name$="[name]"]').value.trim();
		if (!name) return;
		var desc    = tr.querySelector('[name$="[desc]"]').value.trim();
		var qty     = parseFloat(tr.querySelector('[name$="[qty]"]').value) || 0;
		var net     = parseFloat(tr.querySelector('[name$="[price_net]"]').value) || 0;
		var vatStr  = tr.querySelector('select[name$="[vat]"]').value;
		var vatRate = (vatStr === 'zw' || vatStr === '0') ? 0 : parseFloat(vatStr) / 100;
		var rNet    = qty * net;
		var rVat    = rNet * vatRate;
		var rGross  = rNet + rVat;
		sumNet += rNet; sumVat += rVat;
		itemRows += '<tr><td><strong>' + ksEscHtml(name) + '</strong>'
			+ (desc ? '<br><span style="color:#64748b;font-size:12px;">' + ksEscHtml(desc) + '</span>' : '')
			+ '</td>'
			+ '<td class="num">' + qty.toLocaleString('pl-PL',{minimumFractionDigits:2,maximumFractionDigits:2}) + '</td>'
			+ '<td class="num">' + net.toLocaleString('pl-PL',{minimumFractionDigits:2,maximumFractionDigits:2}) + ' zł</td>'
			+ '<td class="num">' + vatStr + '%</td>'
			+ '<td class="num">' + rNet.toLocaleString('pl-PL',{minimumFractionDigits:2,maximumFractionDigits:2}) + ' zł</td>'
			+ '<td class="num">' + rVat.toLocaleString('pl-PL',{minimumFractionDigits:2,maximumFractionDigits:2}) + ' zł</td>'
			+ '<td class="num"><strong>' + rGross.toLocaleString('pl-PL',{minimumFractionDigits:2,maximumFractionDigits:2}) + ' zł</strong></td></tr>';
	});
	var gross = sumNet + sumVat - discount;
	function fmt(v){ return v.toLocaleString('pl-PL',{minimumFractionDigits:2,maximumFractionDigits:2}) + ' zł'; }

	var discountRow = discount > 0
		? '<tr><td>Rabat:</td><td>&minus; ' + fmt(discount) + '</td></tr>'
		: '';

	var logoHtml = KS_CO.logo
		? '<span class="header-logo-wrap"><img src="' + ksEscAttr(KS_CO.logo) + '" class="header-logo" alt="' + ksEscAttr(KS_CO.name) + '"></span>'
		: '';

	var html = '<!DOCTYPE html><html lang="pl"><head><meta charset="UTF-8">'
		+ '<meta name="viewport" content="width=device-width,initial-scale=1">'
		+ '<title>Podgląd: ' + ksEscHtml(title) + '</title>'
		+ '<style>'
		+ 'body{font-family:Arial,sans-serif;color:#1e293b;margin:0;padding:0;background:#f8fafc;}'
		+ '.wrap{max-width:680px;margin:30px auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08);}'
		+ '.header{background:#4F46E5;color:#fff;padding:28px 40px;display:flex;align-items:center;gap:20px;}'
		+ '.header-logo-wrap{background:#fff;border-radius:10px;padding:8px;flex-shrink:0;display:inline-flex;align-items:center;justify-content:center;}'
		+ '.header-logo{width:64px;height:64px;object-fit:contain;max-width:112px;display:block;}'
		+ '.header-text h1{margin:0 0 4px;font-size:22px;color:#fff;}'
		+ '.header-text p{margin:0;opacity:.8;font-size:14px;}'
		+ '.body{padding:32px 40px;}'
		+ '.section-title{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#64748b;margin:24px 0 10px;border-bottom:1px solid #f1f5f9;padding-bottom:6px;}'
		+ '.info-row{display:flex;gap:12px;margin-bottom:6px;font-size:14px;}'
		+ '.info-label{color:#64748b;min-width:160px;flex-shrink:0;}'
		+ 'table.items{width:100%;border-collapse:collapse;font-size:14px;}'
		+ 'table.items th{background:#f1f5f9;color:#475569;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;padding:8px 10px;text-align:left;}'
		+ 'table.items td{padding:9px 10px;border-bottom:1px solid #f1f5f9;vertical-align:top;}'
		+ 'table.items tr:last-child td{border-bottom:none;}'
		+ '.num{text-align:right;white-space:nowrap;}'
		+ '.summary-table{width:100%;border-collapse:collapse;font-size:14px;max-width:300px;margin-left:auto;margin-top:12px;}'
		+ '.summary-table td{padding:6px 10px;}'
		+ '.summary-table td:last-child{text-align:right;font-weight:600;}'
		+ '.summary-table tr.total td{border-top:2px solid #e2e8f0;font-size:16px;font-weight:800;color:#4F46E5;padding-top:10px;}'
		+ '.notes-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px 16px;font-size:14px;line-height:1.6;margin-top:8px;white-space:pre-wrap;}'
		+ '.footer-contact{margin-top:28px;border-top:2px solid #e2e8f0;padding-top:18px;font-size:13px;color:#64748b;}'
		+ '.preview-banner{background:#FEF9C3;border-bottom:2px solid #FDE047;padding:10px 20px;font-size:13px;font-weight:600;color:#854D0E;text-align:center;}'
		+ '@media(max-width:600px){.body{padding:20px;}.header{padding:20px;flex-direction:column;}.info-label{min-width:110px;}}'
		+ '</style></head><body>'
		+ '<div class="preview-banner">⚠ To jest podgląd oferty – e-mail nie został jeszcze wysłany</div>'
		+ '<div class="wrap">'
		+ '<div class="header">' + logoHtml
		+ '<div class="header-text"><h1>' + ksEscHtml(title) + '</h1>'
		+ '<p>' + ksEscHtml(KS_CO.name) + (KS_CO.phone ? ' &bull; ' + ksEscHtml(KS_CO.phone) : '') + '</p>'
		+ '</div></div>'
		+ '<div class="body">'
		// Company section
		+ '<div class="section-title">Dane serwisanta</div>'
		+ '<div class="info-row"><span class="info-label">Firma:</span><strong>' + ksEscHtml(KS_CO.name) + '</strong></div>'
		+ (KS_CO.phone ? '<div class="info-row"><span class="info-label">Telefon:</span>' + ksEscHtml(KS_CO.phone) + '</div>' : '')
		+ (KS_CO.city  ? '<div class="info-row"><span class="info-label">Miasto:</span>' + ksEscHtml(KS_CO.city)  + '</div>' : '')
		+ (KS_CO.url   ? '<div class="info-row"><span class="info-label">Strona:</span><a href="' + ksEscAttr(KS_CO.url) + '" style="color:#4F46E5;">' + ksEscHtml(KS_CO.url) + '</a></div>' : '')
		// Client section
		+ ((clientName || clientEmail || clientPhone || clientAddr)
			? '<div class="section-title">Dane klienta</div>'
			  + (clientName  ? '<div class="info-row"><span class="info-label">Imię i nazwisko:</span><strong>' + ksEscHtml(clientName)  + '</strong></div>' : '')
			  + (clientEmail ? '<div class="info-row"><span class="info-label">E-mail:</span>' + ksEscHtml(clientEmail) + '</div>' : '')
			  + (clientPhone ? '<div class="info-row"><span class="info-label">Telefon:</span>' + ksEscHtml(clientPhone) + '</div>' : '')
			  + (clientAddr  ? '<div class="info-row"><span class="info-label">Adres instalacji:</span>' + ksEscHtml(clientAddr) + '</div>' : '')
			: '')
		// Items table
		+ '<div class="section-title">Pozycje oferty</div>'
		+ '<div style="overflow-x:auto;-webkit-overflow-scrolling:touch;" tabindex="0">'
		+ '<table class="items"><thead><tr>'
		+ '<th>Nazwa</th><th style="text-align:right;">Ilość</th><th style="text-align:right;">Cena netto</th><th style="text-align:right;">VAT</th>'
		+ '<th style="text-align:right;">Netto</th><th style="text-align:right;">VAT</th><th style="text-align:right;">Brutto</th>'
		+ '</tr></thead><tbody>' + itemRows + '</tbody></table>'
		+ '</div>'
		// Summary
		+ '<table class="summary-table">'
		+ '<tr><td>Suma netto:</td><td>' + fmt(sumNet) + '</td></tr>'
		+ '<tr><td>Suma VAT:</td><td>' + fmt(sumVat) + '</td></tr>'
		+ discountRow
		+ '<tr class="total"><td>Suma brutto:</td><td>' + fmt(gross) + '</td></tr>'
		+ '</table>'
		// Notes
		+ (notes ? '<div class="section-title">Uwagi</div><div class="notes-box">' + ksEscHtml(notes) + '</div>' : '')
		// Conditions
		+ ((validUntil || conditions)
			? '<div class="section-title">Warunki</div>'
			  + (validUntil  ? '<div class="info-row"><span class="info-label">Ważność oferty:</span>' + ksEscHtml(validUntil)  + '</div>' : '')
			  + (conditions  ? '<div class="info-row"><span class="info-label">Warunki realizacji:</span>' + ksEscHtml(conditions) + '</div>' : '')
			: '')
		// Footer
		+ '<div class="footer-contact"><strong>' + ksEscHtml(KS_CO.name) + '</strong>'
		+ (KS_CO.phone ? ' &bull; ' + ksEscHtml(KS_CO.phone) : '')
		+ (KS_CO.url   ? ' &bull; <a href="' + ksEscAttr(KS_CO.url) + '" style="color:#4F46E5;">' + ksEscHtml(KS_CO.url) + '</a>' : '')
		+ (KS_CO.city  ? '<br>' + ksEscHtml(KS_CO.city) : '')
		+ '</div>'
		+ '</div></div></body></html>';

	var previewModal = document.getElementById('ks-ofert-preview-modal');
	var previewFrame = document.getElementById('ks-ofert-preview-frame');
	previewFrame.srcdoc = html;
	previewModal.classList.add('open');
	document.body.style.overflow = 'hidden';
};

window.ksCloseOfertPreview = function() {
	document.getElementById('ks-ofert-preview-modal').classList.remove('open');
	document.body.style.overflow = '';
};

// ── HTML escape helpers ──
function ksEscHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function ksEscAttr(s){ return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// ── Escape helper (for JS-generated HTML attributes) ──
function ksEsc(s){
	return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

})();
</script>
<?php endif; ?>
