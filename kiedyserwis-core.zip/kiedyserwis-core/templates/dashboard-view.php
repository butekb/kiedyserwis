<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_user_id = get_current_user_id();

// Wykryj rolę service_manager – potrzebne do pokazania nazwy pracownika na kartach urządzeń.
$_is_service_manager   = in_array( 'service_manager', (array) wp_get_current_user()->roles, true );
$_worker_display_names = array(); // worker_id => display_name
if ( $_is_service_manager ) {
	foreach ( KS_Multi_Account::get_worker_ids_for_manager( $current_user_id ) as $_wid ) {
		$_wd = get_userdata( $_wid );
		if ( $_wd ) {
			$_worker_display_names[ (int) $_wid ] = $_wd->display_name ?: $_wd->user_email;
		}
	}
}

// Handle Filters for Devices
$orderby = isset($_GET['ks_orderby']) ? sanitize_text_field($_GET['ks_orderby']) : 'next_service';
$search = isset($_GET['ks_search']) ? sanitize_text_field($_GET['ks_search']) : '';
$from_filter = isset($_GET['ks_from']) ? sanitize_text_field($_GET['ks_from']) : '';
$to_filter = isset($_GET['ks_to']) ? sanitize_text_field($_GET['ks_to']) : '';

$args = array(
	'post_type'              => 'ks_urzadzenie',
	'posts_per_page'         => -1,
	'author'                 => $current_user_id,
	'post_status'            => 'publish',
	'no_found_rows'          => true,  // We count manually with count()
	'update_post_term_cache' => false, // No taxonomy terms used
		'meta_query'     => array(
			array(
				'key'     => 'ks_is_custom_app',
				'compare' => 'NOT EXISTS',
			),
		),
);

if ( !empty($search) ) {
    $args['meta_query'][] = array(
        'key'     => 'ks_klient_tel',
        'value'   => $search,
        'compare' => 'LIKE'
    );
}

$devices_query = new WP_Query( $args );
$devices = $devices_query->posts;

// Calculate Next Service and device status for sorting/filtering
$today      = ks_warsaw_now()->format( 'Y-m-d' );
$today_year = (int) substr( $today, 0, 4 );
$today_mon  = (int) substr( $today, 5, 2 );
$today_day  = (int) substr( $today, 8, 2 );
$today_ts   = strtotime( $today );
foreach ( $devices as $device ) {
    $last_service = get_post_meta( $device->ID, 'ks_data_serwisu', true );
    $interval = (int) get_post_meta( $device->ID, 'ks_interwal', true );
    $days_before = (int) get_post_meta( $device->ID, 'ks_dni_wyprzedzenia', true );
    $device->next_service_ts = !empty($last_service) ? strtotime( "+$interval months", strtotime( $last_service ) ) : 0;
    $device->next_service_date = $device->next_service_ts > 0 ? date('Y-m-d', $device->next_service_ts) : '';
    if ( $device->next_service_date && $today >= $device->next_service_date ) {
        $device->ks_status = 'overdue';
    } elseif ( $device->next_service_ts > 0 && $today >= date('Y-m-d', strtotime("-$days_before days", $device->next_service_ts)) ) {
        $device->ks_status = 'upcoming';
    } else {
        $device->ks_status = 'ok';
    }
    $device->ks_sms_status = get_post_meta( $device->ID, 'ks_status_sms', true );
}

// Filter Devices list by date range
if ( $from_filter || $to_filter ) {
    $devices = array_filter($devices, function($d) use ($from_filter, $to_filter) {
        $from_match = true;
        $to_match = true;
        if ( !empty($from_filter) ) {
            $from_match = $d->next_service_date >= $from_filter;
        }
        if ( !empty($to_filter) ) {
            $to_match = $d->next_service_date <= $to_filter;
        }
        return $from_match && $to_match;
    });
}

// Filter by notification status when selected
$status_filters = array( 'status_overdue', 'status_upcoming', 'status_upcoming_sms_sent', 'status_ok' );
if ( in_array( $orderby, $status_filters, true ) ) {
    if ( $orderby === 'status_upcoming' ) {
        $devices = array_filter( $devices, function( $d ) {
            return $d->ks_status === 'upcoming' && $d->ks_sms_status !== 'Wysłano';
        } );
    } elseif ( $orderby === 'status_upcoming_sms_sent' ) {
        $devices = array_filter( $devices, function( $d ) {
            return $d->ks_status === 'upcoming' && $d->ks_sms_status === 'Wysłano';
        } );
    } else {
        $status_map = array(
            'status_overdue'  => 'overdue',
            'status_ok'       => 'ok',
        );
        $target_status = $status_map[ $orderby ];
        $devices = array_filter( $devices, function( $d ) use ( $target_status ) {
            return $d->ks_status === $target_status;
        } );
    }
}

usort($devices, function($a, $b) use ($orderby) {
    if ( $orderby === 'next_service_desc' ) return $b->next_service_ts <=> $a->next_service_ts;
    return $a->next_service_ts <=> $b->next_service_ts;
});

$device_count = count($devices);
$active_tab = isset($_GET['ks_tab']) ? sanitize_text_field($_GET['ks_tab']) : 'devices';

// Detect service_worker role for tab restrictions.
$_is_service_worker = in_array( 'service_worker', (array) wp_get_current_user()->roles, true );

// Block service_worker from accessing wizytowka and seo tabs.
if ( $_is_service_worker && in_array( $active_tab, array( 'wizytowka', 'seo' ), true ) ) {
	$active_tab = 'devices';
}

// Low-stock badge for Magazyn menu item
$_low_stock_count = $_is_premium ? ks_get_low_stock_count( $current_user_id ) : 0;

// Pre-calculate device status counts for stats bar (uses pre-computed ks_status)
$stat_red = 0; $stat_yellow = 0; $stat_grey = 0;
foreach ( $devices as $_d ) {
    if ( $_d->ks_status === 'overdue' ) {
        $stat_red++;
    } elseif ( $_d->ks_status === 'upcoming' ) {
        $stat_yellow++;
    } else {
        $stat_grey++;
    }
}

// Pagination: slice devices for display (50 per page), keeping stats over the full set
$_ks_per_page    = 50;
$_ks_page        = max( 1, isset( $_GET['paged'] ) ? intval( $_GET['paged'] ) : 1 );
$_ks_total_pages = (int) ceil( $device_count / max( 1, $_ks_per_page ) );
$devices_paged   = array_slice( $devices, ( $_ks_page - 1 ) * $_ks_per_page, $_ks_per_page );

// Plan data (loaded globally so sidebar and banners can use it)
$_plan_data    = ks_get_plan_data($current_user_id);
$_is_premium   = ks_is_premium_active($current_user_id);
$_is_multi     = ( $_plan_data['status'] === 'multi' ) && $_is_premium;
$_plan_days    = (int) get_user_meta($current_user_id, 'ks_plan_days', true) ?: 30;
$_days_left    = $_is_premium ? (int)ceil(($_plan_data['expiry'] - time()) / DAY_IN_SECONDS) : 0;
$_warn_thresh  = ($_plan_days >= 365) ? 30 : 5;
$_plan_warning = $_is_premium && $_days_left <= $_warn_thresh && $_days_left >= 0;

// Fetch warehouse parts for premium users (used in device add/update modals)
$_magazyn_parts = $_is_premium ? get_posts( array(
	'post_type'              => 'ks_czesc',
	'author'                 => $current_user_id,
	'post_status'            => 'publish',
	'posts_per_page'         => -1,
	'orderby'                => 'title',
	'order'                  => 'ASC',
	'no_found_rows'          => true,
	'update_post_term_cache' => false,
	'suppress_filters'       => false, // Allow pre_get_posts isolation to run.
) ) : array();

// Calendar Logic
$cal_month = isset($_GET['cal_month']) ? intval($_GET['cal_month']) : $today_mon;
$cal_year = isset($_GET['cal_year']) ? intval($_GET['cal_year']) : $today_year;

$first_day = mktime(0, 0, 0, $cal_month, 1, $cal_year);
$days_in_month = (int)date('t', $first_day);
$day_of_week = (int)date('w', $first_day); // 0 (Sun) to 6 (Sat)
if($day_of_week == 0) $day_of_week = 7; // Adjust for Mon start

// Legacy calendar grid data no longer needed (new FullCalendar loads via REST API).
$cal_apps      = [];
$events_by_day = [];
?>

<style>
	@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
	:root {
		--ks-primary: #4F46E5;
		--ks-primary-hover: #4338CA;
		--ks-primary-light: #EEF2FF;
		--ks-success: #10B981;
		--ks-success-light: #D1FAE5;
		--ks-danger: #EF4444;
		--ks-danger-light: #FEE2E2;
		--ks-warning: #F59E0B;
		--ks-warning-light: #FEF3C7;
		--ks-bg: #F1F5F9;
		--ks-sidebar-bg: #0F172A;
		--ks-sidebar-hover: rgba(255,255,255,0.06);
		--ks-card-bg: #FFFFFF;
		--ks-border: #E2E8F0;
		--ks-text-main: #0F172A;
		--ks-text-muted: #64748B;
		--ks-radius: 16px;
		--ks-radius-lg: 20px;
		--ks-shadow-sm: 0 1px 2px rgba(0,0,0,0.06);
		--ks-shadow: 0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.05);
		--ks-shadow-md: 0 4px 6px -1px rgba(0,0,0,0.08), 0 2px 4px -2px rgba(0,0,0,0.04);
		--ks-shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.08), 0 4px 6px -4px rgba(0,0,0,0.04);
	}

	* { box-sizing: border-box; }

	.ks-dashboard-wrapper {
		display: flex;
		min-height: 100vh;
		font-family: 'Inter', system-ui, -apple-system, sans-serif;
		margin: 0;
		background: var(--ks-bg);
		color: var(--ks-text-main);
	}

	/* ===== SIDEBAR ===== */
	.ks-sidebar {
		width: 260px;
		background: var(--ks-sidebar-bg);
		color: #fff;
		padding: 0;
		flex-shrink: 0;
		display: flex;
		flex-direction: column;
		position: sticky;
		top: 0;
		height: 100vh;
		overflow-y: auto;
		box-shadow: 4px 0 24px rgba(0,0,0,0.12);
	}
	.ks-sidebar-brand {
		padding: 28px 24px 20px;
		font-size: 1.125rem;
		font-weight: 800;
		letter-spacing: -0.025em;
		display: flex;
		align-items: center;
		gap: 10px;
		color: #fff;
		border-bottom: 1px solid rgba(255,255,255,0.06);
	}
	.ks-sidebar::-webkit-scrollbar {
		width: 6px;
	}
	.ks-sidebar::-webkit-scrollbar-track {
		background: rgba(255,255,255,0.04);
		border-radius: 10px;
	}
	.ks-sidebar::-webkit-scrollbar-thumb {
		background: rgba(79, 70, 229, 0.8);
		border-radius: 10px;
	}
	.ks-sidebar::-webkit-scrollbar-thumb:hover {
		background: var(--ks-primary-hover);
	}
	.ks-sidebar {
		scrollbar-width: thin;
		scrollbar-color: var(--ks-primary) rgba(255,255,255,0.04);
	}

	.ks-nav-items {
		padding: 16px 12px;
		flex-grow: 1;
	}
	.ks-nav-section-label {
		font-size: 0.6875rem;
		font-weight: 700;
		letter-spacing: 0.08em;
		color: rgba(255,255,255,0.3);
		text-transform: uppercase;
		padding: 12px 16px 6px;
		display: block;
	}
	.ks-nav-item {
		display: flex;
		align-items: center;
		gap: 12px;
		padding: 11px 16px;
		color: rgba(255,255,255,0.6);
		text-decoration: none !important;
		transition: all 0.15s ease;
		font-weight: 500;
		font-size: 0.9375rem;
		border-radius: 10px;
		margin-bottom: 2px;
	}
	.ks-nav-item i { width: 18px; height: 18px; flex-shrink: 0; }
	.ks-nav-item:hover {
		background: var(--ks-sidebar-hover);
		color: #fff !important;
	}
	.ks-nav-item.active {
		background: var(--ks-primary) !important;
		color: #fff !important;
		box-shadow: 0 4px 12px rgba(79, 70, 229, 0.35);
		font-weight: 600;
	}

	/* Submenu */
	.ks-nav-group { display: flex; flex-direction: column; }
	.ks-nav-parent { cursor: pointer; justify-content: space-between; }
	.ks-nav-parent .chevron { transition: transform 0.2s; width: 16px; height: 16px; }
	.ks-nav-parent.open .chevron { transform: rotate(180deg); }
	.ks-submenu { display: none; padding-left: 12px; margin-bottom: 4px; }
	.ks-submenu.active { display: block; }
	.ks-submenu .ks-nav-item { font-size: 0.875rem; padding: 9px 16px; }

	.ks-nav-footer { padding: 12px; border-top: 1px solid rgba(255,255,255,0.06); }
	.ks-nav-item-logout { color: rgba(248,113,113,0.8) !important; border-radius: 10px; }
	.ks-nav-item-logout:hover { background: rgba(239,68,68,0.12) !important; color: #F87171 !important; }

	/* Premium warning badge on nav item */
	.ks-nav-warning-dot {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		background: #F59E0B;
		color: #fff;
		font-size: 0.5625rem;
		font-weight: 800;
		padding: 2px 6px;
		border-radius: 20px;
		margin-left: auto;
		letter-spacing: 0.04em;
		animation: ks-pulse-warn 2s ease-in-out infinite;
	}
	@keyframes ks-pulse-warn {
		0%, 100% { opacity: 1; }
		50% { opacity: 0.6; }
	}
	@keyframes ks-pulse {
		0%, 100% { opacity: 1; transform: scale(1); }
		50% { opacity: 0.75; transform: scale(1.1); }
	}

	/* Calendar agenda view (mobile) */
	.ks-cal-agenda { display: none; }
	.ks-agenda-day {
		background: #fff;
		border-radius: 12px;
		margin-bottom: 12px;
		border: 1px solid var(--ks-border);
		overflow: hidden;
	}
	.ks-agenda-day-header {
		background: #F8FAFC;
		padding: 10px 16px;
		font-size: 0.8125rem;
		font-weight: 700;
		color: var(--ks-text-muted);
		border-bottom: 1px solid var(--ks-border);
		display: flex;
		align-items: center;
		gap: 8px;
	}
	.ks-agenda-day-header.is-today { background: var(--ks-primary-light); color: var(--ks-primary); }
	.ks-agenda-event {
		padding: 12px 16px;
		border-bottom: 1px solid #F1F5F9;
		display: flex;
		align-items: center;
		gap: 12px;
		cursor: pointer;
		transition: background 0.15s;
	}
	.ks-agenda-event:last-child { border-bottom: none; }
	.ks-agenda-event:hover { background: #F8FAFC; }
	.ks-agenda-dot {
		width: 10px; height: 10px;
		border-radius: 50%;
		flex-shrink: 0;
	}
	.ks-agenda-time { font-size: 0.8125rem; font-weight: 700; color: var(--ks-text-muted); min-width: 42px; }
	.ks-agenda-title { font-size: 0.9375rem; font-weight: 600; color: var(--ks-text-main); flex-grow: 1; }
	.ks-agenda-empty { text-align: center; padding: 40px 20px; color: var(--ks-text-muted); font-size: 0.9375rem; }

	/* Mobile slide-up drawers (Narzędzia / Konto) */
	.ks-bnav-drawer {
		display: none;
		position: fixed;
		bottom: 61px; left: 0; right: 0;
		background: var(--ks-sidebar-bg);
		border-top: 1px solid rgba(255,255,255,0.12);
		z-index: 201;
		padding: 8px 12px;
		box-shadow: 0 -4px 16px rgba(0,0,0,0.25);
	}
	.ks-bnav-drawer.open { display: block; }
	.ks-bnav-drawer-link {
		display: flex;
		align-items: center;
		gap: 10px;
		padding: 12px 16px;
		color: rgba(255,255,255,0.7) !important;
		text-decoration: none !important;
		font-size: 0.9375rem;
		font-weight: 500;
		border-radius: 8px;
		transition: background 0.15s;
	}
	.ks-bnav-drawer-link i { width: 18px; height: 18px; }
	.ks-bnav-drawer-link:hover, .ks-bnav-drawer-link.active { background: rgba(255,255,255,0.1); color: #fff !important; }

	/* ===== MAIN CONTENT ===== */
	.ks-content {
		flex-grow: 1;
		padding: 32px 36px;
		background: var(--ks-bg);
		overflow-y: auto;
		min-width: 0;
	}

	.ks-page-header { margin-bottom: 28px; }
	.ks-page-title { font-size: 1.75rem; font-weight: 800; letter-spacing: -0.03em; margin: 0; color: var(--ks-text-main); }
	.ks-page-subtitle { color: var(--ks-text-muted); margin: 6px 0 0 0; font-size: 0.9375rem; }

	.ks-header-flex {
		display: flex;
		justify-content: space-between;
		align-items: center;
		gap: 16px;
	}

	/* ===== STATS ROW ===== */
	.ks-stats-row {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 16px;
		margin-bottom: 24px;
	}
	.ks-stat-card {
		background: var(--ks-card-bg);
		border-radius: var(--ks-radius);
		padding: 20px;
		border: 1px solid var(--ks-border);
		box-shadow: var(--ks-shadow);
		display: flex;
		align-items: center;
		gap: 16px;
	}
	.ks-stat-icon {
		width: 48px; height: 48px;
		border-radius: 12px;
		display: flex; align-items: center; justify-content: center;
		flex-shrink: 0;
	}
	.ks-stat-icon i { width: 22px; height: 22px; }
	.ks-stat-value { font-size: 1.75rem; font-weight: 800; letter-spacing: -0.03em; line-height: 1; margin-bottom: 2px; }
	.ks-stat-label { font-size: 0.8125rem; font-weight: 500; color: var(--ks-text-muted); }

	/* ===== FILTERS BAR ===== */
	.ks-filters-bar {
		background: var(--ks-card-bg);
		padding: 16px 20px;
		border-radius: var(--ks-radius);
		margin-bottom: 24px;
		display: flex;
		gap: 10px;
		flex-wrap: wrap;
		align-items: center;
		border: 1px solid var(--ks-border);
		box-shadow: var(--ks-shadow-sm);
	}
	.ks-filter-input {
		width: 100%;
		padding: 10px 14px;
		border: 1.5px solid var(--ks-border);
		border-radius: 10px;
		font-size: 0.875rem;
		font-family: inherit;
		transition: border-color 0.15s, box-shadow 0.15s;
		background: #F8FAFC;
		color: var(--ks-text-main);
	}
	.ks-filter-input:focus {
		outline: none;
		border-color: var(--ks-primary);
		box-shadow: 0 0 0 3px rgba(79,70,229,0.1);
		background: #fff;
	}
	.ks-filter-select {
		padding: 10px 14px;
		border: 1.5px solid var(--ks-border);
		border-radius: 10px;
		font-size: 0.875rem;
		font-family: inherit;
		background: #F8FAFC;
		color: var(--ks-text-main);
		cursor: pointer;
	}
	.ks-filter-select:focus { outline: none; border-color: var(--ks-primary); }

	/* ===== BUTTONS ===== */
	.ks-btn-primary {
		background: var(--ks-primary);
		color: white !important;
		border: none;
		padding: 11px 22px;
		border-radius: 10px;
		font-weight: 600;
		font-size: 0.9375rem;
		cursor: pointer;
		text-decoration: none !important;
		transition: all 0.15s ease;
		display: inline-flex;
		align-items: center;
		gap: 8px;
		box-shadow: 0 1px 2px rgba(0,0,0,0.08), 0 4px 12px rgba(79,70,229,0.2);
		font-family: inherit;
		white-space: nowrap;
	}
	.ks-btn-primary:hover {
		background: var(--ks-primary-hover);
		transform: translateY(-1px);
		box-shadow: 0 4px 12px rgba(79,70,229,0.3);
	}
	.ks-btn-primary:active { transform: translateY(0); }

	/* ===== ALERTS ===== */
	.ks-alert-banner {
		color: #fff;
		padding: 18px 24px;
		border-radius: 14px;
		margin-bottom: 24px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		gap: 16px;
	}
	.ks-alert-banner-danger {
		background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%);
		box-shadow: 0 4px 20px rgba(239,68,68,0.25);
	}
	.ks-alert-banner-warning {
		background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
		box-shadow: 0 4px 20px rgba(245,158,11,0.25);
	}

	/* ===== DEVICE CARDS ===== */
	.ks-device-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 20px; }

	.ks-device-card {
		background: var(--ks-card-bg);
		border-radius: var(--ks-radius-lg);
		padding: 0;
		border: 1px solid var(--ks-border);
		box-shadow: var(--ks-shadow);
		transition: transform 0.2s, box-shadow 0.2s;
		position: relative;
		overflow: hidden;
		display: flex;
		flex-direction: column;
	}
	.ks-device-card:hover {
		transform: translateY(-3px);
		box-shadow: var(--ks-shadow-lg);
	}
	.ks-card-top-bar {
		height: 5px;
		width: 100%;
	}
	.status-grey .ks-card-top-bar { background: linear-gradient(90deg, #CBD5E1, #94A3B8); }
	.status-yellow .ks-card-top-bar { background: linear-gradient(90deg, #F59E0B, #FBBF24); }
	.status-red .ks-card-top-bar { background: linear-gradient(90deg, #EF4444, #F87171); }

	.ks-card-body { padding: 20px 20px 0; flex-grow: 1; }
	.ks-card-footer { padding: 0 20px 20px; }

	.ks-card-header-row {
		display: flex;
		justify-content: space-between;
		align-items: flex-start;
		margin-bottom: 14px;
	}
	.ks-status-badge {
		display: inline-flex;
		align-items: center;
		gap: 5px;
		font-size: 0.6875rem;
		font-weight: 700;
		text-transform: uppercase;
		letter-spacing: 0.06em;
		padding: 4px 10px;
		border-radius: 20px;
		flex-shrink: 0;
	}
	.ks-status-badge i { width: 10px; height: 10px; }
	.status-red .ks-status-badge { background: var(--ks-danger-light); color: #B91C1C; }
	.status-yellow .ks-status-badge { background: var(--ks-warning-light); color: #92400E; }
	.status-grey .ks-status-badge { background: #F1F5F9; color: var(--ks-text-muted); }

	.ks-card-device-name {
		font-size: 1.0625rem;
		font-weight: 700;
		color: var(--ks-text-main);
		margin: 0 0 5px 0;
		line-height: 1.3;
		flex-grow: 1;
		padding-right: 8px;
	}
	.ks-card-address {
		display: flex;
		align-items: center;
		gap: 5px;
		font-size: 0.8125rem;
		color: var(--ks-text-muted);
	}
	.ks-card-address i { width: 13px; height: 13px; flex-shrink: 0; }

	.ks-card-info {
		background: #F8FAFC;
		padding: 14px 16px;
		border-radius: 12px;
		margin: 14px 0 16px;
		border: 1px solid #EEF2F7;
	}
	.ks-info-row {
		display: flex;
		justify-content: space-between;
		align-items: center;
		font-size: 0.875rem;
		margin-bottom: 8px;
	}
	.ks-info-row:last-child { margin-bottom: 0; }
	.ks-info-label { color: var(--ks-text-muted); font-weight: 500; display: flex; align-items: center; gap: 5px; }
	.ks-info-label i { width: 13px; height: 13px; }
	.ks-info-value { color: var(--ks-text-main); font-weight: 600; }
	.ks-info-value.highlight { color: var(--ks-primary); }
	.ks-countdown-badge {
		display: inline-flex;
		align-items: center;
		gap: 4px;
		font-size: 0.75rem;
		font-weight: 700;
		padding: 3px 8px;
		border-radius: 20px;
	}
	.status-red .ks-countdown-badge { background: var(--ks-danger-light); color: #B91C1C; }
	.status-yellow .ks-countdown-badge { background: var(--ks-warning-light); color: #92400E; }
	.status-grey .ks-countdown-badge { background: var(--ks-primary-light); color: var(--ks-primary); }

	.ks-card-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
	.ks-btn-action {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		gap: 7px;
		padding: 11px 14px;
		border-radius: 10px;
		text-decoration: none !important;
		font-weight: 600;
		font-size: 0.875rem;
		cursor: pointer;
		border: 1.5px solid transparent;
		transition: all 0.15s ease;
		font-family: inherit;
		white-space: nowrap;
	}
	.ks-btn-action i { width: 16px; height: 16px; flex-shrink: 0; }
	.ks-btn-log { background: var(--ks-primary); color: #fff !important; border-color: var(--ks-primary); grid-column: span 2; }
	.ks-btn-log:hover { background: var(--ks-primary-hover); border-color: var(--ks-primary-hover); }
	.ks-btn-cal { background: #334155; color: #fff !important; border-color: #334155; grid-column: span 2; }
	.ks-btn-cal i { color: #fff !important; }
	.ks-btn-cal:hover { background: #1E293B; border-color: #1E293B; }
	.ks-btn-call { background: var(--ks-success); color: #fff !important; border-color: var(--ks-success); grid-column: span 2; }
	.ks-btn-call:hover { background: #059669; }
	.ks-btn-note { background: var(--ks-primary-light); color: #fff !important; border-color: var(--ks-primary); grid-column: span 2; }
	.ks-btn-note:hover { background: var(--ks-primary-hover); color: #fff !important; border-color: var(--ks-primary-hover); }
	.ks-btn-danger-link {
		color: var(--ks-text-muted) !important;
		font-size: 0.8125rem;
		font-weight: 500;
		text-decoration: none !important;
		display: block;
		text-align: center;
		margin-top: 12px;
		padding: 6px;
	}
	.ks-btn-danger-link:hover { color: var(--ks-danger) !important; }

	.ks-note-history {
		margin: 14px 0 0;
		padding: 11px 14px;
		border-radius: 10px;
		background: #F8FAFC;
		border: 1px solid var(--ks-border);
		font-size: 0.8125rem;
		max-height: 80px;
		overflow-y: auto;
		color: var(--ks-text-muted);
		line-height: 1.5;
	}

	/* ===== CALENDAR ===== */
	.ks-calendar-container {
		display: grid;
		grid-template-columns: 1fr 320px;
		gap: 20px;
		align-items: start;
	}
	.ks-calendar-main {
		background: var(--ks-card-bg);
		border-radius: var(--ks-radius-lg);
		padding: 24px;
		box-shadow: var(--ks-shadow);
		border: 1px solid var(--ks-border);
	}
	.ks-calendar-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 20px;
	}
	.ks-calendar-header h3 {
		font-size: 1.25rem;
		font-weight: 800;
		margin: 0;
		letter-spacing: -0.025em;
		text-transform: capitalize;
	}
	.ks-btn-group { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
	.ks-btn-nav {
		display: inline-flex; align-items: center; justify-content: center;
		width: 38px; height: 38px;
		border-radius: 10px;
		border: 1.5px solid var(--ks-border);
		background: #fff;
		color: var(--ks-text-main);
		text-decoration: none !important;
		transition: all 0.15s;
		font-weight: 600;
	}
	.ks-btn-nav:hover { background: #F8FAFC; border-color: #CBD5E1; }
	.ks-btn-nav i { width: 16px; height: 16px; }
	.ks-btn-today {
		padding: 0 14px; height: 38px; width: auto;
		font-size: 0.8125rem; font-weight: 700;
		background: var(--ks-primary-light); color: var(--ks-primary) !important;
		border-color: #C7D2FE;
	}
	.ks-btn-today:hover { background: #E0E7FF; }

	.ks-calendar-legend {
		background: #F8FAFC;
		padding: 10px 16px;
		border-radius: 10px;
		margin-bottom: 16px;
		display: flex;
		gap: 18px;
		font-size: 0.75rem;
		font-weight: 600;
		border: 1px solid var(--ks-border);
		flex-wrap: wrap;
		color: var(--ks-text-muted);
	}
	.ks-legend-dot {
		width: 8px; height: 8px;
		border-radius: 50%;
		display: inline-block;
		margin-right: 5px;
		flex-shrink: 0;
	}
	.ks-calendar-grid {
		display: grid;
		grid-template-columns: repeat(7, 1fr);
		border: 1px solid var(--ks-border);
		border-radius: 12px;
		overflow: hidden;
	}
	.ks-cal-day-name {
		background: #F8FAFC;
		padding: 10px 8px;
		text-align: center;
		font-weight: 700;
		font-size: 0.6875rem;
		color: var(--ks-text-muted);
		border-bottom: 1px solid var(--ks-border);
		text-transform: uppercase;
		letter-spacing: 0.05em;
	}
	.ks-cal-day {
		min-height: 110px;
		padding: 8px 6px;
		background: #fff;
		border-right: 1px solid var(--ks-border);
		border-bottom: 1px solid var(--ks-border);
		transition: background 0.15s;
		vertical-align: top;
	}
	.ks-cal-day:nth-child(7n) { border-right: none; }
	.ks-cal-day.today { background: var(--ks-primary-light); }
	.ks-cal-day.today .ks-cal-day-num {
		background: var(--ks-primary);
		color: #fff;
		width: 26px; height: 26px;
		border-radius: 50%;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		font-size: 0.8125rem;
	}
	.ks-cal-day-num {
		font-weight: 700;
		color: #CBD5E1;
		font-size: 0.8125rem;
		margin-bottom: 6px;
		display: block;
	}
	.ks-cal-day.active-month .ks-cal-day-num { color: var(--ks-text-main); }
	.ks-cal-event {
		font-size: 0.6875rem;
		padding: 3px 7px;
		margin-bottom: 3px;
		border-radius: 5px;
		color: #fff !important;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
		cursor: pointer;
		font-weight: 600;
		display: block;
		transition: opacity 0.15s;
	}
	.ks-cal-event:hover { opacity: 0.85; }
	.ks-cal-event.upcoming { background: var(--ks-success); }
	.ks-cal-event.past { background: #94A3B8; }
	.ks-cal-event.custom { background: #8B5CF6; }

	/* Calendar Sidebar */
	.ks-calendar-sidebar {
		background: var(--ks-card-bg);
		border-radius: var(--ks-radius-lg);
		padding: 24px;
		box-shadow: var(--ks-shadow);
		border: 1px solid var(--ks-border);
	}
	.ks-cal-sidebar-title {
		font-weight: 800;
		font-size: 1rem;
		margin: 0 0 16px 0;
		color: var(--ks-text-main);
		display: flex;
		align-items: center;
		gap: 8px;
	}
	.ks-cal-sidebar-title .today-badge {
		font-size: 0.6875rem;
		background: var(--ks-success-light);
		color: #065F46;
		padding: 2px 8px;
		border-radius: 20px;
		font-weight: 700;
		text-transform: uppercase;
		letter-spacing: 0.05em;
	}
	.ks-today-card {
		padding: 14px 16px;
		border-radius: 12px;
		background: #F8FAFC;
		margin-bottom: 12px;
		border-left: 3px solid var(--ks-success);
		border-top: 1px solid var(--ks-border);
		border-right: 1px solid var(--ks-border);
		border-bottom: 1px solid var(--ks-border);
	}
	.ks-today-card h4 { margin: 0 0 5px 0; font-size: 0.9375rem; font-weight: 700; color: var(--ks-text-main); }
	.ks-today-card p { margin: 3px 0; font-size: 0.8125rem; color: var(--ks-text-muted); display: flex; align-items: center; gap: 4px; }
	.ks-today-card p i { width: 12px; height: 12px; }
	.ks-today-actions { margin-top: 10px; display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
	.ks-btn-mini {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		gap: 4px;
		padding: 9px 8px;
		font-size: 0.75rem;
		border-radius: 8px;
		text-decoration: none !important;
		color: #fff !important;
		font-weight: 600;
		border: none;
		cursor: pointer;
		text-align: center;
		transition: opacity 0.15s;
		font-family: inherit;
		width: 100%;
	}
	.ks-btn-mini:hover { opacity: 0.88; }
	.ks-btn-mini i { width: 13px; height: 13px; color: #fff !important; }

	/* ===== PRICING ===== */
	.ks-pricing-grid {
		display: grid;
		grid-template-columns: repeat(4, 1fr);
		gap: 20px;
		margin: 0 auto;
	}
	.ks-pricing-card {
		background: #fff;
		padding: 32px 24px;
		border-radius: 20px;
		border: 1.5px solid var(--ks-border);
		box-shadow: var(--ks-shadow);
		text-align: center;
		position: relative;
		display: flex;
		flex-direction: column;
		transition: transform 0.2s, box-shadow 0.2s;
	}
	.ks-pricing-card:hover { box-shadow: var(--ks-shadow-lg); transform: translateY(-3px); }
	.ks-pricing-card-featured {
		border: 2px solid var(--ks-primary);
		box-shadow: 0 12px 40px rgba(79,70,229,0.14);
		transform: translateY(-6px);
		z-index: 10;
	}
	.ks-pricing-card-featured:hover { transform: translateY(-9px); }
	.ks-pricing-card--firm {
		background: linear-gradient(145deg, #1e293b, #0f172a);
		border-color: #334155;
		color: #e2e8f0;
	}
	.ks-pricing-card--firm:hover { box-shadow: 0 16px 48px rgba(15,23,42,0.35); }
	.ks-pricing-badge {
		display: inline-block;
		background: #dcfce7;
		color: #166534;
		font-size: 0.7rem;
		font-weight: 700;
		padding: 3px 10px;
		border-radius: 20px;
		text-transform: uppercase;
		letter-spacing: 0.04em;
		margin-bottom: 12px;
	}
	.ks-pricing-badge--firm {
		background: rgba(96,165,250,0.15);
		color: #60a5fa;
	}
	.ks-pricing-footer-note {
		font-size: 0.8125rem;
		color: var(--ks-text-muted);
		text-align: center;
		margin-top: 24px;
		padding-top: 20px;
		border-top: 1px solid var(--ks-border);
	}

	/* ===== TUTORIAL ===== */
	.ks-tutorial-grid {
		display: grid;
		grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
		gap: 20px;
	}
	/* Sugestie cards: 3-column on desktop, horizontal scroll-snap on mobile */
	.ks-sugestie-grid {
		grid-template-columns: 1fr 1fr 1fr;
	}
	.ks-tutorial-card {
		background: #fff;
		padding: 28px;
		border-radius: var(--ks-radius-lg);
		border: 1px solid var(--ks-border);
		box-shadow: var(--ks-shadow);
		transition: box-shadow 0.2s;
	}
	.ks-tutorial-card:hover { box-shadow: var(--ks-shadow-md); }

	/* ===== MODALS ===== */
	.ks-overlay-form {
		display: none;
		position: fixed;
		top: 0; left: 0; width: 100%; height: 100%;
		background: rgba(15,23,42,0.65);
		backdrop-filter: blur(4px);
		z-index: 9999;
		overflow-y: auto;
		padding: 40px 20px;
	}
	.ks-form-card {
		background: #fff;
		max-width: 600px;
		margin: 0 auto;
		border-radius: 20px;
		padding: 36px;
		position: relative;
		box-shadow: 0 25px 50px rgba(0,0,0,0.25);
	}
	.ks-form-card h3 {
		font-size: 1.25rem;
		font-weight: 800;
		margin: 0 0 24px 0;
		color: var(--ks-text-main);
		letter-spacing: -0.02em;
	}
	.ks-close-form {
		position: absolute;
		top: 20px; right: 24px;
		width: 32px; height: 32px;
		border-radius: 8px;
		background: #F1F5F9;
		display: flex; align-items: center; justify-content: center;
		cursor: pointer;
		font-size: 1.2em;
		color: var(--ks-text-muted);
		transition: background 0.15s;
		line-height: 1;
		border: none;
	}
	.ks-close-form:hover { background: #E2E8F0; color: var(--ks-text-main); }
	.ks-form-group { margin-bottom: 16px; }
	.ks-form-group label {
		display: block;
		margin-bottom: 7px;
		font-weight: 600;
		font-size: 0.875rem;
		color: var(--ks-text-main);
	}
	.ks-input {
		width: 100%;
		padding: 11px 14px;
		border: 1.5px solid #D1D5DB;
		border-radius: 10px;
		box-sizing: border-box;
		font-size: 0.9375rem;
		font-family: inherit;
		color: var(--ks-text-main);
		transition: border-color 0.15s, box-shadow 0.15s;
		background: #fff;
	}
	.ks-input:focus {
		outline: none;
		border-color: var(--ks-primary);
		box-shadow: 0 0 0 3px rgba(79,70,229,0.1);
	}

	/* ===== MOBILE BOTTOM NAV ===== */
	.ks-bottom-nav {
		display: none;
		position: fixed;
		bottom: 0; left: 0; right: 0;
		background: var(--ks-sidebar-bg);
		z-index: 200;
		padding: 0 4px;
		padding-bottom: env(safe-area-inset-bottom);
		border-top: 1px solid rgba(255,255,255,0.08);
		box-shadow: 0 -4px 24px rgba(0,0,0,0.2);
	}
	.ks-bottom-nav-inner {
		display: flex;
		align-items: stretch;
		height: 60px;
	}
	.ks-bnav-item {
		flex: 1;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 3px;
		color: #fff !important;
		text-decoration: none !important;
		font-size: 0.75rem;
		font-weight: 600;
		letter-spacing: 0.02em;
		transition: color 0.15s, border-color 0.15s;
		padding: 6px 4px;
		border-radius: 10px;
		border: 1.5px solid transparent;
		margin: 6px 3px;
	}
	.ks-bnav-item i { width: 22px; height: 22px; }
	.ks-bnav-item.active, .ks-bnav-item.open {
		color: #fff !important;
		border-color: rgba(255,255,255,0.55);
	}
	.ks-bnav-item:hover { color: #fff !important; }

	/* ===== RESPONSIVE ===== */
	@media (max-width: 1024px) {
		.ks-calendar-container { grid-template-columns: 1fr; }
		.ks-calendar-sidebar { display: none; } /* shown below on mobile */
	}

	@media (max-width: 768px) {
		.ks-dashboard-wrapper { flex-direction: column; }
		.ks-sidebar { display: none; }
		.ks-bottom-nav { display: block; }

		.ks-content {
			padding: 20px 16px 80px;
		}

		.ks-page-title { font-size: 1.5rem; }

		.ks-header-flex {
			flex-direction: column;
			align-items: stretch;
			gap: 12px;
		}
		.ks-header-flex .ks-btn-primary {
			width: 100%;
			justify-content: center;
			padding: 14px;
			font-size: 1rem;
		}

		.ks-stats-row {
			grid-template-columns: 1fr;
			gap: 8px;
		}
		.ks-stat-card { padding: 14px 16px; gap: 12px; }
		.ks-stat-icon { width: 40px; height: 40px; border-radius: 10px; }
		.ks-stat-icon i { width: 18px; height: 18px; }
		.ks-stat-value { font-size: 1.5rem; }
		.ks-stat-label { font-size: 0.8125rem; }

		.ks-filters-bar {
			flex-direction: column;
			align-items: stretch;
			gap: 10px;
			padding: 14px;
		}

		.ks-device-list { grid-template-columns: 1fr; gap: 14px; }

		.ks-btn-primary, .ks-btn-action, .ks-input { min-height: 48px; }

		.ks-alert-banner {
			flex-direction: column;
			gap: 14px;
			text-align: center;
		}
		.ks-alert-banner a { width: 100%; justify-content: center; }

		.ks-calendar-legend { flex-direction: row; gap: 12px; padding: 8px 12px; flex-wrap: wrap; }
		.ks-cal-day-name { font-size: 0.5625rem; padding: 8px 4px; }
		.ks-cal-day { min-height: 72px; padding: 5px 4px; }
		.ks-cal-event { font-size: 0.5625rem; padding: 2px 4px; }

		.ks-pricing-grid { grid-template-columns: 1fr; gap: 14px; }
		.ks-pricing-card-featured { transform: none; }
		.ks-pricing-card--firm { color: #e2e8f0; }

		.ks-tutorial-grid { grid-template-columns: 1fr; gap: 16px; }
		/* Sugestie: single-card horizontal scroll with snap on mobile */
		.ks-sugestie-grid {
			display: flex;
			flex-direction: row;
			overflow-x: auto;
			scroll-snap-type: x mandatory;
			-webkit-overflow-scrolling: touch;
			gap: 16px;
			padding-bottom: 8px;
		}
		.ks-sugestie-grid .ks-tutorial-card {
			flex: 0 0 85vw;
			max-width: 340px;
			scroll-snap-align: start;
		}

		.ks-overlay-form { padding: 0; backdrop-filter: none; }
		.ks-form-card {
			max-width: none;
			min-height: 100vh;
			border-radius: 0;
			padding: 24px 20px;
		}

		.ks-calendar-sidebar {
			display: block;
			margin-top: 0;
		}

		/* On mobile: hide grid calendar, show agenda view */
		.ks-calendar-grid-wrap { display: none; }
		.ks-cal-agenda { display: block; }

		.ks-card-actions { grid-template-columns: 1fr 1fr; }
		.ks-btn-log { grid-column: span 2; }
		.ks-btn-cal { grid-column: span 1; }
		.ks-btn-call { grid-column: span 1; }
		.ks-btn-note { grid-column: span 2; }

		/* Wizytówka: podgląd button full width below header */
		.ks-viz-header { flex-wrap: wrap; }
		.ks-viz-header .ks-viz-preview-btn { margin-left: 0 !important; width: 100%; justify-content: center; margin-top: 12px; }
	}
</style>

<div class="ks-dashboard-wrapper">
	<aside class="ks-sidebar">
		<div class="ks-sidebar-brand">
			<span>Panel Serwisanta</span>
		</div>
		<nav class="ks-nav-items">
			<span class="ks-nav-section-label">Główne</span>
			<a href="?ks_tab=devices" class="ks-nav-item <?php echo $active_tab === 'devices' ? 'active' : ''; ?>">
				<i data-lucide="layout-dashboard"></i>
				<span>Urządzenia</span>
			</a>
			<a href="?ks_tab=calendar" class="ks-nav-item <?php echo $active_tab === 'calendar' ? 'active' : ''; ?>">
				<i data-lucide="calendar"></i>
				<span>Kalendarz</span>
			</a>
            <?php if ( ! $_is_service_worker ) : ?>
            <a href="?ks_tab=wizytowka" class="ks-nav-item <?php echo $active_tab === 'wizytowka' ? 'active' : ''; ?>">
				<i data-lucide="user"></i>
				<span>Wizytówka</span>
			</a>
            <?php endif; ?>

			<!-- Premium Tools – in Główne section -->
			<div class="ks-nav-group">
				<div class="ks-nav-item ks-nav-parent <?php echo in_array($active_tab, ['seo', 'protokol', 'magazyn', 'ofertomat']) ? 'open' : ''; ?>" onclick="togglePremiumMenu(event)">
					<div style="display:flex; align-items:center; gap:12px;">
						<i data-lucide="briefcase"></i>
						<span>Narzędzia Premium</span>
					</div>
					<?php if ( $_low_stock_count > 0 ) : ?>
						<span class="ks-nav-warning-dot">!</span>
					<?php endif; ?>
					<i data-lucide="chevron-down" class="chevron"></i>
				</div>
				<div id="premiumSubmenu" class="ks-submenu <?php echo in_array($active_tab, ['seo', 'protokol', 'magazyn', 'ofertomat']) ? 'active' : ''; ?>">
					<a href="?ks_tab=magazyn" class="ks-nav-item <?php echo $active_tab === 'magazyn' ? 'active' : ''; ?>">
						<i data-lucide="package"></i>
						<span>Magazyn</span>
						<?php if ( $_low_stock_count > 0 ) : ?>
							<span style="margin-left:auto; background:var(--ks-danger); color:#fff; font-size:0.6875rem; font-weight:700; padding:2px 7px; border-radius:20px; animation:ks-pulse 1.5s infinite;"><?php echo $_low_stock_count; ?></span>
						<?php endif; ?>
					</a>
					<a href="?ks_tab=protokol" class="ks-nav-item <?php echo $active_tab === 'protokol' ? 'active' : ''; ?>">
						<i data-lucide="file-text"></i>
						<span>Protokół serwisowy</span>
					</a>
					<a href="?ks_tab=ofertomat" class="ks-nav-item <?php echo $active_tab === 'ofertomat' ? 'active' : ''; ?>">
						<i data-lucide="file-check"></i>
						<span>Ofertomat</span>
					</a>
					<?php if ( ! $_is_service_worker ) : ?>
					<a href="?ks_tab=seo" class="ks-nav-item <?php echo $active_tab === 'seo' ? 'active' : ''; ?>">
						<i data-lucide="trending-up"></i>
						<span>Pozycjonowanie wizytówki</span>
					</a>
				<?php endif; ?>
				</div>
			</div>

			<span class="ks-nav-section-label" style="margin-top:8px;">Konto</span>
			<a href="?ks_tab=plan" class="ks-nav-item <?php echo $active_tab === 'plan' ? 'active' : ''; ?>">
				<i data-lucide="credit-card"></i>
				<span>Twój Plan</span>
				<?php if ($_plan_warning) : ?>
					<span class="ks-nav-warning-dot">!</span>
				<?php endif; ?>
			</a>
			<a href="?ks_tab=referral" class="ks-nav-item <?php echo $active_tab === 'referral' ? 'active' : ''; ?>">
				<i data-lucide="gift"></i>
				<span>Polecaj, zyskuj</span>
			</a>

			<?php if ($_is_multi) : ?>
			<a href="?ks_tab=multi" class="ks-nav-item <?php echo $active_tab === 'multi' ? 'active' : ''; ?>">
				<i data-lucide="users"></i>
				<span>Zarządzanie Zespołem</span>
			</a>
			<?php endif; ?>

            <a href="?ks_tab=tutorial" class="ks-nav-item <?php echo $active_tab === 'tutorial' ? 'active' : ''; ?>">
				<i data-lucide="help-circle"></i>
				<span>Samouczek</span>
			</a>

            <a href="?ks_tab=sugestie" class="ks-nav-item <?php echo $active_tab === 'sugestie' ? 'active' : ''; ?>">
				<i data-lucide="lightbulb"></i>
				<span>Sugestie</span>
			</a>
		</nav>
		<div class="ks-nav-footer">
			<a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>" class="ks-nav-item ks-nav-item-logout">
				<i data-lucide="log-out"></i>
				<span>Wyloguj</span>
			</a>
		</div>
	</aside>

	<!-- Mobile: Narzędzia drawer -->
	<div class="ks-bnav-drawer" id="ksMobileNarzedziaDrawer">
		<a href="?ks_tab=magazyn" class="ks-bnav-drawer-link <?php echo $active_tab === 'magazyn' ? 'active' : ''; ?>">
			<i data-lucide="package"></i> Magazyn<?php if ( $_low_stock_count > 0 ) : ?> <span style="margin-left:auto; background:var(--ks-danger); color:#fff; font-size:0.6875rem; font-weight:700; padding:2px 7px; border-radius:20px;"><?php echo $_low_stock_count; ?></span><?php endif; ?>
		</a>
		<a href="?ks_tab=protokol" class="ks-bnav-drawer-link <?php echo $active_tab === 'protokol' ? 'active' : ''; ?>">
			<i data-lucide="file-text"></i> Protokół serwisowy
		</a>
		<a href="?ks_tab=ofertomat" class="ks-bnav-drawer-link <?php echo $active_tab === 'ofertomat' ? 'active' : ''; ?>">
			<i data-lucide="file-check"></i> Ofertomat
		</a>
		<?php if ( ! $_is_service_worker ) : ?>
		<a href="?ks_tab=wizytowka" class="ks-bnav-drawer-link <?php echo $active_tab === 'wizytowka' ? 'active' : ''; ?>">
			<i data-lucide="id-card"></i> Wizytówka
		</a>
		<a href="?ks_tab=seo" class="ks-bnav-drawer-link <?php echo $active_tab === 'seo' ? 'active' : ''; ?>">
			<i data-lucide="trending-up"></i> Pozycjonowanie wizytówki
		</a>
		<?php endif; ?>
	</div>

	<!-- Mobile: Konto drawer -->
	<div class="ks-bnav-drawer" id="ksMobileKontoDrawer">
		<a href="?ks_tab=plan" class="ks-bnav-drawer-link <?php echo $active_tab === 'plan' ? 'active' : ''; ?>">
			<i data-lucide="credit-card"></i> Twój Plan
			<?php if ($_plan_warning) : ?><span style="margin-left:auto;width:8px;height:8px;background:#F59E0B;border-radius:50%;flex-shrink:0;"></span><?php endif; ?>
		</a>
		<a href="?ks_tab=referral" class="ks-bnav-drawer-link <?php echo $active_tab === 'referral' ? 'active' : ''; ?>">
			<i data-lucide="gift"></i> Polecaj, zyskuj
		</a>
		<?php if ($_is_multi) : ?>
		<a href="?ks_tab=multi" class="ks-bnav-drawer-link <?php echo $active_tab === 'multi' ? 'active' : ''; ?>">
			<i data-lucide="users"></i> Zarządzanie Zespołem
		</a>
		<?php endif; ?>
		<a href="?ks_tab=tutorial" class="ks-bnav-drawer-link <?php echo $active_tab === 'tutorial' ? 'active' : ''; ?>">
			<i data-lucide="help-circle"></i> Samouczek
		</a>
		<a href="?ks_tab=sugestie" class="ks-bnav-drawer-link <?php echo $active_tab === 'sugestie' ? 'active' : ''; ?>">
			<i data-lucide="lightbulb"></i> Sugestie
		</a>
		<a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>" class="ks-bnav-drawer-link" style="color:rgba(248,113,113,0.9);">
			<i data-lucide="log-out"></i> Wyloguj
		</a>
	</div>

	<!-- Mobile Bottom Navigation -->
	<div class="ks-bottom-nav">
		<div class="ks-bottom-nav-inner">
			<a href="?ks_tab=devices" class="ks-bnav-item <?php echo $active_tab === 'devices' ? 'active' : ''; ?>">
				<i data-lucide="layout-dashboard"></i>
				<span>Urządzenia</span>
			</a>
			<a href="?ks_tab=calendar" class="ks-bnav-item <?php echo $active_tab === 'calendar' ? 'active' : ''; ?>">
				<i data-lucide="calendar"></i>
				<span>Kalendarz</span>
			</a>
			<button class="ks-bnav-item js-mobile-drawer-toggle <?php echo in_array($active_tab, ['seo', 'protokol', 'magazyn', 'wizytowka', 'ofertomat']) ? 'active' : ''; ?>" onclick="toggleMobileDrawer('ksMobileNarzedziaDrawer', this)" aria-label="Otwórz Narzędzia" style="background:none;border:1.5px solid transparent;cursor:pointer;position:relative;">
				<i data-lucide="briefcase"></i>
				<span>Narzędzia</span>
				<?php if ( $_low_stock_count > 0 ) : ?><span aria-label="Niski stan magazynu" style="position:absolute;top:6px;right:4px;width:8px;height:8px;background:var(--ks-danger);border-radius:50%;border:2px solid var(--ks-sidebar-bg);"></span><?php endif; ?>
			</button>
			<button class="ks-bnav-item js-mobile-drawer-toggle <?php echo in_array($active_tab, ['plan','referral','tutorial','sugestie']) ? 'active' : ''; ?>" onclick="toggleMobileDrawer('ksMobileKontoDrawer', this)" aria-label="Otwórz Konto" style="background:none;border:1.5px solid transparent;cursor:pointer;position:relative;">
				<i data-lucide="user-circle"></i>
				<span>Konto</span>
				<?php if ($_plan_warning) : ?><span aria-label="Subskrypcja wygasa wkrótce" style="position:absolute;top:6px;right:4px;width:8px;height:8px;background:#F59E0B;border-radius:50%;border:2px solid var(--ks-sidebar-bg);"></span><?php endif; ?>
			</button>
		</div>
	</div>

	<main class="ks-content">
        <?php
        // Global Notifications
        $error_code = isset($_GET['error']) ? sanitize_text_field($_GET['error']) : '';
        if ( $error_code === 'limit_reached' ) : ?>
            <div class="ks-alert-banner ks-alert-banner-danger">
                <span style="font-weight:800;">🚫 Osiągnięto limit urządzeń! Twój aktualny plan nie pozwala na dodanie kolejnych wpisów.</span>
                <a href="?ks_tab=plan" class="ks-btn-primary" style="background:#fff; color: var(--ks-danger) !important; padding:10px 20px; font-size:0.875rem;">Zwiększ limit</a>
            </div>
        <?php elseif ( $error_code === 'sms_limit_reached' ) : ?>
            <div class="ks-alert-banner ks-alert-banner-danger">
                <span style="font-weight:800;">🚫 Osiągnięto limit powiadomień SMS! W planie darmowym możesz wysłać maksymalnie <?php echo ks_get_free_sms_limit(); ?> SMS-ów. Przejdź na Premium, aby wysyłać bez limitu.</span>
                <a href="?ks_tab=plan" class="ks-btn-primary" style="background:#fff; color: var(--ks-danger) !important; padding:10px 20px; font-size:0.875rem;">Kup Premium</a>
            </div>
        <?php endif; ?>

        <?php if ($_plan_warning && $active_tab !== 'plan') : ?>
            <div class="ks-alert-banner ks-alert-banner-warning">
                <span style="font-weight:800; display:flex; align-items:center; gap:10px;"><i data-lucide="alert-triangle" style="width:20px;height:20px;"></i> Subskrypcja Premium wygaśnie za <?php echo $_days_left; ?> dni! Przedłuż, aby nie stracić dostępu.</span>
                <a href="?ks_tab=plan" class="ks-btn-primary" style="background:rgba(255,255,255,0.2); border:1.5px solid rgba(255,255,255,0.4); padding:10px 20px; font-size:0.875rem; white-space:nowrap;">Przedłuż teraz</a>
            </div>
        <?php endif; ?>

        <?php if (!$_is_premium && $active_tab !== 'plan') : ?>
            <div class="ks-alert-banner" style="background:linear-gradient(135deg,var(--ks-primary) 0%,#4338CA 100%); box-shadow:0 4px 20px rgba(79,70,229,0.25);">
                <span style="font-weight:800; display:flex; align-items:center; gap:10px;"><i data-lucide="zap" style="width:20px;height:20px;"></i> Kup plan premium i korzystaj z wszystkich funkcji bez limitu.</span>
                <a href="<?php echo esc_url( home_url( '/panel-serwisanta/?ks_tab=plan' ) ); ?>" class="ks-btn-primary" style="background:rgba(255,255,255,0.2); border:1.5px solid rgba(255,255,255,0.4); padding:10px 20px; font-size:0.875rem; white-space:nowrap;">Kup</a>
            </div>
        <?php endif; ?>

        <?php
        $comp_phone = get_user_meta($current_user_id, 'ks_company_phone', true);
        if ( $device_count > 0 && empty($comp_phone) && $active_tab !== 'wizytowka' ) : ?>
            <div class="ks-alert-banner ks-alert-banner-warning">
                <span style="font-weight:800;">ℹ️ Uzupełnij swoją firmową wizytówkę, przez którą będą kontaktować się Twoi klienci. Dzięki tej wizytówce zwiększasz również szansę pozyskiwania nowych klientów z wyszukiwarki Google</span>
                <a href="?ks_tab=wizytowka" class="ks-btn-primary" style="background:rgba(255,255,255,0.2); border:1.5px solid rgba(255,255,255,0.4); padding:10px 20px; font-size:0.875rem;">Dokończ profil</a>
            </div>
        <?php endif; ?>


		<?php if ( $active_tab === 'devices' ) : ?>
            <div class="ks-header-flex" style="margin-bottom:24px;">
                <div>
                    <h2 class="ks-page-title">Twoje Urządzenia</h2>
                    <p class="ks-page-subtitle">Łącznie: <?php echo $device_count; ?> urządzeń w bazie</p>
                </div>
                <button class="ks-btn-primary" onclick="document.getElementById('addDeviceModal').style.display='block'">
					<i data-lucide="plus"></i>
					DODAJ URZĄDZENIE
				</button>
            </div>

            <!-- Stats Row -->
            <?php if ( $device_count > 0 ) : ?>
            <div class="ks-stats-row">
                <div class="ks-stat-card">
                    <div class="ks-stat-icon" style="background: var(--ks-danger-light);">
                        <i data-lucide="alert-circle" style="color: var(--ks-danger);"></i>
                    </div>
                    <div>
                        <div class="ks-stat-value" style="color: var(--ks-danger);"><?php echo $stat_red; ?></div>
                        <div class="ks-stat-label">Termin minął</div>
                    </div>
                </div>
                <div class="ks-stat-card">
                    <div class="ks-stat-icon" style="background: var(--ks-warning-light);">
                        <i data-lucide="clock" style="color: var(--ks-warning);"></i>
                    </div>
                    <div>
                        <div class="ks-stat-value" style="color: var(--ks-warning);"><?php echo $stat_yellow; ?></div>
                        <div class="ks-stat-label">Zbliżające się</div>
                    </div>
                </div>
                <div class="ks-stat-card">
                    <div class="ks-stat-icon" style="background: var(--ks-success-light);">
                        <i data-lucide="check-circle" style="color: var(--ks-success);"></i>
                    </div>
                    <div>
                        <div class="ks-stat-value" style="color: var(--ks-success);"><?php echo $stat_grey; ?></div>
                        <div class="ks-stat-label">Aktualne</div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Filters -->
            <form class="ks-filters-bar" method="get">
                <input type="hidden" name="ks_tab" value="devices">
                <div style="flex-grow:1; min-width:220px;">
					<input type="text" name="ks_search" value="<?php echo esc_attr($search); ?>" placeholder="Szukaj po numerze telefonu..." class="ks-filter-input">
				</div>
                <div style="display:flex; align-items:center; gap:6px;">
                    <span style="font-size:0.8125rem; color:var(--ks-text-muted); white-space:nowrap;">Od:</span>
                    <input type="date" name="ks_from" value="<?php echo esc_attr($from_filter); ?>" class="ks-filter-input" style="padding:10px 14px;">
                </div>
                <div style="display:flex; align-items:center; gap:6px;">
                    <span style="font-size:0.8125rem; color:var(--ks-text-muted); white-space:nowrap;">Do:</span>
                    <input type="date" name="ks_to" value="<?php echo esc_attr($to_filter); ?>" class="ks-filter-input" style="padding:10px 14px;">
                </div>
                <select name="ks_orderby" class="ks-filter-select">
                    <option value="next_service" <?php selected($orderby, 'next_service'); ?>>Najbliższy serwis</option>
                    <option value="next_service_desc" <?php selected($orderby, 'next_service_desc'); ?>>Najdalszy serwis</option>
                    <option value="status_overdue" <?php selected($orderby, 'status_overdue'); ?>>Termin minął</option>
                    <option value="status_upcoming" <?php selected($orderby, 'status_upcoming'); ?>>Zbliżający się</option>
                    <option value="status_upcoming_sms_sent" <?php selected($orderby, 'status_upcoming_sms_sent'); ?>>Wysłano przypomnienie SMS</option>
                    <option value="status_ok" <?php selected($orderby, 'status_ok'); ?>>Aktualne</option>
                </select>
                <button type="submit" class="ks-btn-primary" style="padding:10px 20px;">
                    <i data-lucide="search"></i> Szukaj
                </button>
                <a href="?" class="ks-btn-action" style="background:#F1F5F9; color:var(--ks-text-muted) !important; padding:10px 16px; border-radius:10px; font-weight:600; border:1.5px solid var(--ks-border);">
                    <i data-lucide="x"></i> Reset
                </a>
            </form>

            <div class="ks-device-list">
                <?php foreach ( $devices_paged as $device ) :
                    $id = $device->ID;
                    $tel = get_post_meta($id, 'ks_klient_tel', true);
                    $adres = get_post_meta($id, 'ks_adres_urzadzenia', true);
                    $interval = get_post_meta($id, 'ks_interwal', true);
                    $days_before = (int) get_post_meta($id, 'ks_dni_wyprzedzenia', true);
                    $notes = get_post_meta($id, 'ks_notatki', true);
                    $app_date = get_post_meta($id, 'ks_app_date', true);
                    $app_time = get_post_meta($id, 'ks_app_time', true);
                    $parts_history_raw = ($_is_premium) ? get_post_meta($id, 'ks_parts_history', true) : '';
                    $parts_history = array();
                    if ( $parts_history_raw ) {
                        $ph_decoded = json_decode( $parts_history_raw, true );
                        if ( JSON_ERROR_NONE === json_last_error() && is_array( $ph_decoded ) ) {
                            $parts_history = $ph_decoded;
                        }
                    }
                    $status_class = 'status-grey';
                    $status_text = 'Aktualny';
					$sms_status = get_post_meta($id, 'ks_status_sms', true);

                    // Calculate countdown using calendar days (date-only diff) to avoid
                    // mid-day fluctuations caused by comparing a midnight timestamp to time().
                    $countdown_text = '';
                    if ( $device->next_service_ts > 0 ) {
                        $days_diff = (int)round( ( strtotime( $device->next_service_date ) - strtotime( $today ) ) / 86400 );
                        if ( $days_diff < 0 ) {
                            $countdown_text = 'Minęło ' . abs($days_diff) . ' dni';
                        } elseif ( $days_diff == 0 ) {
                            $countdown_text = 'Dziś!';
                        } else {
                            $countdown_text = 'Za ' . $days_diff . ' dni';
                        }
                    }

                    if ( $device->ks_status === 'overdue' ) {
                        $status_class = 'status-red';
                        $status_text = 'Termin minął!';
                    } elseif ( $device->ks_status === 'upcoming' ) {
                        $status_class = 'status-yellow';
                        $status_text = ( $sms_status === 'Wysłano' ) ? 'Wysłano przypomnienie SMS' : 'Zbliżający się';
                    }
                ?>
                    <div class="ks-device-card <?php echo $status_class; ?>">
						<div class="ks-card-top-bar"></div>
                        <div class="ks-card-body">
                            <div class="ks-card-header-row">
                                <div style="flex-grow:1;">
                                    <h3 class="ks-card-device-name"><?php echo esc_html(get_the_title($id)); ?></h3>
                                    <?php if($adres): ?><div class="ks-card-address"><i data-lucide="map-pin"></i> <?php echo esc_html($adres); ?></div><?php endif; ?>
                                    <?php if ( $_is_service_manager && (int) $device->post_author !== $current_user_id ) :
                                        $worker_label = $_worker_display_names[ (int) $device->post_author ] ?? '—';
                                    ?>
                                    <div style="margin-top:5px; display:inline-flex; align-items:center; gap:5px; background:#EEF2FF; color:#4338CA; border-radius:20px; padding:2px 10px; font-size:12px; font-weight:700;">
                                        <i data-lucide="user" style="width:12px; height:12px;"></i>
                                        <?php echo esc_html( $worker_label ); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <span class="ks-status-badge">
                                    <?php if($status_class === 'status-red'): ?><i data-lucide="alert-circle"></i><?php elseif($status_class === 'status-yellow'): ?><i data-lucide="clock"></i><?php else: ?><i data-lucide="check"></i><?php endif; ?>
                                    <?php echo $status_text; ?>
                                </span>
                            </div>

                            <div class="ks-card-info">
                                <div class="ks-info-row">
                                    <span class="ks-info-label"><i data-lucide="phone"></i> Telefon</span>
                                    <span class="ks-info-value"><?php echo esc_html($tel); ?></span>
                                </div>
                                <div class="ks-info-row">
                                    <span class="ks-info-label"><i data-lucide="calendar"></i> Następny serwis</span>
                                    <span class="ks-info-value highlight"><?php echo esc_html($device->next_service_date ?: '—'); ?></span>
                                </div>
                                <?php if ( $countdown_text ) : ?>
                                <div class="ks-info-row">
                                    <span class="ks-info-label"><i data-lucide="timer"></i> Pozostało</span>
                                    <span class="ks-countdown-badge"><?php echo esc_html($countdown_text); ?></span>
                                </div>
                                <?php endif; ?>
                            </div>

                            <?php if(!empty($notes)): ?>
                                <div class="ks-note-history">
                                    <?php echo nl2br(esc_html($notes)); ?>
                                </div>
                            <?php endif; ?>

                            <?php if( ! empty( $parts_history ) ) : ?>
                                <div class="ks-note-history" style="margin-top:6px; font-size:0.8125rem; color:var(--ks-text-muted);">
                                    <?php foreach ( array_reverse( $parts_history ) as $_ph_entry ) :
                                        if ( empty( $_ph_entry['parts'] ) || ! is_array( $_ph_entry['parts'] ) ) continue;
                                        $ph_date = esc_html( $_ph_entry['date'] ?? '' );
                                        foreach ( $_ph_entry['parts'] as $_ph_part ) :
                                    ?>
                                    <div style="display:flex; align-items:center; gap:6px; padding:2px 0;">
                                        <i data-lucide="package" style="width:12px; height:12px; flex-shrink:0;"></i>
                                        <span><strong>Użyte części:</strong> <?php echo $ph_date; ?> – <?php echo esc_html( $_ph_part['name'] ); ?><?php echo ( (int)$_ph_part['qty'] > 1 ) ? ' (szt. ' . (int)$_ph_part['qty'] . ')' : ''; ?></span>
                                    </div>
                                    <?php endforeach; endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="ks-card-footer">
                            <div class="ks-card-actions" style="margin-top:16px;">
                                <button class="ks-btn-action ks-btn-log" onclick="openLogModal(<?php echo htmlspecialchars(json_encode([
                                    'id' => $id, 'title' => get_the_title($id), 'adres' => $adres, 'tel' => $tel, 'interval' => $interval, 'days' => $days_before, 'notes' => $notes
                                ])); ?>)">
                                    <i data-lucide="refresh-cw"></i> ZAKTUALIZUJ SERWIS
                                </button>
                                <button class="ks-btn-action ks-btn-cal" onclick="openCalModal(<?php echo $id; ?>, <?php echo $app_date ? "'" . esc_js($app_date) . "'" : 'null'; ?>, <?php echo $app_time ? "'" . esc_js($app_time) . "'" : 'null'; ?>)">
                                    <i data-lucide="calendar-plus"></i> DODAJ WIZYTĘ
                                </button>
                                <a href="tel:<?php echo esc_attr($tel); ?>" class="ks-btn-action ks-btn-call">
                                    <i data-lucide="phone"></i> ZADZWOŃ
                                </a>
                                <button class="ks-btn-action ks-btn-note" onclick="openNoteModal(<?php echo $id; ?>)">
                                    <i data-lucide="notebook-pen"></i> DODAJ NOTATKĘ
                                </button>
                            </div>
                            <a href="javascript:void(0)" class="ks-btn-danger-link" onclick="deleteDevice(<?php echo $id; ?>)">usuń urządzenie</a>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if ( $_ks_total_pages > 1 ) :
                    // Preserve all active filters when navigating pages
                    $_ks_base_args = array_filter( [
                        'ks_tab'     => 'devices',
                        'ks_search'  => $search,
                        'ks_from'    => $from_filter,
                        'ks_to'      => $to_filter,
                        'ks_orderby' => $orderby !== 'next_service' ? $orderby : null,
                    ] );
                    ?>
                    <div style="grid-column:1/-1; display:flex; align-items:center; justify-content:center; gap:8px; padding:24px 0 8px;">
                        <?php if ( $_ks_page > 1 ) : ?>
                            <a href="<?php echo esc_url( add_query_arg( array_merge( $_ks_base_args, [ 'paged' => $_ks_page - 1 ] ), home_url( '/panel-serwisanta/' ) ) ); ?>" class="ks-btn-action" style="padding:8px 16px;">« Poprzednia</a>
                        <?php endif; ?>
                        <span style="font-size:0.875rem; color:var(--ks-text-muted); padding:0 8px;">Strona <?php echo $_ks_page; ?> z <?php echo $_ks_total_pages; ?></span>
                        <?php if ( $_ks_page < $_ks_total_pages ) : ?>
                            <a href="<?php echo esc_url( add_query_arg( array_merge( $_ks_base_args, [ 'paged' => $_ks_page + 1 ] ), home_url( '/panel-serwisanta/' ) ) ); ?>" class="ks-btn-action" style="padding:8px 16px;">Następna »</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if ( $device_count === 0 ) : ?>
                    <div style="grid-column: 1/-1; text-align:center; padding: 60px 20px; background:#fff; border-radius:20px; border:1px solid var(--ks-border);">
                        <div style="width:64px; height:64px; background:var(--ks-primary-light); border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; color:var(--ks-primary);">
                            <i data-lucide="package" style="width:28px; height:28px;"></i>
                        </div>
                        <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:8px;">Brak urządzeń</h3>
                        <p style="color:var(--ks-text-muted); font-size:0.9375rem; margin-bottom:24px;">Dodaj pierwsze urządzenie, aby zacząć zarządzać serwisem.<br><b>Mając konto serwisanta Premium, będziesz mógł przypisać użyte części serwisowe z magazynu podczas dodawania urządzenia.</b><br>Aby uzupełnić magazyn, przejdź do sekcji NARZĘDZIA a następnie- MAGAZYN.</p>
                        <button class="ks-btn-primary" onclick="document.getElementById('addDeviceModal').style.display='block'">
                            <i data-lucide="plus"></i> Dodaj pierwsze urządzenie
                        </button>
                    </div>
                <?php endif; ?>
            </div>

		<?php elseif ( $active_tab === 'calendar' ) : ?>
                <!-- ============================================================
                     CALENDAR (FullCalendar)
                     ============================================================ -->
                <div class="ks-header-flex" style="margin-bottom:24px;">
                    <h2 class="ks-page-title">Kalendarz</h2>
                    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                        <div id="ks-cal-filters" role="search" aria-label="Filtry kalendarza">
                            <select data-filter="status" aria-label="Filtruj wg statusu">
                                <option value="">Wszystkie statusy</option>
                                <option value="scheduled">Zaplanowane</option>
                                <option value="completed">Zakończone</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Bulk reschedule bar (shown when events are selected) -->
                <div id="ks-cal-bulk-bar" aria-label="Masowe przenoszenie wizyt" role="toolbar">
                    <span class="ks-bulk-count">0 zaznaczone</span>
                    <button id="ks-bulk-prev-day" type="button" aria-label="Przesuń o 1 dzień wcześniej">&#8592; Dzień wcześniej</button>
                    <button id="ks-bulk-next-day" type="button" aria-label="Przesuń o 1 dzień później">Dzień później &#8594;</button>
                    <button id="ks-bulk-clear" type="button" aria-label="Wyczyść zaznaczenie">&#215; Wyczyść</button>
                </div>

                <!-- Calendar container (FullCalendar mounts here) -->
                <div id="ks-new-calendar-root" style="position:relative;">
                    <div id="ks-cal-spinner" role="status" aria-label="Ładowanie kalendarza..."></div>
                    <div id="ks-new-calendar" role="application" aria-label="Kalendarz wizyt"></div>
                </div>

                <!-- Color legend -->
                <div class="ks-cal-legend" aria-label="Legenda statusów">
                    <span><span class="ks-legend-dot" style="background:#4F46E5;"></span>Zaplanowana</span>
                    <span><span class="ks-legend-dot" style="background:#10B981;"></span>Zakończona</span>
                    <span><span class="ks-legend-dot" style="background:#8B5CF6;"></span>Inne wpisy</span>
                </div>

                <!-- Event detail modal (desktop) -->
                <div id="ks-cal-modal" role="dialog" aria-modal="true" aria-label="Szczegóły wizyty" aria-hidden="true">
                    <div class="ks-cal-modal-inner">
                        <button class="ks-close-btn" type="button" aria-label="Zamknij">&times;</button>
                        <div class="ks-cal-modal-body"></div>
                    </div>
                </div>

                <!-- Bottom-sheet overlay (mobile) -->
                <div id="ks-cal-sheet-overlay" aria-hidden="true"></div>

                <!-- Bottom-sheet (mobile event detail) -->
                <div id="ks-cal-sheet" role="dialog" aria-modal="true" aria-label="Szczegóły wizyty" aria-hidden="true">
                    <button class="ks-sheet-close" type="button" aria-label="Zamknij">&times;</button>
                    <div class="ks-cal-sheet-body"></div>
                </div>

                <!-- Quick-create modal -->
                <div id="ks-cal-quick-modal" role="dialog" aria-modal="true" aria-label="Dodaj wizytę" aria-hidden="true">
                    <div class="ks-cal-modal-inner">
                        <button class="ks-close-btn" type="button" aria-label="Zamknij">&times;</button>
                        <h3 style="margin-bottom:16px;font-size:1.125rem;font-weight:700;">Dodaj wizytę</h3>
                        <form id="ks-cal-quick-form" novalidate>
                            <input type="hidden" id="ks-qc-device-id" value="">
                            <div id="ks-qc-title-wrap" class="ks-form-group">
                                <label for="ks-qc-title">Tytuł *</label>
                                <input id="ks-qc-title" type="text" class="ks-input" placeholder="np. Przegląd pralki Samsung" autocomplete="off">
                            </div>
                            <?php if ( $_is_service_manager && ! empty( $_worker_display_names ) ) : ?>
                            <div id="ks-qc-worker-wrap" class="ks-form-group">
                                <label for="ks-qc-worker">Pracownik</label>
                                <select id="ks-qc-worker" class="ks-input">
                                    <option value="">— Ja (Manager) —</option>
                                    <?php foreach ( $_worker_display_names as $_wid => $_wname ) : ?>
                                    <option value="<?php echo esc_attr( $_wid ); ?>"><?php echo esc_html( $_wname ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                                <div class="ks-form-group">
                                    <label for="ks-qc-start">Początek *</label>
                                    <input id="ks-qc-start" type="datetime-local" class="ks-input" required>
                                </div>
                                <div class="ks-form-group">
                                    <label for="ks-qc-end">Koniec</label>
                                    <input id="ks-qc-end" type="datetime-local" class="ks-input">
                                </div>
                            </div>
                            <div class="ks-form-group">
                                <label for="ks-qc-address">Adres</label>
                                <input id="ks-qc-address" type="text" class="ks-input" placeholder="np. ul. Morska 1, Gdynia" autocomplete="street-address">
                            </div>
                            <div class="ks-form-group">
                                <label for="ks-qc-notes">Notatki</label>
                                <textarea id="ks-qc-notes" class="ks-input" rows="3" style="resize:vertical;"></textarea>
                            </div>
                            <button type="submit" class="ks-qc-submit">ZAPISZ WIZYTĘ</button>
                        </form>
                    </div>
                </div>

                <!-- Conflict resolution modal -->
                <div id="ks-cal-conflict-modal" role="dialog" aria-modal="true" aria-label="Konflikt terminów" aria-hidden="true">
                    <div class="ks-cal-modal-inner">
                        <button class="ks-close-btn" type="button" aria-label="Zamknij">&times;</button>
                        <h3 style="margin-bottom:8px;font-size:1.125rem;font-weight:700;color:#991B1B;">&#9888; Konflikt terminów</h3>
                        <div class="ks-conflict-body"></div>
                        <div class="ks-conflict-actions">
                            <button id="ks-conflict-cancel" type="button">Anuluj przeniesienie</button>
                            <button id="ks-conflict-force" type="button">Wymuś i zapisz</button>
                        </div>
                    </div>
                </div>

                <!-- FAB: Floating Action Button (add visit) -->
                <button id="ks-cal-fab" type="button" aria-label="Dodaj nową wizytę" title="Dodaj nową wizytę">+</button>

        <?php elseif ( $active_tab === 'wizytowka' ) :
			$comp_logo = get_user_meta($current_user_id, 'ks_company_logo', true);
			$comp_name = get_user_meta($current_user_id, 'ks_company_name', true) ?: get_the_author_meta('display_name', $current_user_id);
			$comp_phone = get_user_meta($current_user_id, 'ks_company_phone', true);
			$comp_desc = get_user_meta($current_user_id, 'ks_company_desc', true);
			$comp_city = get_user_meta($current_user_id, 'ks_company_city', true);
            $comp_url = get_user_meta($current_user_id, 'ks_company_url', true);
			$updated_at = (int) get_user_meta($current_user_id, 'ks_profile_updated_at', true);
			$is_ready = !empty($updated_at) && $updated_at > 0; // Card is always ready after first save (cache purged on save)
            $just_updated = isset($_GET['profile_updated']);
			?>
			<h2 class="ks-page-title" style="margin-bottom:8px;">Twoja Cyfrowa Wizytówka</h2>
			<p class="ks-page-subtitle" style="margin-bottom:28px;">Te dane będą widoczne dla Twoich klientów po kliknięciu w link z SMS-a.</p>

            <?php if($just_updated): ?>
                <div style="background:var(--ks-success); color:#fff; padding:14px 20px; border-radius:12px; margin-bottom:24px; font-weight:600; display:flex; align-items:center; gap:10px; box-shadow:0 4px 12px rgba(16,185,129,0.2);">
                    <i data-lucide="check-circle" style="width:20px; height:20px; flex-shrink:0;"></i>
                    Zmiany zostały zapisane! Twoja wizytówka jest aktualnie widoczna dla klientów.
                </div>
            <?php endif; ?>

            <?php if(isset($_GET['logo_deleted'])): ?>
                <div style="background:var(--ks-success); color:#fff; padding:14px 20px; border-radius:12px; margin-bottom:24px; font-weight:600; display:flex; align-items:center; gap:10px; box-shadow:0 4px 12px rgba(16,185,129,0.2);">
                    <i data-lucide="check-circle" style="width:20px; height:20px; flex-shrink:0;"></i>
                    Logo zostało usunięte.
                </div>
            <?php endif; ?>

            <?php $logo_error = isset($_GET['logo_error']) ? sanitize_text_field($_GET['logo_error']) : ''; ?>
            <?php if ( $logo_error === 'format' ) : ?>
                <div style="background:var(--ks-danger); color:#fff; padding:14px 20px; border-radius:12px; margin-bottom:24px; font-weight:600; display:flex; align-items:center; gap:10px; box-shadow:0 4px 12px rgba(239,68,68,0.2);">
                    <i data-lucide="x-circle" style="width:20px; height:20px; flex-shrink:0;"></i>
                    Niedozwolony format pliku. Logo musi być w formacie JPG, JPEG, PNG, GIF lub WebP.
                </div>
            <?php elseif ( $logo_error === 'size' ) : ?>
                <div style="background:var(--ks-danger); color:#fff; padding:14px 20px; border-radius:12px; margin-bottom:24px; font-weight:600; display:flex; align-items:center; gap:10px; box-shadow:0 4px 12px rgba(239,68,68,0.2);">
                    <i data-lucide="x-circle" style="width:20px; height:20px; flex-shrink:0;"></i>
                    Plik jest za duży. Maksymalny rozmiar logo to 5 MB.
                </div>
            <?php endif; ?>

			<div style="background:#fff; padding:36px; border-radius:20px; max-width:640px; box-shadow:var(--ks-shadow); border:1px solid var(--ks-border);">
                <div class="ks-viz-header" style="display:flex; align-items:center; gap:12px; margin-bottom:28px; padding-bottom:24px; border-bottom:1px solid var(--ks-border); flex-wrap:wrap;">
                    <?php if($comp_logo): ?>
                        <div style="position:relative; display:inline-block; flex-shrink:0;">
                            <?php echo wp_get_attachment_image($comp_logo, [64, 64], false, ["style" => "border-radius:12px; width:64px; height:64px; object-fit:cover; display:block;"]); ?>
                            <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" style="position:absolute; top:-8px; right:-8px; margin:0;">
                                <input type="hidden" name="action" value="ks_delete_logo">
                                <?php wp_nonce_field('ks_delete_logo', 'ks_delete_logo_nonce'); ?>
                                <button type="submit" title="Usuń logo" aria-label="Usuń logo firmy" onclick="return confirm('Czy usunąć logo firmy?')" style="width:22px; height:22px; border-radius:50%; background:var(--ks-danger); border:2px solid #fff; color:#fff; cursor:pointer; display:flex; align-items:center; justify-content:center; padding:0; font-size:12px; line-height:1; box-shadow:0 2px 6px rgba(0,0,0,0.2);">✕</button>
                            </form>
                        </div>
                    <?php else: ?>
                        <div style="width:64px; height:64px; background:var(--ks-primary-light); border-radius:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                            <i data-lucide="building-2" style="width:28px; height:28px; color:var(--ks-primary);"></i>
                        </div>
                    <?php endif; ?>
                    <div style="min-width:0; flex-grow:1;">
                        <div style="font-weight:800; font-size:1.125rem; color:var(--ks-text-main);"><?php echo esc_html($comp_name ?: 'Twoja Firma'); ?></div>
                        <div style="font-size:0.875rem; color:var(--ks-text-muted);"><?php echo esc_html($comp_city ?: 'Uzupełnij miasto'); ?></div>
                        <?php if($is_ready): ?>
                            <a href="<?php echo esc_url(get_author_posts_url($current_user_id)); ?>" target="_blank" class="ks-btn-primary ks-viz-preview-btn" style="margin-top:10px; padding:8px 16px; font-size:0.875rem; display:inline-flex;">
                                <i data-lucide="external-link"></i> Podgląd wizytówki
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

				<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" enctype="multipart/form-data" id="ks-wizytowka-form">
					<input type="hidden" name="action" value="ks_save_card">
					<?php wp_nonce_field( 'ks_save_card', 'ks_card_nonce' ); ?>
					<div class="ks-form-group">
                        <label>Logo Firmy</label>
                        <input type="file" name="company_logo" id="ks-logo-input" accept=".jpg,.jpeg,.png,.gif,.webp" style="font-size:0.875rem; color:var(--ks-text-muted);">
                        <div id="ks-logo-error" style="display:none; color:var(--ks-danger); font-size:0.8rem; margin-top:6px; font-weight:600;"></div>
                    </div>
					<div class="ks-form-group"><label>Nazwa Firmy *</label><input type="text" name="company_name" value="<?php echo esc_attr($comp_name); ?>" required class="ks-input"></div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                        <div class="ks-form-group"><label>Miasto działalności</label><input type="text" name="company_city" value="<?php echo esc_attr($comp_city); ?>" class="ks-input"></div>
                        <div class="ks-form-group"><label>Telefon *</label><input type="tel" name="company_phone" value="<?php echo esc_attr($comp_phone); ?>" required class="ks-input"></div>
                    </div>
                    <div class="ks-form-group"><label>Strona internetowa</label><input type="text" name="company_url" value="<?php echo esc_attr($comp_url); ?>" placeholder="np. www.twojastrona.pl" class="ks-input"></div>
					<div class="ks-form-group"><label>Opis firmy / usług</label><textarea name="company_desc" class="ks-input" rows="4" style="resize:vertical;"><?php echo esc_textarea($comp_desc); ?></textarea></div>
					<button type="submit" class="ks-btn-primary" style="width:100%; justify-content:center; padding:13px; font-size:1rem;">
                        <i data-lucide="save"></i> ZAPISZ WIZYTÓWKĘ
                    </button>
					</form>
			</div>
            <script>
            (function() {
                var ALLOWED_EXTS = ['jpg','jpeg','png','gif','webp'];
                var MAX_BYTES    = 5 * 1024 * 1024;
                var input = document.getElementById('ks-logo-input');
                var errEl = document.getElementById('ks-logo-error');
                var form  = document.getElementById('ks-wizytowka-form');
                if (!input || !errEl || !form) return;

                function getExt(name) {
                    return name.split('.').pop().toLowerCase().replace(/[^a-z0-9]/g,'');
                }

                function validate() {
                    if (!input.files || !input.files.length) {
                        errEl.style.display = 'none';
                        return true;
                    }
                    var file = input.files[0];
                    var ext  = getExt(file.name);
                    if (ALLOWED_EXTS.indexOf(ext) === -1) {
                        errEl.textContent = 'Niedozwolony format pliku. Dozwolone formaty: JPG, JPEG, PNG, GIF, WebP.';
                        errEl.style.display = 'block';
                        input.value = '';
                        return false;
                    }
                    if (file.size > MAX_BYTES) {
                        errEl.textContent = 'Plik jest za duży. Maksymalny rozmiar logo to 5 MB.';
                        errEl.style.display = 'block';
                        input.value = '';
                        return false;
                    }
                    errEl.style.display = 'none';
                    return true;
                }

                input.addEventListener('change', validate);
                form.addEventListener('submit', function(e) {
                    if (!validate()) { e.preventDefault(); }
                });
            })();
            </script>
		<?php elseif ( $active_tab === 'seo' ) :
			include plugin_dir_path(__FILE__) . 'premium-seo.php';
		elseif ( $active_tab === 'protokol' ) :
			include plugin_dir_path(__FILE__) . 'premium-protokol.php';
		elseif ( $active_tab === 'magazyn' ) :
			include plugin_dir_path(__FILE__) . 'premium-magazyn.php';
		elseif ( $active_tab === 'ofertomat' ) :
			include plugin_dir_path(__FILE__) . 'premium-ofertomat.php';
		elseif ( $active_tab === 'plan' ) :
			// Reuse global plan variables
			$plan       = $_plan_data;
			$is_premium = $_is_premium;
			$is_multi   = $_is_multi;
			$days_left  = $_days_left;

			// Device usage calculation – use a COUNT query (no data transfer)
			$_count_query = new WP_Query( array(
				'post_type'              => 'ks_urzadzenie',
				'author'                 => $current_user_id,
				'post_status'            => 'publish',
				'posts_per_page'         => 1,
				'fields'                 => 'ids',
				'no_found_rows'          => false,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'meta_query'             => array(
					array(
						'key'     => 'ks_is_custom_app',
						'compare' => 'NOT EXISTS',
					),
				),
			) );
			$current_usage = $_count_query->found_posts;
			$usage_percent = $is_premium ? 0 : min(100, ($current_usage / max(1, $plan['limit'])) * 100);
			$_free_sms_limit = ks_get_free_sms_limit();
			$_sms_sent       = ks_get_user_sms_sent_count( $current_user_id );
			$_sms_percent    = $is_premium ? 0 : min(100, ($_sms_sent / max(1, $_free_sms_limit)) * 100);
			?>
			<h2 class="ks-page-title" style="margin-bottom:24px;">Twój Plan i Płatności</h2>

			<!-- Status Header -->
			<div style="background:#fff; padding:28px 32px; border-radius:20px; box-shadow:var(--ks-shadow); border:1px solid var(--ks-border); margin-bottom:28px;">
				<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:16px;">
					<div>
						<span style="font-size:0.75rem; font-weight:700; color:var(--ks-text-muted); text-transform:uppercase; letter-spacing:0.06em;">Aktualny Plan</span>
						<h3 style="font-size:1.625rem; font-weight:800; margin:4px 0 0 0; color:<?php echo $is_premium ? ($is_multi ? '#3b82f6' : ($plan['status'] === 'premium14' ? '#8B5CF6' : 'var(--ks-primary)')) : 'var(--ks-text-main)'; ?>; letter-spacing:-0.02em;">
							<?php echo $is_multi ? '🏢 MULTI' : ($plan['status'] === 'premium14' ? '🎁 PREMIUM – OKRES PRÓBNY (14 DNI)' : ($is_premium ? '✦ PREMIUM' : 'DARMOWY (FREE)')); ?>
						</h3>
					</div>
					<div style="text-align:right;">
						<span style="font-size:0.75rem; font-weight:700; color:var(--ks-text-muted); text-transform:uppercase; letter-spacing:0.06em;">Użycie Limitów</span>
						<div style="font-size:1.375rem; font-weight:800; margin-top:4px;"><?php echo $current_usage; ?> / <?php echo $is_premium ? '∞' : $plan['limit']; ?> <span style="font-size:0.875rem; font-weight:500; color:var(--ks-text-muted);">urządzeń</span></div>
					</div>
				</div>

				<?php if(!$is_premium): ?>
					<div style="width:100%; height:10px; background:#F1F5F9; border-radius:10px; overflow:hidden; margin-bottom:10px;">
						<div style="width:<?php echo $usage_percent; ?>%; height:100%; background:linear-gradient(90deg, var(--ks-primary), #818CF8); border-radius:10px; transition:width 0.5s ease-out;"></div>
					</div>
					<p style="font-size:0.8125rem; color:var(--ks-text-muted); margin:0 0 20px;">W planie darmowym możesz dodać maksymalnie <?php echo $plan['limit']; ?> urządzeń. Przejdź na Premium, aby zdjąć limity.</p>

					<!-- SMS usage for free plan -->
					<div style="border-top:1px solid var(--ks-border); padding-top:16px;">
						<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
							<span style="font-size:0.8125rem; font-weight:600; color:var(--ks-text-main); display:flex; align-items:center; gap:6px;">
								<i data-lucide="message-square" style="width:15px; height:15px; color:var(--ks-primary);"></i>
								Powiadomienia SMS
							</span>
							<span style="font-size:0.8125rem; font-weight:700; color:<?php echo $_sms_sent >= $_free_sms_limit ? 'var(--ks-danger)' : 'var(--ks-text-main)'; ?>;"><?php echo $_sms_sent; ?> / <?php echo $_free_sms_limit; ?></span>
						</div>
						<div style="width:100%; height:8px; background:#F1F5F9; border-radius:8px; overflow:hidden; margin-bottom:8px;">
							<div style="width:<?php echo $_sms_percent; ?>%; height:100%; background:<?php echo $_sms_sent >= $_free_sms_limit ? 'var(--ks-danger)' : 'linear-gradient(90deg, var(--ks-primary), #818CF8)'; ?>; border-radius:8px; transition:width 0.5s ease-out;"></div>
						</div>
						<p style="font-size:0.8125rem; color:var(--ks-text-muted); margin:0;">
							<?php if ( $_sms_sent >= $_free_sms_limit ) : ?>
								Osiągnąłeś limit SMS w planie darmowym. <a href="?ks_tab=plan" style="color:var(--ks-primary); font-weight:700;">Kup Premium</a>, aby wysyłać bez ograniczeń.
							<?php else : ?>
								Pozostało <?php echo max(0, $_free_sms_limit - $_sms_sent); ?> z <?php echo $_free_sms_limit; ?> darmowych powiadomień SMS. Przejdź na Premium, aby wysyłać bez limitu.
							<?php endif; ?>
						</p>
					</div>
				<?php else: ?>
					<div style="display:inline-flex; align-items:center; gap:8px; color:<?php echo $plan['status'] === 'premium14' ? '#5B21B6' : '#065F46'; ?>; font-weight:600; font-size:0.875rem; background:<?php echo $plan['status'] === 'premium14' ? '#EDE9FE' : 'var(--ks-success-light)'; ?>; padding:8px 16px; border-radius:10px;">
						<i data-lucide="check-circle" style="width:16px; height:16px;"></i>
						<?php if ( $plan['status'] === 'premium14' ) : ?>
							Okres próbny (14 dni) aktywny do: <?php echo date('d.m.Y', $plan['expiry']); ?> – kup plan, aby kontynuować!
						<?php else : ?>
							Subskrypcja Premium aktywna do: <?php echo date('d.m.Y', $plan['expiry']); ?>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>

			<?php
			if ($_plan_warning) : ?>
				<div class="ks-alert-banner ks-alert-banner-warning" style="margin-bottom:28px;">
					<span style="display:flex; align-items:center; gap:10px; font-weight:700;"><i data-lucide="alert-triangle"></i> Twoja subskrypcja Premium wygaśnie za <?php echo $days_left; ?> dni. Przedłuż ją teraz!</span>
				</div>
			<?php endif;

			// Referral bonus summary in plan tab
			$_plan_ref_bonus = (int) get_user_meta( $current_user_id, 'ks_referral_bonus_days', true );
			if ( $_plan_ref_bonus > 0 ) : ?>
				<div style="background:#fff; padding:20px 28px; border-radius:16px; box-shadow:var(--ks-shadow); border:1px solid var(--ks-border); margin-bottom:24px; display:flex; align-items:center; gap:16px; flex-wrap:wrap;">
					<i data-lucide="gift" style="width:28px; height:28px; color:#F59E0B; flex-shrink:0;"></i>
					<div>
						<div style="font-weight:700; font-size:0.9375rem;">Bonus za polecenia</div>
						<div style="font-size:0.875rem; color:var(--ks-text-muted); margin-top:2px;">Do Twojego konta zostało dopisanych łącznie <strong style="color:#F59E0B;">+<?php echo $_plan_ref_bonus; ?> dni</strong> premium za skuteczne polecenia.</div>
					</div>
					<a href="?ks_tab=referral" class="ks-btn-primary" style="margin-left:auto; white-space:nowrap; padding:10px 18px; font-size:0.875rem;">Polecaj dalej</a>
				</div>
			<?php endif; ?>

			<!-- Pricing Cards -->
			<div class="ks-pricing-grid">
				<?php
				$_ks_dashboard_plans = ks_get_pricing_plans();
				$_ks_dash_card_classes = array( '', '', 'ks-pricing-card-featured', 'ks-pricing-card--firm' );
				foreach ( $_ks_dashboard_plans as $_ks_di => $_ks_dp ) :
					$_ks_dp_badge    = trim( $_ks_dp['badge'] );
					$_ks_dp_features = array_filter( array_map( 'trim', explode( "\n", $_ks_dp['features'] ) ) );
					$_ks_dp_card_cls = $_ks_dash_card_classes[ $_ks_di ];
					// Buduj link – do panelu serwisanta dodaj parametr śledzący z ID użytkownika
					$_ks_dp_base_url = $_ks_dp['btn_url_panel'];
					$_ks_dp_url      = $_ks_dp_base_url
						? add_query_arg( 'attr1', $current_user_id, $_ks_dp_base_url )
						: '#zamow';
				?>
				<div class="ks-pricing-card <?php echo esc_attr( $_ks_dp_card_cls ); ?>">
					<?php if ( $_ks_dp_badge ) : ?>
					<span class="ks-pricing-badge<?php echo $_ks_di === 3 ? ' ks-pricing-badge--firm' : ''; ?>">
						<?php echo esc_html( $_ks_dp_badge ); ?>
					</span>
					<?php endif; ?>
					<p style="font-size:0.75rem; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; color:<?php echo $_ks_di === 3 ? '#64748b' : 'var(--ks-text-muted)'; ?>; margin:0 0 4px;">
						<?php echo esc_html( $_ks_dp['period'] ); ?>
					</p>
					<h4 style="font-size:1.2rem; font-weight:800; margin:0 0 20px; letter-spacing:-0.02em;<?php echo $_ks_di === 3 ? ' color:#f1f5f9;' : ''; ?>">
						<?php echo esc_html( $_ks_dp['name'] ); ?>
					</h4>
					<div style="display:flex; align-items:flex-start; justify-content:center; gap:2px; margin-bottom:4px;">
						<span style="font-size:1rem; font-weight:700; color:<?php echo $_ks_di === 3 ? '#60a5fa' : 'var(--ks-primary)'; ?>; margin-top:10px;">zł</span>
						<span style="font-size:3rem; font-weight:900; color:<?php echo $_ks_di === 3 ? '#60a5fa' : 'var(--ks-primary)'; ?>; line-height:1; letter-spacing:-0.04em;">
							<?php echo esc_html( $_ks_dp['price'] ); ?>
						</span>
						<span style="font-size:1rem; font-weight:600; color:<?php echo $_ks_di === 3 ? '#94a3b8' : 'var(--ks-text-muted)'; ?>; margin-top:10px;">
							<?php echo esc_html( $_ks_dp['price_unit'] ); ?>
						</span>
					</div>
					<p style="font-size:0.8125rem; color:<?php echo $_ks_di === 3 ? '#94a3b8' : 'var(--ks-text-muted)'; ?>; margin:0 0 24px;">
						<?php echo esc_html( $_ks_dp['sub'] ); ?>
					</p>
					<ul style="list-style:none; padding:0; margin:0 0 28px; text-align:left; font-size:0.875rem; color:<?php echo $_ks_di === 3 ? '#94a3b8' : 'var(--ks-text-muted)'; ?>; flex-grow:1;">
						<?php foreach ( $_ks_dp_features as $_ks_dp_feat ) : ?>
						<li style="margin-bottom:10px; display:flex; align-items:center; gap:8px;">
							<i data-lucide="check" style="color:<?php echo $_ks_di === 3 ? '#34d399' : 'var(--ks-success)'; ?>; width:15px; flex-shrink:0;"></i>
							<?php echo esc_html( $_ks_dp_feat ); ?>
						</li>
						<?php endforeach; ?>
					</ul>
					<a href="<?php echo esc_url( $_ks_dp_url ); ?>"
					   target="_blank"
					   class="ks-btn-primary"
					   style="width:100%; justify-content:center; padding:13px; border-radius:12px;<?php echo $_ks_di === 3 ? ' background:#3b82f6; border-color:#3b82f6;' : ''; ?>">
						<?php echo esc_html( $_ks_dp['btn_text'] ); ?>
					</a>
				</div>
				<?php endforeach; ?>
			</div><!-- /.ks-pricing-grid -->

			<p class="ks-pricing-footer-note"><strong>Wystawiamy faktury (zwolnienie z VAT).</strong> Podstawa prawna: zwolnienie podmiotowe.</p>

		<?php elseif ( $active_tab === 'referral' ) :
			$_ref_code        = ks_get_or_create_referral_code( $current_user_id );
			$_ref_bonus_days  = (int) get_user_meta( $current_user_id, 'ks_referral_bonus_days', true );
			$_ref_all_count   = count( get_users( array(
				'meta_key'   => 'ks_referred_by',
				'meta_value' => $current_user_id,
				'fields'     => 'ids',
			) ) );
			$_ref_rewarded    = count( get_users( array(
				'fields'     => 'ids',
				'meta_query' => array(
					'relation' => 'AND',
					array( 'key' => 'ks_referred_by',       'value' => $current_user_id ),
					array( 'key' => 'ks_referral_rewarded', 'value' => '1' ),
				),
			) ) );
			$_ref_msg = 'Cześć, polecam Ci www.kiedyserwis.pl – kompleksowy system, który automatyzuje pracę i buduje Twój wizerunek. Podczas rejestracji podaj kod: ' . $_ref_code . ' a otrzymasz 14 dni konta premium na testy.';
			?>
			<h2 class="ks-page-title" style="margin-bottom:6px;">Polecaj, zyskuj</h2>
			<p class="ks-page-subtitle" style="margin-bottom:28px;">Poleć KiedySerwis znajomym serwisantom i zyskaj dodatkowe 30 dni konta premium za każdą osobę, która dzięki Twojemu kodowi kupi plan Premium lub Multi.</p>

			<!-- Code card -->
			<div style="background:#fff; padding:28px 32px; border-radius:20px; box-shadow:var(--ks-shadow); border:1px solid var(--ks-border); margin-bottom:24px;">
				<div style="font-size:0.75rem; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; color:var(--ks-text-muted); margin-bottom:8px;">Twój indywidualny kod polecający</div>
				<div style="display:flex; align-items:center; gap:16px; flex-wrap:wrap;">
					<div id="ks-ref-code-display" style="font-size:2rem; font-weight:900; letter-spacing:0.25em; color:var(--ks-primary); background:var(--ks-primary-light); padding:16px 28px; border-radius:14px; font-family:monospace;">
						<?php echo esc_html( $_ref_code ); ?>
					</div>
					<button data-msg="<?php echo esc_attr( $_ref_msg ); ?>" onclick="ksRefCopyCode(this.dataset.msg)" class="ks-btn-primary" style="padding:12px 20px; gap:8px;">
						<i data-lucide="copy" style="width:16px; height:16px;"></i>
						<span id="ks-ref-copy-label">Kopiuj wiadomość</span>
					</button>
				</div>
				<!-- Preview of what gets copied -->
				<div style="margin-top:16px; padding:14px 18px; background:#F8FAFC; border-radius:10px; border:1px solid #E2E8F0; font-size:0.875rem; color:var(--ks-text-muted); line-height:1.7; font-style:italic;">
					&ldquo;<?php echo esc_html( $_ref_msg ); ?>&rdquo;
				</div>
				<p style="margin:14px 0 0; font-size:0.875rem; color:var(--ks-text-muted); line-height:1.6;">
					Osoba która zarejestruje się używając Twojego kodu otrzyma automatycznie <strong>14 dni konta Premium</strong> z odblokowanymi wszystkimi funkcjami. Gdy następnie kupi pełny plan <strong>Premium</strong> lub <strong>Multi</strong>, Twoje konto zostanie przedłużone o <strong>30 dni</strong> – nawet jeśli masz konto darmowe!
				</p>
			</div>

			<!-- Stats row -->
			<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:16px; margin-bottom:24px;">
				<div style="background:#fff; padding:24px; border-radius:16px; box-shadow:var(--ks-shadow); border:1px solid var(--ks-border); text-align:center;">
					<div style="font-size:2rem; font-weight:900; color:var(--ks-primary); line-height:1;"><?php echo $_ref_all_count; ?></div>
					<div style="font-size:0.8125rem; color:var(--ks-text-muted); margin-top:6px;">Zaproszonych serwisantów</div>
				</div>
				<div style="background:#fff; padding:24px; border-radius:16px; box-shadow:var(--ks-shadow); border:1px solid var(--ks-border); text-align:center;">
					<div style="font-size:2rem; font-weight:900; color:var(--ks-success); line-height:1;"><?php echo $_ref_rewarded; ?></div>
					<div style="font-size:0.8125rem; color:var(--ks-text-muted); margin-top:6px;">Kupiło plan Premium/Multi</div>
				</div>
				<div style="background:#fff; padding:24px; border-radius:16px; box-shadow:var(--ks-shadow); border:1px solid var(--ks-border); text-align:center;">
					<div style="font-size:2rem; font-weight:900; color:#F59E0B; line-height:1;">+<?php echo $_ref_bonus_days; ?></div>
					<div style="font-size:0.8125rem; color:var(--ks-text-muted); margin-top:6px;">Dni premii łącznie</div>
				</div>
			</div>

			<!-- How it works -->
			<div style="background:#fff; padding:28px 32px; border-radius:20px; box-shadow:var(--ks-shadow); border:1px solid var(--ks-border);">
				<h4 style="margin:0 0 20px; font-size:1rem; font-weight:800;">Jak to działa?</h4>
				<ol style="padding-left:20px; margin:0; font-size:0.875rem; color:var(--ks-text-muted); line-height:1.8;">
					<li>Kliknij <strong>Kopiuj wiadomość</strong> – do schowka trafi gotowy tekst z Twoim kodem.</li>
					<li>Prześlij wiadomość znajomemu serwisantowi, który jeszcze nie ma konta w KiedySerwis.</li>
					<li>Kolega wpisuje Twój kod w polu <em>Kod polecającego</em> podczas rejestracji i <strong>automatycznie otrzymuje 14 dni konta Premium</strong> ze wszystkimi funkcjami do przetestowania.</li>
					<li>Gdy wykupi pełny plan <strong>Premium</strong> lub <strong>Multi</strong>, Twoje konto zostanie automatycznie przedłużone o <strong>30 dni</strong> – nawet jeśli teraz masz konto darmowe!</li>
					<li>Nie ma limitu – nagroda przysługuje za każde skuteczne polecenie.</li>
				</ol>
			</div>

			<script>
			function ksRefCopyCode(msg) {
				navigator.clipboard.writeText(msg).then(function() {
					var lbl = document.getElementById('ks-ref-copy-label');
					lbl.textContent = 'Skopiowano!';
					setTimeout(function() { lbl.textContent = 'Kopiuj wiadomość'; }, 2000);
				}).catch(function() {
					// Fallback for older browsers
					var el = document.createElement('textarea');
					el.value = msg;
					document.body.appendChild(el);
					el.select();
					document.execCommand('copy');
					document.body.removeChild(el);
					var lbl = document.getElementById('ks-ref-copy-label');
					lbl.textContent = 'Skopiowano!';
					setTimeout(function() { lbl.textContent = 'Kopiuj wiadomość'; }, 2000);
				});
			}
			</script>

		<?php elseif ( $active_tab === 'multi' ) :
			if ( $_is_multi ) :
				// Render the manager dashboard inline (reuses KS_Multi_Account shortcode logic)
				$ks_multi = new KS_Multi_Account();
				echo $ks_multi->render_manager_dashboard();
			else : ?>
				<div class="ks-form-card" style="max-width:480px; text-align:center;">
					<i data-lucide="lock" style="width:40px; height:40px; color:var(--ks-text-muted); margin-bottom:16px;"></i>
					<h3 style="margin:0 0 8px;">Plan Multi wymagany</h3>
					<p style="color:var(--ks-text-muted); margin:0 0 20px; font-size:0.875rem;">Ta sekcja jest dostępna wyłącznie dla kont z planem Multi.</p>
					<a href="?ks_tab=plan" class="ks-btn-primary" style="width:100%; justify-content:center;">Zobacz plany</a>
				</div>
			<?php endif;

        elseif ( $active_tab === 'tutorial' ) : ?>
            <h2 class="ks-page-title" style="margin-bottom:6px;">Samouczek</h2>
            <p class="ks-page-subtitle" style="margin-bottom:28px;">Dowiedz się jak w pełni wykorzystać potencjał panelu serwisanta zgodnie z zalecanym schematem działania</p>

            <div class="ks-tutorial-grid">
                <!-- Step 1 – Magazyn (Premium) -->
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:rgba(16,185,129,0.1); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="package" style="color:#10B981;"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Magazyn Części <span style="font-size:0.75rem; background:var(--ks-primary-light); color:var(--ks-primary); padding:2px 8px; border-radius:20px; font-weight:700; vertical-align:middle;">Premium</span></h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Prowadź cyfrowy magazyn części serwisowych. Ustaw poziom minimum dla każdej części – gdy stan osiągnie lub spadnie poniżej minimum,
                        otrzymasz powiadomienie w panelu i e-mail <strong>„Osiągnięto minimum"</strong>. <strong>Zalecamy dodanie części serwisowych w pierwszej kolejności.</strong>
                        Podczas dodawania lub aktualizowania serwisu urządzenia będziesz mógł wybrać użyte części – ta czynność zdejmuje ze stanu część oraz finalnie
                        przypisana część do urządzenia jest widoczna w protokole serwisowym.
                    </p>
                </div>

                <!-- Step 2 – Dodawanie Urządzeń -->
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:var(--ks-primary-light); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="plus" style="color:var(--ks-primary);"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Dodawanie Urządzeń</h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Dodając urządzenie swojego klienta przechodzisz przez proces zapisywania informacji w bazie na temat urządzenia i klienta.
                        To pozwoli Ci w łatwy sposób znaleźć informacje o urządzeniu w przyszłości, a system będzie odliczał czas do kolejnego serwisu.
                    </p>
                </div>

                <!-- Step 3 – Protokół (Premium) -->
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:rgba(239,68,68,0.1); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="file-text" style="color:#EF4444;"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Protokół Serwisowy <span style="font-size:0.75rem; background:var(--ks-primary-light); color:var(--ks-primary); padding:2px 8px; border-radius:20px; font-weight:700; vertical-align:middle;">Premium</span></h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Generuj profesjonalne protokoły serwisowe z podpisem klienta i wysyłaj je e-mailem bezpośrednio z panelu.
                        Skonfiguruj wzorzec z listą wykonanych czynności, stopką i logo firmy. Urządzenie wyszukujesz po <strong>numerze telefonu</strong> klienta.
                        Protokół zawiera także użyte części z magazynu.
                    </p>
                </div>

                <!-- Step 4 – Automatyczne Powiadomienia -->
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:var(--ks-success-light); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="message-square" style="color:var(--ks-success);"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Automatyczne Powiadomienia</h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        System automatycznie wysyła powiadomienia SMS do Twoich klientów przed nadchodzącym terminem serwisu.
                        Możesz zdecydować, z jakim wyprzedzeniem klient ma otrzymać wiadomość.
                        W treści SMS-a znajdzie się link do Twojej cyfrowej wizytówki.
                    </p>
                </div>

                <!-- Step 5 – Cyfrowa Wizytówka -->
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:rgba(245,158,11,0.1); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="user" style="color:#F59E0B;"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Cyfrowa Wizytówka</h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Uzupełnij swoją wizytówkę – logo firmy, dane kontaktowe, zakres usług i opis. Klienci trafiają na nią przez link w SMS-ie.
                        Dobra wizytówka buduje zaufanie i wyróżnia Cię na tle konkurencji w wynikach wyszukiwania. Dla kont premium wprowadziliśmy funkcję
                        „Pozycjonowanie wizytówki" – uzupełnienie formularza znacznie zwiększa szansę na pozyskiwanie nowych klientów z wyszukiwarki Google.
                    </p>
                </div>

                <!-- Step 6 – Wygodny Kalendarz -->
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:rgba(139,92,246,0.1); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="calendar" style="color:#8B5CF6;"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Wygodny Kalendarz</h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Kontroluj swoje wizyty dzięki przejrzystemu kalendarzowi. Możesz planować spotkania przypisane do konkretnych urządzeń
                        lub dodawać własne wpisy. W sekcji „Dzisiejsze Wizyty" masz szybki dostęp do numeru telefonu klienta oraz nawigacji do adresu urządzenia.
                    </p>
                </div>

                <!-- Step 7 – Ofertomat (Premium) -->
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:rgba(6,182,212,0.1); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="file-check" style="color:#06B6D4;"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Ofertomat <span style="font-size:0.75rem; background:var(--ks-primary-light); color:var(--ks-primary); padding:2px 8px; border-radius:20px; font-weight:700; vertical-align:middle;">Premium</span></h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Przygotuj i wyślij profesjonalną ofertę do klienta w kilka minut. Wypełnij formularz z pozycjami usług i części,
                        a system automatycznie wyliczy wartości netto, VAT i brutto. Gotowa oferta trafia na e-mail klienta – możesz otrzymać kopię
                        na swój adres. Wygodny formularz działa sprawnie zarówno na komputerze, jak i na telefonie.
                    </p>
                </div>

                <!-- Step 8 – Pozycjonowanie wizytówki (Premium) -->
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:rgba(79,70,229,0.1); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="trending-up" style="color:var(--ks-primary);"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Pozycjonowanie Wizytówki <span style="font-size:0.75rem; background:var(--ks-primary-light); color:var(--ks-primary); padding:2px 8px; border-radius:20px; font-weight:700; vertical-align:middle;">Premium</span></h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Zwiększ widoczność swojej firmy w wyszukiwarce Google. Uzupełnij listę obsługiwanych miast, wykaz usług i serwisowanych marek –
                        każda z tych informacji pomaga Google dopasować Twój profil do zapytań lokalnych klientów. System automatycznie generuje
                        zaawansowany kod Schema.org, który wzmacnia wiarygodność firmy w oczach wyszukiwarek.
                    </p>
                </div>

                <!-- Step 9 – Program Poleceń (wkrótce) -->
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:rgba(251,191,36,0.15); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="gift" style="color:#F59E0B;"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Program Poleceń <span style="font-size:0.75rem; background:#FEF3C7; color:#92400E; padding:2px 8px; border-radius:20px; font-weight:700; vertical-align:middle;">Wkrótce</span></h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Już wkrótce będziesz mógł polecać KiedySerwis.pl innym serwisantom i czerpać z tego korzyści. Planujemy unikalny kod
                        polecający dla każdego użytkownika – gdy poleconej przez Ciebie serwisant wykupi pakiet Premium, Ty otrzymasz nagrodę.
                        Szczegóły programu ogłosimy niebawem – śledź aktualności w panelu!
                    </p>
                </div>
            </div>
		<?php elseif ( $active_tab === 'sugestie' ) :
            // Suggestion form success / error feedback
            $sug_status = isset($_GET['sug_status']) ? sanitize_text_field($_GET['sug_status']) : '';
        ?>
            <h2 class="ks-page-title" style="margin-bottom:6px;">Sugestie</h2>
            <p class="ks-page-subtitle" style="margin-bottom:28px;">Twój głos kształtuje przyszłość KiedySerwis.pl</p>

            <?php if ( $sug_status === 'sent' ) : ?>
                <div class="ks-alert-banner" style="background:var(--ks-success-light); color:var(--ks-success); border-color:var(--ks-success); margin-bottom:24px;">
                    <i data-lucide="check-circle" style="width:18px; height:18px;"></i>
                    Dziękujemy za Twoją sugestię! Przeanalizujemy ją i wrócimy z odpowiedzią.
                </div>
            <?php elseif ( $sug_status === 'error' ) : ?>
                <div class="ks-alert-banner ks-alert-banner-danger" style="margin-bottom:24px;">
                    <i data-lucide="alert-circle" style="width:18px; height:18px;"></i>
                    Wystąpił błąd przy wysyłaniu. Spróbuj ponownie lub napisz bezpośrednio na biuro@kiedyserwis.pl.
                </div>
            <?php endif; ?>

            <div class="ks-tutorial-grid ks-sugestie-grid" style="margin-bottom:40px;">
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:var(--ks-primary-light); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="clock" style="color:var(--ks-primary);"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Odzyskaj swój czas</h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Naszym celem jest odciążyć Cię z papierkowej roboty i przypomnień, abyś mógł skupić się na tym, co potrafisz najlepiej — montażu i serwisie urządzeń.
                    </p>
                </div>
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:var(--ks-success-light); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="trending-up" style="color:var(--ks-success);"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Rozwijamy się razem</h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        W ramach abonamentu stale dodajemy nowe funkcje. To Ty — serwisant — najlepiej wiesz, czego potrzebujesz. Twoje sugestie bezpośrednio wpływają na nasz plan rozwoju.
                    </p>
                </div>
                <div class="ks-tutorial-card">
                    <div style="width:48px; height:48px; background:rgba(139,92,246,0.1); border-radius:12px; display:flex; align-items:center; justify-content:center; margin-bottom:20px;">
                        <i data-lucide="lightbulb" style="color:#8B5CF6;"></i>
                    </div>
                    <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:10px; letter-spacing:-0.02em;">Twój pomysł, nasza praca</h3>
                    <p style="font-size:0.875rem; line-height:1.6; color:var(--ks-text-muted);">
                        Opisz dowolny pomysł, który usprawniłby Twoją codzienną pracę. Każda sugestia jest czytana przez nasz zespół i poważnie rozważana.
                    </p>
                </div>
            </div>

            <div style="max-width:640px;">
                <h3 style="font-size:1.25rem; font-weight:700; margin-bottom:20px; letter-spacing:-0.02em;">Prześlij swoją sugestię</h3>
                <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" class="ks-form-group" style="display:flex; flex-direction:column; gap:16px;">
                    <input type="hidden" name="action" value="ks_send_suggestion">
                    <?php wp_nonce_field( 'ks_send_suggestion', 'ks_suggestion_nonce' ); ?>
                    <!-- Honeypot anti-spam field — must stay empty -->
                    <input type="text" name="ks_hp_field" value="" style="display:none;" tabindex="-1" autocomplete="off">

                    <div class="ks-form-group">
                        <label for="sug_subject">Temat sugestii *</label>
                        <input type="text" id="sug_subject" name="sug_subject" required maxlength="150" placeholder="np. Eksport listy urządzeń do PDF" class="ks-input">
                    </div>
                    <div class="ks-form-group">
                        <label for="sug_message">Opis *</label>
                        <textarea id="sug_message" name="sug_message" required rows="6" maxlength="3000" placeholder="Opisz swój pomysł — co chciałbyś zmienić lub dodać i dlaczego ułatwiłoby Ci to pracę?" class="ks-input" style="resize:vertical;"></textarea>
                    </div>
                    <button type="submit" class="ks-btn-primary" style="width:100%; justify-content:center; padding:13px; font-size:1rem;">
                        <i data-lucide="send"></i> WYŚLIJ SUGESTIĘ
                    </button>
                </form>
            </div>
		<?php endif; ?>
	</main>
</div>

<!-- Modals -->
<div id="addDeviceModal" class="ks-overlay-form">
	<div class="ks-form-card">
		<button class="ks-close-form" onclick="this.parentElement.parentElement.style.display='none'">&times;</button>
		<?php if ( ks_can_add_device($current_user_id) ) : ?>
            <h3>Dodaj Nowe Urządzenie</h3>
            <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
                <input type="hidden" name="action" value="ks_add_device">
                <?php wp_nonce_field( 'ks_create_device', 'ks_device_nonce' ); ?>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                    <?php if ( $_is_premium && empty( $_magazyn_parts ) ) : ?>
                    <div style="grid-column:span 2;" class="ks-form-group" id="ks-add-no-parts-banner">
                        <div style="background:#EFF6FF; border:1px solid #BFDBFE; border-radius:12px; padding:14px 16px; font-size:0.875rem; color:#1E40AF; display:flex; align-items:flex-start; gap:10px;">
                            <i data-lucide="info" style="width:16px; height:16px; flex-shrink:0; margin-top:2px; color:#3B82F6;"></i>
                            <span>Możesz przypisać użyte części podczas tego serwisu. Będą widoczne w protokole. Dodaj części serwisowe, które masz na stanie <a href="<?php echo esc_url( home_url( '/panel-serwisanta/?ks_tab=magazyn' ) ); ?>" style="font-weight:700; color:#1D4ED8; text-decoration:underline;">KLIKNIJ TUTAJ</a> lub <button type="button" onclick="ksHideNoPartsBanner('ks-add-no-parts-banner')" style="background:none; border:none; cursor:pointer; font-size:inherit; color:#1E40AF; text-decoration:underline; padding:0;">nie pokazuj ponownie</button></span>
                        </div>
                    </div>
                    <script>if (localStorage.getItem('ks_hide_no_parts_banner')) { document.getElementById('ks-add-no-parts-banner').style.display = 'none'; }</script>
                    <?php endif; ?>
                    <div style="grid-column:span 2;" class="ks-form-group"><label>Nazwa / Model</label><input type="text" name="device_name" class="ks-input"></div>
                    <div style="grid-column:span 2;" class="ks-form-group"><label>Adres urządzenia</label><input type="text" name="device_address" class="ks-input"></div>
                    <div class="ks-form-group"><label>Telefon Klienta *</label><input type="tel" name="klient_tel" required class="ks-input"></div>
                    <div class="ks-form-group"><label>Interwał (miesiące) *</label><input type="number" name="interwal" value="12" required class="ks-input"></div>
                    <div class="ks-form-group"><label>Powiadomienie SMS</label><select name="dni_wyprzedzenia" class="ks-input"><option value="7">7 dni</option><option value="14">14 dni</option><option value="30" selected>30 dni</option><option value="40">40 dni</option><option value="60">60 dni</option><option value="-1">Nie wysyłaj</option></select></div>
                    <div class="ks-form-group"><label>Data ostatniego serwisu</label><input type="date" name="data_serwisu" value="<?php echo esc_attr( $today ); ?>" class="ks-input"></div>
                    <div style="grid-column:span 2;" class="ks-form-group"><label>Notatka</label><textarea name="ks_notatki" class="ks-input" rows="3"></textarea></div>
                    <?php if ( $_is_premium && ! empty( $_magazyn_parts ) ) : ?>
                    <div style="grid-column:span 2;" class="ks-form-group">
                        <label style="margin-bottom:10px; display:block;">Użyte części z magazynu <span style="font-weight:400; color:var(--ks-text-muted);">(opcjonalnie)</span></label>
                        <?php foreach ( $_magazyn_parts as $_part ) :
                            $_stock = (int) get_post_meta( $_part->ID, 'ks_stan', true );
                        ?>
                        <div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">
                            <label style="display:flex; align-items:center; gap:6px; flex:1; font-weight:400; cursor:pointer;" for="add_part_<?php echo $_part->ID; ?>">
                                <input type="checkbox" id="add_part_<?php echo $_part->ID; ?>" name="log_parts[<?php echo $_part->ID; ?>]" value="1" <?php echo $_stock <= 0 ? 'disabled' : ''; ?> aria-label="<?php echo esc_attr( $_part->post_title ); ?>" style="width:16px; height:16px; accent-color:var(--ks-primary);">
                                <?php echo esc_html( $_part->post_title ); ?>
                                <span style="font-size:0.75rem; color:<?php echo $_stock <= 0 ? 'var(--ks-danger)' : 'var(--ks-text-muted)'; ?>;">(stan: <?php echo $_stock; ?>)</span>
                            </label>
                            <input type="number" name="log_parts_qty[<?php echo $_part->ID; ?>]" value="1" min="1" max="<?php echo max( 1, $_stock ); ?>" <?php echo $_stock <= 0 ? 'disabled' : ''; ?> style="width:60px; padding:6px 8px; border:1px solid var(--ks-border); border-radius:8px; font-size:0.875rem;" aria-label="Ilość: <?php echo esc_attr( $_part->post_title ); ?>">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <div style="grid-column:span 2;" class="ks-form-group" style="margin-top:4px;">
                        <label style="display:flex; align-items:flex-start; gap:8px; font-weight:400; cursor:pointer; line-height:1.4;">
                            <input type="checkbox" name="ks_client_data_consent" value="1" required style="margin-top:2px; flex-shrink:0; accent-color:var(--ks-primary); width:15px; height:15px;">
                            <span style="font-size:0.75rem; color:var(--ks-text-muted);">Potwierdzam, że posiadam zgodę klienta na przetwarzanie jego danych oraz wysyłkę powiadomień serwisowych SMS. <span style="color:var(--ks-danger); font-weight:700;">(wymagane)</span></span>
                        </label>
                    </div>
                    <button type="submit" class="ks-btn-primary" style="grid-column:span 2; justify-content:center; padding:13px;">ZAPISZ URZĄDZENIE</button>
                </div>
            </form>
        <?php else : ?>
            <div style="text-align:center; padding:20px 0;">
                <div style="background:var(--ks-danger-light); width:64px; height:64px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; color:var(--ks-danger);">
                    <i data-lucide="lock" style="width:28px; height:28px;"></i>
                </div>
                <h3 style="margin-bottom:12px;">Wymagana Płatność</h3>
                <p style="color:var(--ks-text-muted); margin-bottom:24px; font-size:0.9375rem;">Osiągnąłeś limit urządzeń w swoim planie lub Twoja subskrypcja wygasła. Aby dodać nowe urządzenie, przejdź na plan Premium.</p>
                <a href="?ks_tab=plan" class="ks-btn-primary" style="width:100%; justify-content:center; padding:13px;">ZOBACZ DOSTĘPNE PLANY</a>
            </div>
        <?php endif; ?>
	</div>
</div>

<div id="logServiceModal" class="ks-overlay-form">
	<div class="ks-form-card">
		<button class="ks-close-form" onclick="this.parentElement.parentElement.style.display='none'">&times;</button>
		<h3>Zaktualizuj Serwis</h3>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
			<input type="hidden" name="action" value="ks_log_service">
            <input type="hidden" name="device_id" id="log_device_id">
			<?php wp_nonce_field( 'ks_log_service', 'ks_log_nonce' ); ?>
			<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <?php if ( $_is_premium && empty( $_magazyn_parts ) ) : ?>
                <div style="grid-column:span 2;" class="ks-form-group" id="ks-log-no-parts-banner">
                    <div style="background:#EFF6FF; border:1px solid #BFDBFE; border-radius:12px; padding:14px 16px; font-size:0.875rem; color:#1E40AF; display:flex; align-items:flex-start; gap:10px;">
                        <i data-lucide="info" style="width:16px; height:16px; flex-shrink:0; margin-top:2px; color:#3B82F6;"></i>
                        <span>Możesz przypisać użyte części podczas tego serwisu. Będą widoczne w protokole. Dodaj części serwisowe, które masz na stanie <a href="<?php echo esc_url( home_url( '/panel-serwisanta/?ks_tab=magazyn' ) ); ?>" style="font-weight:700; color:#1D4ED8; text-decoration:underline;">KLIKNIJ TUTAJ</a> lub <button type="button" onclick="ksHideNoPartsBanner('ks-log-no-parts-banner')" style="background:none; border:none; cursor:pointer; font-size:inherit; color:#1E40AF; text-decoration:underline; padding:0;">nie pokazuj ponownie</button></span>
                    </div>
                </div>
                <script>if (localStorage.getItem('ks_hide_no_parts_banner')) { document.getElementById('ks-log-no-parts-banner').style.display = 'none'; }</script>
                <?php endif; ?>
				<div style="grid-column:span 2;" class="ks-form-group"><label>Nazwa / Model</label><input type="text" name="device_name" id="log_device_name" class="ks-input"></div>
				<div style="grid-column:span 2;" class="ks-form-group"><label>Adres</label><input type="text" name="device_address" id="log_device_address" class="ks-input"></div>
				<div class="ks-form-group"><label>Telefon</label><input type="tel" name="klient_tel" id="log_klient_tel" required class="ks-input"></div>
				<div class="ks-form-group"><label>Interwał (miesiące)</label><input type="number" name="interwal" id="log_interwal" required class="ks-input"></div>
                <div class="ks-form-group"><label>Powiadomienie SMS</label>
					<select name="dni_wyprzedzenia" id="log_days" class="ks-input">
						<option value="7">7 dni</option><option value="14">14 dni</option><option value="30">30 dni</option><option value="40">40 dni</option><option value="60">60 dni</option><option value="-1">Nie wysyłaj</option>
					</select>
				</div>
                <div class="ks-form-group"><label>Data serwisu (Dziś)</label><input type="date" name="data_serwisu" value="<?php echo esc_attr( $today ); ?>" class="ks-input"></div>
				<div style="grid-column:span 2;" class="ks-form-group">
                    <label>Historia i nowa notatka</label>
                    <div id="log_history" style="font-size:0.8125rem; color:var(--ks-text-muted); max-height:80px; overflow-y:auto; margin-bottom:10px; border:1.5px solid var(--ks-border); border-radius:8px; padding:10px; background:#F8FAFC;"></div>
                    <textarea name="ks_notatki" class="ks-input" rows="2" placeholder="Dopisz nową notatkę..."></textarea>
                </div>
                <?php if ( $_is_premium && ! empty( $_magazyn_parts ) ) : ?>
                <div style="grid-column:span 2;" class="ks-form-group">
                    <label style="margin-bottom:10px; display:block;">Użyte części z magazynu <span style="font-weight:400; color:var(--ks-text-muted);">(opcjonalnie)</span></label>
                    <?php foreach ( $_magazyn_parts as $_part ) :
                        $_stock = (int) get_post_meta( $_part->ID, 'ks_stan', true );
                    ?>
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">
                        <label style="display:flex; align-items:center; gap:6px; flex:1; font-weight:400; cursor:pointer;" for="log_part_<?php echo $_part->ID; ?>">
                            <input type="checkbox" id="log_part_<?php echo $_part->ID; ?>" name="log_parts[<?php echo $_part->ID; ?>]" value="1" <?php echo $_stock <= 0 ? 'disabled' : ''; ?> aria-label="<?php echo esc_attr( $_part->post_title ); ?>" style="width:16px; height:16px; accent-color:var(--ks-primary);">
                            <?php echo esc_html( $_part->post_title ); ?>
                            <span style="font-size:0.75rem; color:<?php echo $_stock <= 0 ? 'var(--ks-danger)' : 'var(--ks-text-muted)'; ?>;">(stan: <?php echo $_stock; ?>)</span>
                        </label>
                        <input type="number" name="log_parts_qty[<?php echo $_part->ID; ?>]" value="1" min="1" max="<?php echo max( 1, $_stock ); ?>" <?php echo $_stock <= 0 ? 'disabled' : ''; ?> style="width:60px; padding:6px 8px; border:1px solid var(--ks-border); border-radius:8px; font-size:0.875rem;" aria-label="Ilość: <?php echo esc_attr( $_part->post_title ); ?>">
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
				<button type="submit" class="ks-btn-primary" style="grid-column:span 2; justify-content:center; padding:13px;">ZAPISZ ZMIANY</button>
			</div>
		</form>
	</div>
</div>

<!-- Post-save protocol prompt (shown after adding/updating a device for premium users) -->
<div id="sendProtocolPromptModal" class="ks-overlay-form">
	<div class="ks-form-card" style="max-width:440px; text-align:center;">
		<button class="ks-close-form" onclick="this.parentElement.parentElement.style.display='none'">&times;</button>
		<div style="background:var(--ks-primary-light); width:64px; height:64px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; color:var(--ks-primary);">
			<i data-lucide="file-text" style="width:28px; height:28px;"></i>
		</div>
		<h3 style="margin-bottom:12px;">Wysłać protokół serwisowy?</h3>
		<p style="color:var(--ks-text-muted); margin-bottom:24px; font-size:0.9375rem;">Czy chcesz wysłać protokół serwisowy na adres e-mail klienta?</p>
		<div style="display:grid; gap:10px;">
			<a href="<?php echo esc_url( home_url( '/panel-serwisanta/?ks_tab=protokol' ) ); ?>" class="ks-btn-primary" style="justify-content:center; padding:13px;">
				<i data-lucide="send"></i> TAK – WYŚLIJ PROTOKÓŁ
			</a>
			<button type="button" onclick="this.parentElement.parentElement.parentElement.style.display='none'" style="background:#F1F5F9; color:var(--ks-text-muted) !important; font-weight:600; padding:11px; border-radius:10px; border:1.5px solid var(--ks-border); cursor:pointer;">NIE – ZAMKNIJ</button>
		</div>
	</div>
</div>

<div id="overdueNoticeModal" class="ks-overlay-form">
	<div class="ks-form-card" style="max-width:440px; text-align:center;">
		<button class="ks-close-form" onclick="this.parentElement.parentElement.style.display='none'">&times;</button>
        <div style="background:var(--ks-danger-light); width:64px; height:64px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; color:var(--ks-danger);">
            <i data-lucide="alert-circle" style="width:28px; height:28px;"></i>
        </div>
		<h3 style="margin-bottom:12px;">Termin serwisu urządzenia minął!</h3>
		<p style="color:var(--ks-text-muted); margin-bottom:24px; font-size:0.9375rem;">Zalecamy niezwłoczny kontakt z klientem w celu umówienia wizyty.</p>
		<a href="#" id="overdue_call_btn" class="ks-btn-primary" style="width:100%; justify-content:center; padding:13px; background:var(--ks-success);">
            <i data-lucide="phone"></i> ZADZWOŃ DO KLIENTA
        </a>
	</div>
</div>

<div id="nearTermNoticeModal" class="ks-overlay-form">
	<div class="ks-form-card" style="max-width:440px; text-align:center;">
		<button class="ks-close-form" onclick="this.parentElement.parentElement.style.display='none'">&times;</button>
        <div style="background:var(--ks-warning-light); width:64px; height:64px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px; color:var(--ks-warning);">
            <i data-lucide="bell" style="width:28px; height:28px;"></i>
        </div>
		<h3 style="margin-bottom:12px;">Zbliża się termin serwisu</h3>
		<p style="color:var(--ks-text-muted); margin-bottom:24px; font-size:0.9375rem;">Termin serwisu przypada za mniej niż 30 dni. Czy chcesz wysłać klientowi powiadomienie SMS?</p>
		<div style="display:grid; gap:10px;">
            <a href="#" id="near_term_sms_btn"
			<?php
			$_nt_dev_id = isset( $_GET['ks_dev_id'] ) ? intval( $_GET['ks_dev_id'] ) : 0;
			if ( $_nt_dev_id ) :
				$_nt_nonce = wp_create_nonce( 'ks_send_manual_sms' );
				$_nt_url   = admin_url( 'admin-post.php?action=ks_send_manual_sms&ks_dev_id=' . $_nt_dev_id . '&ks_sms_nonce=' . $_nt_nonce );
			?>data-sms-url="<?php echo esc_url( $_nt_url ); ?>"<?php endif; ?>
			class="ks-btn-primary" style="justify-content:center; padding:13px;">
                <i data-lucide="send"></i> WYŚLIJ SMS Z POWIADOMIENIEM
            </a>
            <button type="button" class="ks-btn-action" onclick="this.parentElement.parentElement.parentElement.style.display='none'" style="background:#F1F5F9; color:var(--ks-text-muted) !important; font-weight:600; padding:11px; border-radius:10px; border:1.5px solid var(--ks-border);">ZAMKNIJ</button>
        </div>
	</div>
</div>

<div id="calendarModal" class="ks-overlay-form">
	<div class="ks-form-card" style="max-width:400px;">
		<button class="ks-close-form" onclick="this.parentElement.parentElement.style.display='none'">&times;</button>
		<h3>Potwierdź Wizytę</h3>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
			<input type="hidden" name="action" value="ks_save_appointment"><input type="hidden" name="device_id" id="cal_device_id">
			<?php wp_nonce_field( 'ks_save_app', 'ks_app_nonce' ); ?>
			<div class="ks-form-group"><label>Data</label><input type="date" name="app_date" required class="ks-input"></div>
			<div class="ks-form-group"><label>Godzina</label><input type="time" name="app_time" required class="ks-input"></div>
			<?php if ( $_is_service_manager && ! empty( $_worker_display_names ) ) : ?>
			<div class="ks-form-group">
				<label>Pracownik</label>
				<select name="app_worker_id" class="ks-input">
					<option value="">— Ja (Manager) —</option>
					<?php foreach ( $_worker_display_names as $_wid => $_wname ) : ?>
					<option value="<?php echo esc_attr( $_wid ); ?>"><?php echo esc_html( $_wname ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<?php endif; ?>
			<button id="cal-modal-submit" type="submit" class="ks-btn-primary" style="width:100%; justify-content:center; padding:13px;">ZAPISZ TERMIN</button>
            <div id="cal-modal-delete-row" style="display:none; margin-top:14px; border-top:1px solid var(--ks-border); padding-top:14px;">
                <button type="button" class="ks-btn-action" style="color:var(--ks-danger) !important; border-color:var(--ks-danger-light); background:var(--ks-danger-light); padding:10px 16px; font-size:0.875rem;" onclick="confirmDelete()">
                    <i data-lucide="trash-2" style="width:14px; height:14px;"></i> USUŃ WPIS Z KALENDARZA
                </button>
            </div>
		</form>
        <form id="deleteForm" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" style="display:none;">
            <input type="hidden" name="action" value="ks_delete_entry">
            <input type="hidden" name="device_id" id="del_device_id">
            <?php wp_nonce_field('ks_delete_entry', 'ks_delete_nonce'); ?>
        </form>
        <form id="deleteDeviceForm" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" style="display:none;">
            <input type="hidden" name="action" value="ks_delete_device">
            <input type="hidden" name="device_id" id="del_device_real_id">
            <?php wp_nonce_field('ks_delete_device', 'ks_delete_nonce'); ?>
        </form>
	</div>
</div>

<div id="customAppModal" class="ks-overlay-form">
	<div class="ks-form-card">
		<button class="ks-close-form" onclick="this.parentElement.parentElement.style.display='none'">&times;</button>
		<h3>Dodaj wpis do kalendarza</h3>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
			<input type="hidden" name="action" value="ks_save_custom_app">
			<?php wp_nonce_field( 'ks_save_app', 'ks_app_nonce' ); ?>
            <div class="ks-form-group"><label>Tytuł działania</label><input type="text" name="app_title" required class="ks-input"></div>
            <div class="ks-form-group"><label>Adres wizyty</label><input type="text" name="app_address" class="ks-input" placeholder="np. ul. Morska 1, Gdynia"></div>
			<div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
				<div class="ks-form-group"><label>Data</label><input type="date" name="app_date" required class="ks-input"></div>
                <div class="ks-form-group"><label>Godzina</label><input type="time" name="app_time" required class="ks-input"></div>
			</div>
            <div class="ks-form-group"><label>Notatki</label><textarea name="ks_notatki" class="ks-input" rows="3"></textarea></div>
			<button type="submit" class="ks-btn-primary" style="width:100%; justify-content:center; padding:13px;">ZAPISZ W KALENDARZU</button>
		</form>
	</div>
</div>

<div id="addNoteModal" class="ks-overlay-form">
	<div class="ks-form-card">
		<button class="ks-close-form" onclick="this.parentElement.parentElement.style.display='none'">&times;</button>
		<h3>Dodaj notatkę</h3>
		<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
			<input type="hidden" name="action" value="ks_add_note">
			<input type="hidden" name="device_id" id="note_device_id">
			<?php wp_nonce_field( 'ks_add_note', 'ks_note_nonce' ); ?>
			<div class="ks-form-group">
				<label>Notatka</label>
				<textarea name="ks_notatka" id="note_content" class="ks-input" rows="4" placeholder="Wpisz notatkę, np. klient nie odbierał, wyjechał, urządzenie już nieużywane…" required></textarea>
			</div>
			<button type="submit" class="ks-btn-primary" style="width:100%; justify-content:center; padding:13px;">ZAPISZ NOTATKĘ</button>
		</form>
	</div>
</div>

<script>
function togglePremiumMenu(e) {
	const parent = e.currentTarget;
	const submenu = document.getElementById('premiumSubmenu');
	parent.classList.toggle('open');
	submenu.classList.toggle('active');
}

// Generic mobile drawer toggle (Narzędzia / Konto)
function toggleMobileDrawer(drawerId, triggerBtn) {
	const allDrawers = document.querySelectorAll('.ks-bnav-drawer');
	const allTriggers = document.querySelectorAll('.js-mobile-drawer-toggle');
	const target = document.getElementById(drawerId);
	const isOpen = target && target.classList.contains('open');

	// Close all drawers + remove open class from all triggers
	allDrawers.forEach(function(d) { d.classList.remove('open'); });
	allTriggers.forEach(function(b) { b.classList.remove('open'); });

	if (!isOpen) {
		if (target) target.classList.add('open');
		if (triggerBtn) triggerBtn.classList.add('open');
	}
}

// Close mobile drawers when clicking outside
document.addEventListener('click', function(e) {
	if (!e.target.closest('.ks-bnav-drawer') && !e.target.closest('.js-mobile-drawer-toggle')) {
		document.querySelectorAll('.ks-bnav-drawer').forEach(function(d) { d.classList.remove('open'); });
		document.querySelectorAll('.js-mobile-drawer-toggle').forEach(function(b) { b.classList.remove('open'); });
	}
});

function openLogModal(data) {
    document.getElementById('log_device_id').value = data.id;
    document.getElementById('log_device_name').value = data.title || '';
    document.getElementById('log_device_address').value = data.adres || '';
    document.getElementById('log_klient_tel').value = data.tel || '';
    document.getElementById('log_interwal').value = data.interval || '12';
    document.getElementById('log_days').value = data.days || '30';
    document.getElementById('log_history').innerHTML = data.notes ? data.notes.replace(/\n/g, '<br>') : 'Brak poprzednich notatek.';
    document.getElementById('logServiceModal').style.display = 'block';
}
function openCalModal(id, existingDate, existingTime) {
    document.getElementById('cal_device_id').value = id;
    var dateInput   = document.querySelector('#calendarModal input[name="app_date"]');
    var timeInput   = document.querySelector('#calendarModal input[name="app_time"]');
    var modalTitle  = document.querySelector('#calendarModal h3');
    var deleteRow   = document.getElementById('cal-modal-delete-row');
    var hasExisting = !!(existingDate);
    if (dateInput) dateInput.value = existingDate || '';
    if (timeInput) timeInput.value = existingTime || '';
    if (modalTitle) modalTitle.textContent = hasExisting ? 'Zmień termin wizyty' : 'Potwierdź Wizytę';
    if (deleteRow) deleteRow.style.display = hasExisting ? '' : 'none';
    document.getElementById('calendarModal').style.display = 'block';
}
function openNoteModal(id) {
    document.getElementById('note_device_id').value = id;
    document.getElementById('note_content').value = '';
    document.getElementById('addNoteModal').style.display = 'block';
}
function confirmDelete() {
    if(confirm('Czy na pewno chcesz usunąć ten wpis z kalendarza?')) {
        document.getElementById('del_device_id').value = document.getElementById('cal_device_id').value;
        document.getElementById('deleteForm').submit();
    }
}
function deleteDevice(id) {
    if(confirm('Czy na pewno usunąć urządzenie z systemu?')) {
        document.getElementById('del_device_real_id').value = id;
        document.getElementById('deleteDeviceForm').submit();
    }
}
window.onclick = function(event) { if (event.target.className === 'ks-overlay-form') event.target.style.display = 'none'; }

// Permanently hide the no-parts banner (localStorage)
function ksHideNoPartsBanner(bannerId) {
    localStorage.setItem('ks_hide_no_parts_banner', '1');
    var el = document.getElementById(bannerId);
    if (el) el.style.display = 'none';
}


window.addEventListener('DOMContentLoaded', (event) => {
    const urlParams = new URLSearchParams(window.location.search);
    const notice = urlParams.get('ks_notice');
    const devId = urlParams.get('ks_dev_id');
    const askProtocol = urlParams.get('ks_ask_protocol');

    if ( notice === 'overdue' && devId ) {
        <?php
        // Build the tel: link server-side from post meta so the phone number
        // is never exposed in the URL (browser history, logs, referrer headers).
        $not_dev_id     = isset( $_GET['ks_dev_id'] ) ? intval( $_GET['ks_dev_id'] ) : 0;
        $overdue_device = $not_dev_id ? get_post( $not_dev_id ) : null;
        $overdue_tel    = '';
        if ( $overdue_device && (int) $overdue_device->post_author === $current_user_id ) {
            $overdue_tel = get_post_meta( $not_dev_id, 'ks_klient_tel', true );
        }
        if ( $overdue_tel ) {
            echo 'document.getElementById(\'overdue_call_btn\').href = \'tel:' . esc_js( $overdue_tel ) . '\';';
        }
        ?>
        document.getElementById('overdueNoticeModal').style.display = 'block';
    } else if ( notice === 'near_term' && devId ) {
        var smsBtn = document.getElementById('near_term_sms_btn');
        if (smsBtn && smsBtn.dataset.smsUrl) {
            smsBtn.href = smsBtn.dataset.smsUrl;
        }
        document.getElementById('nearTermNoticeModal').style.display = 'block';
    }

    // Show protocol prompt if requested (after adding/updating a device)
    if ( askProtocol === '1' ) {
        document.getElementById('sendProtocolPromptModal').style.display = 'block';
    }
});
</script>
