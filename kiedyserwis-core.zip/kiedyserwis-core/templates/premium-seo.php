<?php
/**
 * Template for Premium SEO positioning module.
 * Displayed in the technician dashboard under "Pozycjonowanie wizytówki".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_premium = ks_is_premium_active($current_user_id);

if ( ! $is_premium ) : ?>
	<style>
		.ks-seo-upsell-card {
			background:#fff; padding: 48px; border-radius:24px; border:1px solid var(--ks-border); box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); max-width: 850px; margin: 0 auto;
		}
		.ks-seo-feature-grid {
			display:grid; grid-template-columns: 1fr 1fr; gap:32px; margin-bottom:48px;
		}
		.ks-seo-upsell-card h2 { font-size: 2.25rem; font-weight: 800; letter-spacing: -0.025em; margin-bottom: 16px; }
		@media (max-width: 768px) {
			.ks-seo-upsell-card { padding: 24px; }
			.ks-seo-feature-grid { grid-template-columns: 1fr; gap: 16px; margin-bottom: 32px; }
			.ks-seo-upsell-card h2 { font-size: 1.5rem; }
			.ks-seo-feature-grid > div:last-child { grid-column: auto !important; }
		}
	</style>
    <div class="ks-seo-upsell-card">
        <div style="text-align:center; margin-bottom:40px;">
            <div style="width: 80px; height: 80px; background: rgba(79, 70, 229, 0.1); border-radius: 20px; display: flex; align-items: center; justify-content: center; margin: 0 auto 24px;">
                <i data-lucide="trending-up" style="color: var(--ks-primary); width:40px; height:40px;"></i>
            </div>
            <h2>🚀 Twoja firma może być nr 1 w okolicy! Odblokuj Pozycjonowanie Premium.</h2>
            <p style="font-size: 1.125rem; color: var(--ks-text-muted); line-height: 1.6;">Twoja wizytówka to obecnie „cyfrowa ulotka”. Zmień ją w aktywny magnes na klientów, korzystając z narzędzi SEO, które zazwyczaj kosztują tysiące złotych u agencji marketingowych.</p>
        </div>

        <div class="ks-seo-feature-grid">
            <div style="padding:24px; background:#F9FAFB; border-radius:16px;">
                <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:12px; display:flex; align-items:center; gap:8px;"><i data-lucide="map-pin" style="color:var(--ks-primary);"></i> Dominacja Lokalna (Long-Tail SEO)</h3>
                <p style="font-size:0.875rem; color:var(--ks-text-muted);"><strong>Obecnie:</strong> Jesteś widoczny głównie na nazwę swojej firmy.<br><strong>W Premium:</strong> Dodaj listę wszystkich okolicznych miast i wsi. Google zacznie wyświetlać Cię osobom szukającym pomocy dokładnie tam, gdzie dojeżdżasz.</p>
            </div>
            <div style="padding:24px; background:#F9FAFB; border-radius:16px;">
                <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:12px; display:flex; align-items:center; gap:8px;"><i data-lucide="wrench" style="color:var(--ks-primary);"></i> Pełne Menu Usług</h3>
                <p style="font-size:0.875rem; color:var(--ks-text-muted);"><strong>Obecnie:</strong> Klient widzi tylko ogólny opis.<br><strong>W Premium:</strong> Wprowadź szczegółowy wykaz (np. „awaryjne otwieranie”, „serwis 24h”, „montaż sterowników”). Każda usługa to nowa szansa na znalezienie Cię w wyszukiwarce.</p>
            </div>
            <div style="padding:24px; background:#F9FAFB; border-radius:16px;">
                <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:12px; display:flex; align-items:center; gap:8px;"><i data-lucide="factory" style="color:var(--ks-primary);"></i> Ekspert Konkretnych Marek</h3>
                <p style="font-size:0.875rem; color:var(--ks-text-muted);"><strong>W Premium:</strong> Wymień marki, które serwisujesz. Gdy ktoś wpisze w Google nazwę producenta i Twoje miasto, Twoja wizytówka pojawi się jako rekomendowany punkt serwisowy.</p>
            </div>
            <div style="padding:24px; background:#F9FAFB; border-radius:16px;">
                <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:12px; display:flex; align-items:center; gap:8px;"><i data-lucide="bot" style="color:var(--ks-primary);"></i> Inteligentny Kod Google (Schema.org)</h3>
                <p style="font-size:0.875rem; color:var(--ks-text-muted);"><strong>Technologia:</strong> Automatycznie generujemy dla Ciebie zaawansowany kod techniczny, który mówi wyszukiwarce: „To jest legalna, działająca firma”. Dzięki temu Twój profil wygląda profesjonalnie.</p>
            </div>
            <div style="padding:24px; background:#F9FAFB; border-radius:16px; grid-column: span 2;">
                <h3 style="font-size:1.125rem; font-weight:700; margin-bottom:12px; display:flex; align-items:center; gap:8px;"><i data-lucide="search" style="color:var(--ks-primary);"></i> Własny Tytuł w Wyszukiwarce</h3>
                <p style="font-size:0.875rem; color:var(--ks-text-muted);"><strong>Personalizacja:</strong> Sam zdecyduj, co widzi klient w Google jeszcze przed kliknięciem. Stwórz chwytliwe hasło, które pokona konkurencję.</p>
            </div>
        </div>

        <div style="text-align:center;">
            <p style="font-weight:700; margin-bottom:24px; font-size:1.125rem;">👉 Nie daj się wyprzedzić konkurencji. Aktywuj Pakiet Premium i pozwól klientom Cię znaleźć!</p>
            <a href="?ks_tab=plan" class="ks-btn-primary" style="padding: 16px 40px; font-size:1.125rem; border-radius:12px;">AKTYWUJ PAKIET PREMIUM</a>
        </div>
    </div>
<?php else :
    $seo_cities = get_user_meta($current_user_id, 'ks_seo_cities', true);
    $seo_services = get_user_meta($current_user_id, 'ks_seo_services', true);
    $seo_brands = get_user_meta($current_user_id, 'ks_seo_brands', true);
    $seo_title = get_user_meta($current_user_id, 'ks_seo_title', true);
    $seo_description = get_user_meta($current_user_id, 'ks_seo_description', true);
    $seo_category = get_user_meta($current_user_id, 'ks_seo_category', true);
    $seo_category_custom = get_user_meta($current_user_id, 'ks_seo_category_custom', true);
    $opening_hours = get_user_meta($current_user_id, 'ks_opening_hours', true);
    $seo_updated = isset($_GET['seo_updated']);
    ?>
    <h2 style="font-size: 1.875rem; font-weight: 800; letter-spacing: -0.025em; margin: 0 0 8px 0;">Pozycjonowanie i SEO Wizytówki</h2>
    <p style="color: var(--ks-text-muted); margin-bottom: 32px;">Skonfiguruj parametry, które pomogą Google lepiej zrozumieć i wyżej wyświetlać Twoją firmę.</p>

    <?php if($seo_updated): ?>
        <div style="background:var(--ks-success); color:#fff; padding:15px; border-radius:12px; margin-bottom:32px; font-weight:600;">✅ Ustawienia SEO zostały zapisane! Zmiany w wyszukiwarce Google mogą potrwać od kilku dni do kilku tygodni.</div>
    <?php endif; ?>

	<style>
		.ks-seo-form-container { background:#fff; padding: 40px; border-radius:20px; max-width: 800px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); border:1px solid var(--ks-border); }
		@media (max-width: 768px) {
			.ks-seo-form-container { padding: 24px; }
		}
	</style>
    <div class="ks-seo-form-container">
        <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
            <input type="hidden" name="action" value="ks_save_seo">
            <?php wp_nonce_field( 'ks_save_seo', 'ks_seo_nonce' ); ?>

            <div class="ks-form-group">
                <label>Główna Kategoria</label>
                <p style="font-size:0.75rem; color:var(--ks-text-muted); margin-top:-5px; margin-bottom:10px;">Wybierz branżę, która najlepiej opisuje Twoją działalność.</p>
                <select name="ks_seo_category" id="ks_seo_category_select" class="ks-input">
                    <option value="">Wybierz kategorię...</option>
                    <?php
                    $categories = [
                        'Ogrzewanie i Gaz (Kotły, piece, instalacje)',
                        'Klimatyzacja i Wentylacja (HVAC)',
                        'Hydraulika i Kanalizacja',
                        'AGD i Gastronomia (Pralki, lodówki, ekspresy)',
                        'Elektryka i Energetyka (Instalacje, Fotowoltaika)',
                        'Bramy, Rolety i Automatyka',
                        'Zabezpieczenia i Alarmy (Monitoring, SSWiN)',
                        'Serwis IT i Elektronika (Komputery, RTV)',
                        'Maszyny i Urządzenia Przemysłowe',
                        'Inna (wpisz poniżej...)'
                    ];
                    foreach($categories as $cat): ?>
                        <option value="<?php echo $cat; ?>" <?php selected($seo_category, $cat); ?>><?php echo $cat; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="ks-form-group" id="ks_seo_category_custom_group" style="display: <?php echo ($seo_category === 'Inna (wpisz poniżej...)') ? 'block' : 'none'; ?>;">
                <label>Twoja branża (Inna)</label>
                <input type="text" name="ks_seo_category_custom" value="<?php echo esc_attr($seo_category_custom); ?>" class="ks-input" placeholder="Wpisz swoją branżę...">
            </div>

            <div class="ks-form-group">
                <label>Obsługiwane Miasta i Miejscowości (SEO Cities)</label>
                <p style="font-size:0.75rem; color:var(--ks-text-muted); margin-top:-5px; margin-bottom:10px;">Wpisz miasta oddzielone przecinkami, np: Warszawa, Piaseczno, Pruszków, Legionowo</p>
                <textarea name="ks_seo_cities" class="ks-input" rows="2" placeholder="Wymień obszar swojego działania..."><?php echo esc_textarea($seo_cities); ?></textarea>
            </div>

            <div class="ks-form-group">
                <label>Zakres usług / Menu Usług (SEO Services)</label>
                <p style="font-size:0.75rem; color:var(--ks-text-muted); margin-top:-5px; margin-bottom:10px;">Wymień konkretne usługi, np: naprawa lodówek, serwis klimatyzacji, montaż pomp ciepła</p>
                <textarea name="ks_seo_services" class="ks-input" rows="3" placeholder="Krótki opis działalności..."><?php echo esc_textarea($seo_services); ?></textarea>
            </div>

            <div class="ks-form-group">
                <label>Obsługiwane marki (SEO Brands)</label>
                <p style="font-size:0.75rem; color:var(--ks-text-muted); margin-top:-5px; margin-bottom:10px;">Wpisz marki, które serwisujesz, np: Bosch, Samsung, Viessmann, Whirlpool</p>
                <input type="text" name="ks_seo_brands" value="<?php echo esc_attr($seo_brands); ?>" class="ks-input" placeholder="Marki produktów...">
            </div>

            <div class="ks-form-group">
                <label>Własny Tytuł SEO dla Google (Title Tag)</label>
                <p style="font-size:0.75rem; color:var(--ks-text-muted); margin-top:-5px; margin-bottom:10px;">To co widzi klient w wynikach wyszukiwania. Max 60 znaków.</p>
                <input type="text" name="ks_seo_title" id="ks_seo_title_input" maxlength="60" value="<?php echo esc_attr($seo_title); ?>" class="ks-input" placeholder="Serwis Kotłów Viessmann Wrocław | Przeglądy i Naprawa | [Nazwa]">
            </div>

            <div class="ks-form-group">
                <label>Meta Opis SEO (Meta Description)</label>
                <p style="font-size:0.75rem; color:var(--ks-text-muted); margin-top:-5px; margin-bottom:10px;">Opis Twojej firmy w Google (max 160 znaków). Podpowiedź: Montaż i serwis kotłów gazowych Viessmann we Wrocławiu. Wykonujemy roczne przeglądy gwarancyjne, pierwsze uruchomienia i naprawy. Autoryzowany serwisant. Sprawdź!</p>
                <textarea name="ks_seo_description" maxlength="160" class="ks-input" rows="3" placeholder="Wpisz profesjonalny opis swojej działalności..."><?php echo esc_textarea($seo_description); ?></textarea>
            </div>

            <div class="ks-form-group">
                <label>Godziny otwarcia (Opening Hours)</label>
                <p style="font-size:0.75rem; color:var(--ks-text-muted); margin-top:-5px; margin-bottom:10px;">Np: Pon-Pt 08:00-16:00, Sob 08:00-14:00</p>
                <input type="text" name="ks_opening_hours" value="<?php echo esc_attr($opening_hours); ?>" class="ks-input" placeholder="Pon-Pt 08:00-16:00">
            </div>

            <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Category "Other" Toggle
                const categorySelect = document.getElementById('ks_seo_category_select');
                const customGroup = document.getElementById('ks_seo_category_custom_group');

                if (categorySelect && customGroup) {
                    categorySelect.addEventListener('change', function() {
                        if (this.value === 'Inna (wpisz poniżej...)') {
                            customGroup.style.display = 'block';
                        } else {
                            customGroup.style.display = 'none';
                        }
                    });
                }
            });
            </script>

            <button type="submit" class="ks-btn-primary" style="width:100%; justify-content:center; padding:15px; font-size:1rem;">OPTYMALIZUJ WIZYTÓWKĘ</button>
        </form>
    </div>
<?php endif; ?>
