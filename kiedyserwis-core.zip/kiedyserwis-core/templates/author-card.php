<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$author_slug = get_query_var('ks_company_slug');
if ($author_slug) {
    $users = get_users(array(
        'meta_key' => 'ks_company_slug',
        'meta_value' => $author_slug,
        'number' => 1
    ));
    if (!empty($users)) {
        $author_id = $users[0]->ID;
    } else {
        // Fallback to nicename
        $user = get_user_by('slug', $author_slug);
        $author_id = $user ? $user->ID : 0;
    }
} else {
    $author = get_queried_object();
    $author_id = isset($author->ID) ? $author->ID : 0;
}

if (!$author_id) {
    echo '<div style="text-align:center; padding:100px;"><h1>Serwisant nie odnaleziony.</h1></div>';
    get_footer();
    return;
}

$comp_logo  = get_user_meta($author_id, 'ks_company_logo', true);
$comp_name  = get_user_meta($author_id, 'ks_company_name', true) ?: get_the_author_meta( 'display_name', $author_id );
$comp_desc  = get_user_meta($author_id, 'ks_company_desc', true);
$comp_phone = get_user_meta($author_id, 'ks_company_phone', true);
$comp_city  = get_user_meta($author_id, 'ks_company_city', true);
$comp_url   = get_user_meta($author_id, 'ks_company_url', true);

$is_premium = ks_is_premium_active($author_id);
$seo_services = $is_premium ? get_user_meta($author_id, 'ks_seo_services', true) : '';
$seo_brands   = $is_premium ? get_user_meta($author_id, 'ks_seo_brands', true) : '';
$seo_category = $is_premium ? get_user_meta($author_id, 'ks_seo_category', true) : '';
$seo_category_custom = $is_premium ? get_user_meta($author_id, 'ks_seo_category_custom', true) : '';
$opening_hours = $is_premium ? get_user_meta($author_id, 'ks_opening_hours', true) : '';

$display_category = ( $seo_category === 'Inna (wpisz poniżej...)' ) ? $seo_category_custom : $seo_category;
?>

<style>
    :root {
		--ks-primary: #4F46E5;
		--ks-success: #10B981;
		--ks-bg: #F9FAFB;
		--ks-text-main: #111827;
		--ks-text-muted: #6B7280;
	}
	/* Full-page background so the header (white text) is visible */
	.ks-card-page-bg {
		background-image: url('https://kiedyserwis.pl/wp-content/uploads/2026/03/bg_header.jpg');
		background-size: cover;
		background-position: center top;
		background-repeat: no-repeat;
		min-height: 100vh;
		padding-top: 200px;  /* push card below header */
		padding-bottom: 60px;
	}
	.ks-author-card {
		max-width: 480px;
		margin: 0 auto;
		padding: 48px 40px;
		background: #fff;
		border-radius: 32px;
		box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.1);
		text-align: center;
		font-family: 'Inter', system-ui, -apple-system, sans-serif;
        border: 1px solid rgba(0,0,0,0.05);
	}
	.ks-logo-wrapper {
		margin-bottom: 32px;
        display: flex;
        justify-content: center;
	}
	.ks-logo-wrapper img {
		max-width: 140px;
		height: auto;
		border-radius: 20px;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
	}
    .ks-avatar-fallback {
        width: 120px; height: 120px;
        background: var(--ks-bg);
        border-radius: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        color: #D1D5DB;
    }
	.ks-author-card h1 {
		color: var(--ks-text-main);
		margin: 0 0 12px 0;
		font-size: 2.25rem;
        font-weight: 800;
        letter-spacing: -0.025em;
	}
	.ks-author-card .tagline {
		color: var(--ks-primary);
		font-weight: 700;
		margin-bottom: 32px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        font-size: 0.75rem;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
	}
	.ks-author-card .bio {
		color: var(--ks-text-muted);
		line-height: 1.625;
		margin-bottom: 40px;
        font-size: 1.125rem;
	}
	.ks-author-card .ks-btn-call-large {
		display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
		background: var(--ks-success);
		color: #fff !important;
		text-decoration: none !important;
		padding: 20px 32px;
		border-radius: 20px;
		font-size: 1.25rem;
		font-weight: 800;
		box-shadow: 0 10px 15px -3px rgba(16, 185, 129, 0.3);
		transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
	}
	.ks-author-card .ks-btn-call-large:hover {
		transform: translateY(-2px);
		box-shadow: 0 20px 25px -5px rgba(16, 185, 129, 0.4);
		background: #059669;
	}
	.ks-branding {
		margin-top: 56px;
		font-size: 0.875rem;
		color: var(--ks-text-muted);
        border-top: 1px solid #F3F4F6;
        padding-top: 24px;
	}
	.ks-branding strong {
		color: var(--ks-primary);
        font-weight: 700;
	}
</style>

<div class="ks-card-page-bg">
<div class="ks-author-card">
	<div class="ks-logo-wrapper">
        <?php if($comp_logo): ?>
            <?php echo wp_get_attachment_image($comp_logo, 'medium'); ?>
        <?php else: ?>
            <div class="ks-avatar-fallback"><i data-lucide="wrench" style="width:52px; height:52px; color:#9CA3AF;"></i></div>
        <?php endif; ?>
    </div>

	<h1><?php echo esc_html( $comp_name ); ?></h1>
	<p class="tagline">
        <i data-lucide="map-pin" style="width:14px; height:14px;"></i>
        <span><?php echo $comp_city ? esc_html($comp_city) . ' | ' : ''; ?><?php echo $display_category ?: 'Twój Technik Serwisowy'; ?></span>
    </p>

    <?php if($comp_desc): ?>
        <div class="bio">
            <?php echo wpautop( esc_html( $comp_desc ) ); ?>
        </div>
    <?php endif; ?>

    <?php if($is_premium && ( $seo_services || $seo_brands || $opening_hours ) ): ?>
        <div style="text-align: left; margin-bottom: 40px; padding: 24px; background: #F9FAFB; border-radius: 20px; border: 1px solid #E5E7EB;">
            <?php if($seo_services): ?>
                <div style="margin-bottom: 16px;">
                    <h4 style="font-size: 0.75rem; font-weight: 800; color: var(--ks-primary); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px;">Zakres usług</h4>
                    <p style="font-size: 0.9375rem; color: var(--ks-text-main); font-weight: 500;"><?php echo esc_html($seo_services); ?></p>
                </div>
            <?php endif; ?>

            <?php if($seo_brands): ?>
                <div style="margin-bottom: 16px;">
                    <h4 style="font-size: 0.75rem; font-weight: 800; color: var(--ks-primary); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px;">Obsługiwane marki</h4>
                    <p style="font-size: 0.9375rem; color: var(--ks-text-main); font-weight: 500;"><?php echo esc_html($seo_brands); ?></p>
                </div>
            <?php endif; ?>

            <?php if($opening_hours): ?>
                <div>
                    <h4 style="font-size: 0.75rem; font-weight: 800; color: var(--ks-primary); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px;">Godziny otwarcia</h4>
                    <p style="font-size: 0.9375rem; color: var(--ks-text-main); font-weight: 500;"><?php echo esc_html($opening_hours); ?></p>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if($comp_url): ?>
        <div style="margin-bottom: 32px;">
            <a href="<?php echo esc_url($comp_url); ?>" target="_blank" style="color: var(--ks-primary); text-decoration: none; font-weight: 600; display: inline-flex; align-items: center; gap: 6px;">
                <i data-lucide="globe" style="width:18px; height:18px;"></i>
                <?php echo esc_html(preg_replace('#^https?://#', '', $comp_url)); ?>
            </a>
        </div>
    <?php endif; ?>

    <?php if($comp_phone): ?>
	    <a href="tel:<?php echo esc_attr( $comp_phone ); ?>" class="ks-btn-call-large">
            <i data-lucide="phone-call" style="width:28px; height:28px;"></i>
            ZADZWOŃ TERAZ
        </a>
    <?php endif; ?>

	<div class="ks-branding">
		<p>Chronimy Twoją gwarancję z <strong>kiedyserwis.pl</strong></p>
	</div>
</div><!-- /.ks-author-card -->
</div><!-- /.ks-card-page-bg -->

<?php
get_footer();
