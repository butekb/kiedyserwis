<?php
/**
 * Template: Cennik KiedySerwis.pl
 * Używany przez shortcode [ks_cennik].
 * Cztery kolumny: Na chwilę / Na dłużej / Na dobre (wyróżniona) / Dla Firmy.
 * Treść i linki są konfigurowane w Ustawienia → KiedySerwis → Cennik.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$_ks_plans = ks_get_pricing_plans();
?>
<style>
/* =========================================================
   KS Cennik – responsywna siatka 4-kolumnowa
   Paleta: #4F46E5 (indigo), #1e293b (slate), #f8fafc (bg)
   ========================================================= */
.ks-pricing {
	font-family: 'Inter', Arial, sans-serif;
	max-width: 1160px;
	margin: 0 auto;
	padding: 40px 16px 56px;
	box-sizing: border-box;
}

.ks-pricing__grid {
	display: grid;
	grid-template-columns: repeat(4, 1fr);
	gap: 20px;
	align-items: stretch;
}

/* ── Karta bazowa ── */
.ks-pricing__card {
	background: #fff;
	border-radius: 16px;
	border: 2px solid #e2e8f0;
	padding: 32px 24px 28px;
	display: flex;
	flex-direction: column;
	gap: 0;
	transition: box-shadow .2s;
	position: relative;
	box-sizing: border-box;
}

.ks-pricing__card:hover {
	box-shadow: 0 8px 32px rgba(79,70,229,.10);
}

/* ── Wyróżniona kolumna "Na dobre" ── */
.ks-pricing__card--featured {
	border-color: #4F46E5;
	box-shadow: 0 8px 40px rgba(79,70,229,.18);
	background: linear-gradient(160deg, #f0efff 0%, #fff 60%);
}

/* ── Kolumna firmowa ── */
.ks-pricing__card--firm {
	border-color: #1e3a5f;
	background: linear-gradient(160deg, #1e293b 0%, #0f172a 100%);
	color: #e2e8f0;
}

/* ── Odznaka (badge) ── */
.ks-pricing__badge {
	position: absolute;
	top: -13px;
	left: 50%;
	transform: translateX(-50%);
	background: #4F46E5;
	color: #fff;
	font-size: 11px;
	font-weight: 700;
	letter-spacing: .06em;
	text-transform: uppercase;
	padding: 4px 14px;
	border-radius: 20px;
	white-space: nowrap;
}

.ks-pricing__card--featured .ks-pricing__badge {
	background: #4F46E5;
}

.ks-pricing__card--firm .ks-pricing__badge {
	background: #2563eb;
}

/* ── Nagłówek ── */
.ks-pricing__period {
	font-size: 12px;
	font-weight: 700;
	text-transform: uppercase;
	letter-spacing: .08em;
	color: #64748b;
	margin-bottom: 6px;
}

.ks-pricing__card--firm .ks-pricing__period {
	color: #94a3b8;
}

.ks-pricing__name {
	font-size: 22px;
	font-weight: 800;
	color: #1e293b;
	margin: 0 0 20px;
	line-height: 1.2;
}

.ks-pricing__card--firm .ks-pricing__name {
	color: #f1f5f9;
}

/* ── Cena ── */
.ks-pricing__price-wrap {
	display: flex;
	align-items: flex-end;
	gap: 4px;
	margin-bottom: 4px;
}

.ks-pricing__currency {
	font-size: 20px;
	font-weight: 700;
	color: #4F46E5;
	line-height: 1.6;
}

.ks-pricing__amount {
	font-size: 44px;
	font-weight: 800;
	color: #1e293b;
	line-height: 1;
}

.ks-pricing__card--firm .ks-pricing__amount {
	color: #f1f5f9;
}

.ks-pricing__period-unit {
	font-size: 14px;
	color: #64748b;
	margin-bottom: 6px;
	line-height: 1.8;
}

.ks-pricing__card--firm .ks-pricing__period-unit {
	color: #94a3b8;
}

.ks-pricing__card--featured .ks-pricing__currency,
.ks-pricing__card--featured .ks-pricing__amount {
	color: #4F46E5;
}

.ks-pricing__card--firm .ks-pricing__currency {
	color: #60a5fa;
}
.ks-pricing__sub {
	font-size: 13px;
	color: #64748b;
	margin-bottom: 24px;
}

.ks-pricing__card--firm .ks-pricing__sub {
	color: #94a3b8;
}

/* ── Divider ── */
.ks-pricing__divider {
	height: 1px;
	background: #e2e8f0;
	margin: 0 0 20px;
}

.ks-pricing__card--firm .ks-pricing__divider {
	background: #334155;
}

/* ── Lista zalet ── */
.ks-pricing__features {
	list-style: none;
	margin: 0 0 28px;
	padding: 0;
	display: flex;
	flex-direction: column;
	gap: 10px;
	flex: 1;
}

.ks-pricing__features li {
	display: flex;
	align-items: flex-start;
	gap: 9px;
	font-size: 14px;
	color: #334155;
	line-height: 1.4;
}

.ks-pricing__card--firm .ks-pricing__features li {
	color: #cbd5e1;
}

.ks-pricing__features li::before {
	content: '';
	display: inline-block;
	width: 18px;
	height: 18px;
	min-width: 18px;
	border-radius: 50%;
	background: #e0e7ff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' fill='none'%3E%3Cpath d='M2 6.5l3 3 5-5' stroke='%234F46E5' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") center/10px no-repeat;
	margin-top: 1px;
}

.ks-pricing__card--firm .ks-pricing__features li::before {
	background-color: #1e3a5f;
	background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' fill='none'%3E%3Cpath d='M2 6.5l3 3 5-5' stroke='%2360a5fa' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
}

/* ── Przycisk CTA ── */
.ks-pricing__btn {
	display: block;
	text-align: center;
	padding: 13px 20px;
	border-radius: 10px;
	font-size: 15px;
	font-weight: 700;
	text-decoration: none;
	transition: filter .15s, transform .1s;
	cursor: pointer;
	border: none;
}

.ks-pricing__btn:hover {
	filter: brightness(1.08);
	transform: translateY(-1px);
}

.ks-pricing__btn--outline {
	background: transparent;
	border: 2px solid #4F46E5;
	color: #4F46E5;
}

.ks-pricing__btn--primary {
	background: #4F46E5;
	color: #fff;
}

.ks-pricing__btn--firm {
	background: #2563eb;
	color: #fff;
}

/* ── Stopka z info o VAT ── */
.ks-pricing__footer {
	text-align: center;
	margin-top: 28px;
	font-size: 12.5px;
	color: #64748b;
	line-height: 1.6;
}

.ks-pricing__footer strong {
	color: #1e293b;
}

/* =========================================================
   Responsywność
   ========================================================= */

/* Tablet: 2 kolumny */
@media (max-width: 900px) {
	.ks-pricing__grid {
		grid-template-columns: repeat(2, 1fr);
	}

	/* Wyróżniona karta na pełną szerokość */
	.ks-pricing__card--featured {
		grid-column: span 2;
	}
}

/* Mobile: 1 kolumna – każda karta pełna szerokość */
@media (max-width: 768px) {
	.ks-pricing__grid {
		grid-template-columns: 1fr;
	}

	.ks-pricing__card--featured {
		grid-column: span 1;
	}

	.ks-pricing__amount {
		font-size: 38px;
	}

	.ks-pricing__name {
		font-size: 19px;
	}
}
</style>

<?php
// Klasy kart i styl przycisku dla każdego planu
$_ks_card_classes = array( '', '', 'ks-pricing__card--featured', 'ks-pricing__card--firm' );
$_ks_btn_classes  = array( 'ks-pricing__btn--outline', 'ks-pricing__btn--outline', 'ks-pricing__btn--primary', 'ks-pricing__btn--firm' );
?>
<section class="ks-pricing" aria-label="Cennik KiedySerwis.pl">
	<div class="ks-pricing__grid">

		<?php foreach ( $_ks_plans as $_ks_i => $_ks_plan ) :
			$_ks_card_cls = $_ks_card_classes[ $_ks_i ];
			$_ks_btn_cls  = $_ks_btn_classes[ $_ks_i ];
			$_ks_badge    = trim( $_ks_plan['badge'] );
			$_ks_features = array_filter( array_map( 'trim', explode( "\n", $_ks_plan['features'] ) ) );
		?>
		<div class="ks-pricing__card <?php echo esc_attr( $_ks_card_cls ); ?>">

			<?php if ( $_ks_badge ) : ?>
				<span class="ks-pricing__badge"><?php echo esc_html( $_ks_badge ); ?></span>
			<?php endif; ?>

			<p class="ks-pricing__period"><?php echo esc_html( $_ks_plan['period'] ); ?></p>
			<h3 class="ks-pricing__name"><?php echo esc_html( $_ks_plan['name'] ); ?></h3>

			<div class="ks-pricing__price-wrap">
				<span class="ks-pricing__currency">zł</span>
				<span class="ks-pricing__amount"><?php echo esc_html( $_ks_plan['price'] ); ?></span>
				<span class="ks-pricing__period-unit"><?php echo esc_html( $_ks_plan['price_unit'] ); ?></span>
			</div>
			<p class="ks-pricing__sub"><?php echo esc_html( $_ks_plan['sub'] ); ?></p>

			<div class="ks-pricing__divider"></div>

			<ul class="ks-pricing__features">
				<?php foreach ( $_ks_features as $_ks_feat ) : ?>
					<li><?php echo esc_html( $_ks_feat ); ?></li>
				<?php endforeach; ?>
			</ul>

			<a href="<?php echo esc_url( $_ks_plan['btn_url'] ); ?>"
			   class="ks-pricing__btn <?php echo esc_attr( $_ks_btn_cls ); ?>">
				<?php echo esc_html( $_ks_plan['btn_text'] ); ?>
			</a>
		</div>
		<?php endforeach; ?>

	</div><!-- /.ks-pricing__grid -->

	<p class="ks-pricing__footer">
		<strong>Wystawiamy faktury (zwolnienie z VAT).</strong>
		Podstawa prawna: zwolnienie podmiotowe.
	</p>
</section>
