<?php
/**
 * Plugin Name: KiedySerwis Core
 * Description: Kompleksowa logika biznesowa dla platformy kiedyserwis.pl.
 * Version: 1.0.0
 * Author: Jules
 * Text Domain: kiedyserwis-core
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Returns the absolute path to the debug log file.
 *
 * The filename includes a random secret suffix generated on first use and
 * stored in wp_options. This makes the URL unguessable on Nginx servers where
 * .htaccess rules do not apply, providing defence-in-depth on top of the
 * .htaccess denial rule that already protects Apache-based setups.
 *
 * @return string Absolute path to the log file.
 */
function ks_get_log_path() {
	$suffix = get_option( 'ks_log_suffix' );
	if ( empty( $suffix ) ) {
		$suffix = bin2hex( random_bytes( 8 ) ); // 16-char hex, 64-bit entropy
		update_option( 'ks_log_suffix', $suffix, false );
	}
	return WP_CONTENT_DIR . '/ks-logs/ks-debug-' . $suffix . '.log';
}

/**
 * Zapisuje wiadomość do pliku logów (ks-debug-{suffix}.log w wp-content/ks-logs/).
 * Działa niezależnie od ustawień WP_DEBUG i konfiguracji PHP error_log.
 *
 * @param string $message Treść wpisu logu.
 */
function ks_log( $message ) {
	$log_dir  = WP_CONTENT_DIR . '/ks-logs/';
	$log_file = ks_get_log_path();

	// Ensure the log directory exists and is protected from direct web access.
	if ( ! is_dir( $log_dir ) ) {
		wp_mkdir_p( $log_dir );
	}

	// Create .htaccess to deny direct access on Apache servers.
	$htaccess = $log_dir . '.htaccess';
	if ( ! file_exists( $htaccess ) ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
		file_put_contents( $htaccess, "Require all denied\nDeny from all\n" );
	}

	// Create index.php to prevent directory listing on all servers.
	$index = $log_dir . 'index.php';
	if ( ! file_exists( $index ) ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
		file_put_contents( $index, '<?php // Silence is golden.' );
	}

	$entry = '[' . current_time( 'mysql' ) . '] ' . $message . PHP_EOL;
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
	if ( false === file_put_contents( $log_file, $entry, FILE_APPEND | LOCK_EX ) ) {
		// Fallback to PHP error log if the file cannot be written.
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( '[KiedySerwis] ks_log zapis nieudany. Wiadomość: ' . $message );
	}
}

/**
 * Returns the current DateTimeImmutable in the Europe/Warsaw timezone.
 * Use instead of date() / time() to ensure all dates are computed
 * in Polish local time regardless of the server's default timezone.
 *
 * @return DateTimeImmutable
 */
function ks_warsaw_now() {
	return new DateTimeImmutable( 'now', new DateTimeZone( 'Europe/Warsaw' ) );
}

// Include Module Handlers
require_once plugin_dir_path( __FILE__ ) . 'inc/class-ks-seo-handler.php';
new KS_SEO_Handler();

// New Calendar Module (REST routes + feature-flag assets)
require_once plugin_dir_path( __FILE__ ) . 'inc/ks-calendar.php';

require_once plugin_dir_path( __FILE__ ) . 'inc/class-ks-admin-users.php';
new KS_Admin_Users();

require_once plugin_dir_path( __FILE__ ) . 'inc/class-ks-multi-account.php';
new KS_Multi_Account();

// Register Custom Post Type: ks_urzadzenie
function ks_register_urzadzenie_cpt() {
	$labels = array(
		'name'               => 'Urządzenia',
		'singular_name'      => 'Urządzenie',
		'menu_name'          => 'Urządzenia',
		'name_admin_bar'     => 'Urządzenie',
		'add_new'            => 'Dodaj nowe',
		'add_new_item'       => 'Dodaj nowe urządzenie',
		'new_item'           => 'Nowe urządzenie',
		'edit_item'          => 'Edytuj urządzenie',
		'view_item'          => 'Zobacz urządzenie',
		'all_items'          => 'Wszystkie urządzenia',
		'search_items'       => 'Szukaj urządzeń',
		'not_found'          => 'Nie znaleziono urządzeń.',
		'not_found_in_trash' => 'Brak urządzeń w koszu.',
	);

	$args = array(
		'labels'             => $labels,
		// Not publicly accessible – device records contain sensitive customer PII
		// (phone numbers, addresses, service notes). They must only be accessible
		// through the authenticated technician dashboard, never via public URLs or
		// the WordPress REST API.
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,   // Keep visible in WP-Admin for editors/admins.
		'show_in_menu'       => true,
		'query_var'          => false,  // Disable ?ks_urzadzenie=slug URL access.
		'rewrite'            => false,  // No public permalink required.
		'capability_type'    => 'post',
		'has_archive'        => false,  // No public archive page.
		'hierarchical'       => false,
		'menu_position'      => 5,
		'supports'           => array( 'title', 'author' ),
		'show_in_rest'       => false,  // Exclude from /wp-json/wp/v2/ks_urzadzenie.
	);

	register_post_type( 'ks_urzadzenie', $args );
}
add_action( 'init', 'ks_register_urzadzenie_cpt' );

/**
 * Register Custom Post Type: ks_czesc (Magazyn parts)
 */
function ks_register_czesc_cpt() {
	register_post_type( 'ks_czesc', array(
		'labels'             => array(
			'name'          => 'Części magazynowe',
			'singular_name' => 'Część',
		),
		'public'             => false,
		'show_ui'            => false,
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => false,
		'supports'           => array( 'title', 'author' ),
		'show_in_rest'       => false,
	) );
}
add_action( 'init', 'ks_register_czesc_cpt' );

/**
 * Prevent page caching for logged-in technicians on the front end.
 *
 * Fires on template_redirect (before any output) so that cache plugins which
 * check the DONOTCACHEPAGE constant or LiteSpeed action hooks at this stage
 * correctly mark the response as non-cacheable. This ensures that the
 * device/calendar counts and FullCalendar assets (JS/CSS versions) are always
 * served fresh and are never stale due to a cached HTML page.
 */
add_action( 'template_redirect', 'ks_prevent_technician_page_cache' );

function ks_prevent_technician_page_cache() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	// Standard browser + proxy no-cache headers.
	nocache_headers();
	// LiteSpeed Cache: prevent server-side caching and mark as private.
	do_action( 'litespeed_control_set_nocache', 'ks-technician-dashboard' );
	do_action( 'litespeed_control_set_private', 'ks-technician-dashboard' );
	// WP Super Cache / W3TC / WP Rocket / SG Optimizer: universal constant.
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
}


/**
 * Helper: purge all relevant caches for a user so changes are visible immediately.
 *
 * @param int $user_id WordPress user ID. When provided, the author-card URL is also flushed.
 *                     Pass 0 (or omit) for actions that don't have an author page to flush
 *                     (e.g. deleting a device, saving an appointment).
 */
function ks_purge_user_cache( $user_id = 0 ) {
	// LiteSpeed Cache – flush specific URLs
	if ( function_exists( 'litespeed_purge_url' ) ) {
		litespeed_purge_url( home_url( '/panel-serwisanta/' ) );
		if ( $user_id ) {
			litespeed_purge_url( get_author_posts_url( $user_id ) );
		}
	}
	// LiteSpeed Cache – broadcast purge_all via the action hook (works in newer LSCWP versions)
	do_action( 'litespeed_purge_all' );
	// WP Rocket
	if ( function_exists( 'rocket_clean_domain' ) ) {
		rocket_clean_domain();
	}
	// W3 Total Cache
	if ( function_exists( 'w3tc_flush_all' ) ) {
		w3tc_flush_all();
	}
	// WP Super Cache
	if ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache();
	}
}

/* =====================================================================
 * Centralized ownership validation helpers
 *
 * These functions are the single authoritative check for all device and
 * part ownership across every handler and template.  All admin-post.php
 * action callbacks MUST use these helpers instead of inline post_author
 * comparisons so that future refactors cannot accidentally drop the check.
 * ===================================================================== */

/**
 * Return true when $device_id is a published ks_urzadzenie that belongs to
 * $user_id (defaults to the current logged-in user).
 *
 * @param int $device_id Post ID of the device.
 * @param int $user_id   User to verify against; 0 means current user.
 * @return bool
 */
function ks_verify_device_ownership( $device_id, $user_id = 0 ) {
	if ( ! $user_id ) {
		$user_id = get_current_user_id();
	}
	if ( ! $user_id || ! $device_id ) {
		return false;
	}
	$device = get_post( (int) $device_id );
	if ( ! $device || $device->post_type !== 'ks_urzadzenie' ) {
		return false;
	}
	$device_author = (int) $device->post_author;
	// Bezpośredni właściciel.
	if ( $device_author === $user_id ) {
		return true;
	}
	// Manager Serwisu może korzystać z urządzeń swoich pracowników.
	$user = get_userdata( $user_id );
	if ( $user && in_array( 'service_manager', (array) $user->roles, true ) ) {
		$worker_ids = KS_Multi_Account::get_worker_ids_for_manager( $user_id );
		if ( in_array( $device_author, $worker_ids, true ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Return true when $part_id is a published ks_czesc that belongs to $user_id
 * (defaults to the current logged-in user).
 *
 * @param int $part_id Post ID of the warehouse part.
 * @param int $user_id User to verify against; 0 means current user.
 * @return bool
 */
function ks_verify_part_ownership( $part_id, $user_id = 0 ) {
	if ( ! $user_id ) {
		$user_id = get_current_user_id();
	}
	if ( ! $user_id || ! $part_id ) {
		return false;
	}
	$part = get_post( (int) $part_id );
	return $part
		&& $part->post_type === 'ks_czesc'
		&& (int) $part->post_author === $user_id;
}

// Register Meta Fields
function ks_add_urzadzenie_meta_boxes() {
	add_meta_box(
		'ks_urzadzenie_meta',
		'Szczegóły Urządzenia',
		'ks_urzadzenie_meta_callback',
		'ks_urzadzenie',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'ks_add_urzadzenie_meta_boxes' );

function ks_urzadzenie_meta_callback( $post ) {
	wp_nonce_field( 'ks_urzadzenie_meta_save', 'ks_urzadzenie_meta_nonce' );

	$tel = get_post_meta( $post->ID, 'ks_klient_tel', true );
	$adres = get_post_meta( $post->ID, 'ks_adres_urzadzenia', true );
	$data_serwisu = get_post_meta( $post->ID, 'ks_data_serwisu', true );
	$interwal = get_post_meta( $post->ID, 'ks_interwal', true );
	$dni_wyprzedzenia = get_post_meta( $post->ID, 'ks_dni_wyprzedzenia', true );
	$notatki = get_post_meta( $post->ID, 'ks_notatki', true );
	$status_sms = get_post_meta( $post->ID, 'ks_status_sms', true );

	echo '<table class="form-table">';

	echo '<tr><th><label for="ks_klient_tel">Numer telefonu klienta</label></th>';
	echo '<td><input type="text" id="ks_klient_tel" name="ks_klient_tel" value="' . esc_attr( $tel ) . '" class="regular-text"></td></tr>';

	echo '<tr><th><label for="ks_adres_urzadzenia">Adres urządzenia</label></th>';
	echo '<td><input type="text" id="ks_adres_urzadzenia" name="ks_adres_urzadzenia" value="' . esc_attr( $adres ) . '" class="regular-text"></td></tr>';

	echo '<tr><th><label for="ks_data_serwisu">Data ostatniego serwisu</label></th>';
	echo '<td><input type="date" id="ks_data_serwisu" name="ks_data_serwisu" value="' . esc_attr( $data_serwisu ) . '" class="regular-text"></td></tr>';

	echo '<tr><th><label for="ks_interwal">Interwał serwisu (miesiące)</label></th>';
	echo '<td><input type="number" id="ks_interwal" name="ks_interwal" value="' . esc_attr( $interwal ) . '" class="regular-text"></td></tr>';

	echo '<tr><th><label for="ks_dni_wyprzedzenia">Dni wyprzedzenia SMS</label></th>';
	echo '<td><input type="number" id="ks_dni_wyprzedzenia" name="ks_dni_wyprzedzenia" value="' . esc_attr( $dni_wyprzedzenia ) . '" class="regular-text"></td></tr>';

	echo '<tr><th><label for="ks_notatki">Notatki serwisowe</label></th>';
	echo '<td><textarea id="ks_notatki" name="ks_notatki" class="large-text" rows="4">' . esc_textarea( $notatki ) . '</textarea></td></tr>';

	echo '<tr><th><label for="ks_status_sms">Status powiadomienia</label></th>';
	echo '<td><select id="ks_status_sms" name="ks_status_sms">
		<option value="Oczekuje" ' . selected( $status_sms, 'Oczekuje', false ) . '>Oczekuje</option>
		<option value="Wysłano" ' . selected( $status_sms, 'Wysłano', false ) . '>Wysłano</option>
		<option value="Błąd" ' . selected( $status_sms, 'Błąd', false ) . '>Błąd</option>
		<option value="Wyłączono" ' . selected( $status_sms, 'Wyłączono', false ) . '>Wyłączono</option>
	</select></td></tr>';

	echo '</table>';
}

function ks_save_urzadzenie_meta( $post_id ) {
	if ( ! isset( $_POST['ks_urzadzenie_meta_nonce'] ) || ! wp_verify_nonce( $_POST['ks_urzadzenie_meta_nonce'], 'ks_urzadzenie_meta_save' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$fields = array(
		'ks_klient_tel',
		'ks_adres_urzadzenia',
		'ks_data_serwisu',
		'ks_interwal',
		'ks_dni_wyprzedzenia',
		'ks_notatki',
		'ks_status_sms',
	);

	// Sanitize each field with the appropriate function.
	// ks_notatki is a multi-line textarea and must preserve newlines.
	$textarea_fields = array( 'ks_notatki' );
	foreach ( $fields as $field ) {
		if ( isset( $_POST[ $field ] ) ) {
			if ( in_array( $field, $textarea_fields, true ) ) {
				update_post_meta( $post_id, $field, sanitize_textarea_field( $_POST[ $field ] ) );
			} else {
				update_post_meta( $post_id, $field, sanitize_text_field( $_POST[ $field ] ) );
			}
		}
	}

	// When the SMS status is manually reset to 'Oczekuje', clear the dedup guard
	// so the next batch run will actually attempt to send the SMS.
	if ( isset( $_POST['ks_status_sms'] ) && 'Oczekuje' === sanitize_text_field( $_POST['ks_status_sms'] ) ) {
		delete_post_meta( $post_id, 'ks_last_sms_date' );
	}
}
add_action( 'save_post_ks_urzadzenie', 'ks_save_urzadzenie_meta' );

/**
 * SMS Automation "Brain"
 */

// Register a minute-by-minute cron schedule so the SMS queue is checked every
// minute starting at the configured send hour, until all messages are delivered.
add_filter( 'cron_schedules', function ( $schedules ) {
	$schedules['ks_every_minute'] = array(
		'interval' => 60,
		'display'  => 'Co minutę (KiedySerwis)',
	);
	return $schedules;
} );

// Auto-migrate existing installs from the old 'daily' fixed-time schedule to
// 'ks_every_minute'. Runs on every request but only writes to the DB once
// (subsequent calls find the schedule already correct and do nothing).
add_action( 'plugins_loaded', function () {
	if ( 'ks_every_minute' !== wp_get_schedule( 'ks_daily_sms_cron' ) ) {
		wp_clear_scheduled_hook( 'ks_daily_sms_cron' );
		wp_schedule_event( time(), 'ks_every_minute', 'ks_daily_sms_cron' );
	}
} );

/**
 * Return (and lazily generate) the secret token used to authenticate the
 * external server-cron endpoint.
 */
function ks_get_cron_secret() {
	$secret = get_option( 'ks_cron_secret' );
	if ( empty( $secret ) ) {
		$secret = bin2hex( random_bytes( 24 ) ); // 48-char hex string
		update_option( 'ks_cron_secret', $secret, false );
	}
	return $secret;
}

/**
 * Return (and lazily generate) the shared secret used to authenticate
 * incoming payment webhooks from 1koszyk.pl.
 *
 * This secret must be configured in the 1koszyk.pl webhook settings panel
 * as the value that will be sent in the X-KS-Webhook-Secret HTTP header
 * (or as the ks_secret POST parameter) with every webhook request.
 */
function ks_get_webhook_secret() {
	$secret = get_option( 'ks_webhook_secret' );
	if ( empty( $secret ) ) {
		$secret = bin2hex( random_bytes( 24 ) ); // 48-char hex string
		update_option( 'ks_webhook_secret', $secret, false );
	}
	return $secret;
}

/**
 * Returns the full URL that an external cron service (e.g. Seohost.pl) should
 * call once per day to trigger the SMS reminder batch.
 */
function ks_get_external_cron_url() {
	return rest_url( 'ks/v1/run-sms-queue' ) . '?token=' . ks_get_cron_secret();
}

// Role creation and Cron scheduling on plugin activation
function ks_activation_handler() {
	// Generate the external-cron secret token if not already set
	ks_get_cron_secret();

	// Generate the payment webhook secret if not already set
	ks_get_webhook_secret();

	// Schedule Cron
	if ( ! wp_next_scheduled( 'ks_daily_sms_cron' ) ) {
		wp_schedule_event( time(), 'ks_every_minute', 'ks_daily_sms_cron' );
	}

	// Create Roles
	if ( ! get_role( 'serwisant' ) ) {
		add_role( 'serwisant', 'Serwisant', array(
			'read'           => true,
			'edit_posts'     => true,
			'delete_posts'   => false,
			'publish_posts'  => true,
			'upload_files'   => true,
		) );
	}

	// Multi-Account roles (service_manager, service_worker)
	KS_Multi_Account::register_roles();

	// Register CPT
	ks_register_urzadzenie_cpt();

	// Register Rewrite Rules
	ks_add_custom_rewrite_rules();

	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'ks_activation_handler' );

// WP-Admin Redirection & Restriction
function ks_restrict_admin_access() {
	if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
		// Allow access to admin-post.php
		if ( strpos( $_SERVER['PHP_SELF'], 'admin-post.php' ) !== false ) {
			return;
		}

		$user = wp_get_current_user();
		if ( $user && in_array( 'serwisant', (array) $user->roles ) ) {
			wp_safe_redirect( home_url( '/panel-serwisanta/' ) );
			exit;
		}
	}
}
add_action( 'admin_init', 'ks_restrict_admin_access' );

// Hide Admin Bar for Technicians
add_filter('show_admin_bar', function($show) {
    if ( current_user_can('serwisant') && !current_user_can('administrator') ) {
        return false;
    }
    return $show;
});

// Unschedule on deactivation
function ks_deactivation_unschedule() {
	wp_clear_scheduled_hook( 'ks_daily_sms_cron' );
}
register_deactivation_hook( __FILE__, 'ks_deactivation_unschedule' );

// Returns the configured SMS send hour (0–23), defaulting to 10.
function ks_get_sms_send_hour() {
	return max( 0, min( 23, (int) get_option( 'ks_sms_send_hour', 10 ) ) );
}

// Reschedule cron whenever the SMS send hour setting changes.
// The send hour is honoured by the hour-check inside ks_process_daily_sms;
// there is no need to anchor the cron event to a specific start time.
function ks_reschedule_sms_cron_on_change( $old_value, $new_value ) {
	wp_clear_scheduled_hook( 'ks_daily_sms_cron' );
	wp_schedule_event( time(), 'ks_every_minute', 'ks_daily_sms_cron' );
}
add_action( 'update_option_ks_sms_send_hour', 'ks_reschedule_sms_cron_on_change', 10, 2 );

// The Cron Job Logic – processes devices in batches to support large datasets (1 000+ technicians × 500+ devices)
function ks_process_daily_sms() {
	// Honour the configured send hour – bail out silently if too early.
	// The hook fires every minute, so logging here would flood the debug file.
	$current_hour = (int) ks_warsaw_now()->format( 'G' );
	$send_hour    = ks_get_sms_send_hour();
	if ( $current_hour < $send_hour ) {
		return;
	}

	ks_run_sms_batch_for_today();
}
add_action( 'ks_daily_sms_cron', 'ks_process_daily_sms' );

/**
 * Core batch SMS logic: sends today's reminders for all eligible devices.
 * Extracted so both the scheduled cron and the admin force-run can share it.
 *
 * @return int Number of SMS messages successfully dispatched.
 */
function ks_run_sms_batch_for_today() {
	// When called from a non-authenticated context (external server-cron REST endpoint
	// or WP-Cron), get_current_user_id() returns 0. WordPress's get_posts() restricts
	// results for non-publicly-queryable CPTs when there is no authenticated user with
	// sufficient capabilities – the device list is returned empty and no SMS is sent.
	// We temporarily switch to the first administrator so the query returns all
	// device posts, then restore the original user ID when the function exits.
	$prev_user_id = get_current_user_id();
	if ( 0 === $prev_user_id ) {
		$admin_ids = get_users( array(
			'role'    => 'administrator',
			'number'  => 1,
			'fields'  => 'ids',
			'orderby' => 'ID',
			'order'   => 'ASC',
		) );
		if ( ! empty( $admin_ids ) ) {
			wp_set_current_user( (int) $admin_ids[0] );
		}
	}

	$today      = ks_warsaw_now()->format( 'Y-m-d' );
	$batch_size = 200;
	$offset     = 0;
	$sent_count = 0;

	ks_log( "[KiedySerwis] Batch SMS: start. Dzisiaj (Warsaw): {$today}" );

	do {
		$args = array(
			'post_type'              => 'ks_urzadzenie',
			'posts_per_page'         => $batch_size,
			'offset'                 => $offset,
			'post_status'            => 'publish',
			'no_found_rows'          => true,  // Skip COUNT(*) – we control the loop ourselves
			'update_post_term_cache' => false, // We don't use terms
			// Pre-filter in SQL: only devices that have a service date and a phone number
			// and haven't had an SMS sent yet (status != 'Wysłano').
			// Exclude devices that use a custom app for notifications.
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'ks_data_serwisu',
					'compare' => 'EXISTS',
				),
				array(
					'key'     => 'ks_klient_tel',
					'compare' => 'EXISTS',
				),
				array(
					'relation' => 'OR',
					array(
						'key'     => 'ks_status_sms',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => 'ks_status_sms',
						'value'   => 'Wysłano',
						'compare' => '!=',
					),
				),
				array(
					'key'     => 'ks_is_custom_app',
					'compare' => 'NOT EXISTS',
				),
			),
		);

		$devices = get_posts( $args );
		ks_log( '[KiedySerwis] Batch SMS: znaleziono ' . count( $devices ) . ' urządzeń w tej partii (offset=' . $offset . ').' );

		foreach ( $devices as $device ) {
			$last_service  = get_post_meta( $device->ID, 'ks_data_serwisu', true );
			$interval      = (int) get_post_meta( $device->ID, 'ks_interwal', true );
			$days_before   = (int) get_post_meta( $device->ID, 'ks_dni_wyprzedzenia', true );
			$phone         = get_post_meta( $device->ID, 'ks_klient_tel', true );
			$status        = get_post_meta( $device->ID, 'ks_status_sms', true );
			$last_sms_date = get_post_meta( $device->ID, 'ks_last_sms_date', true );

			// Skip devices where SMS notifications are disabled ("Nie wysyłaj").
			if ( $days_before < 0 ) {
				continue;
			}

			if ( empty( $last_service ) || empty( $interval ) || empty( $phone ) ) {
				ks_log( "[KiedySerwis] Batch SMS: pominięto urządzenie ID={$device->ID} (brak daty/interwału/telefonu)." );
				continue;
			}

			// Calculate Next Service Date and Trigger Date using wp_date() so the
			// computed dates always honour the WordPress timezone (Europe/Warsaw),
			// not the server's PHP default timezone (often UTC).
			$next_service_ts   = strtotime( "+{$interval} months", strtotime( $last_service ) );
			$next_service_date = wp_date( 'Y-m-d', $next_service_ts );
			$trigger_ts        = strtotime( "-{$days_before} days", $next_service_ts );
			$trigger_date      = wp_date( 'Y-m-d', $trigger_ts );

			// Skip devices whose reminder is still in the future.
			// Allow today AND any overdue date (<= today) so that a missed cron run
			// does not permanently skip the reminder.
			if ( $trigger_date > $today ) {
				continue;
			}

			if ( $status === 'Wysłano' ) {
				continue;
			}

			// Deduplication guard: if an SMS was already sent to this device today
			// (ks_last_sms_date stores the Y-m-d of the last actual send), skip it.
			// This prevents duplicate sends when the external cron fires every 5 minutes.
			if ( $last_sms_date === $today ) {
				ks_log( "[KiedySerwis] Batch SMS: urządzenie ID={$device->ID} pominięto – SMS już wysłany dzisiaj ({$today})." );
				continue;
			}

			$author_id    = $device->post_author;
			$company_name = get_user_meta( $author_id, 'ks_company_name', true ) ?: get_the_author_meta( 'display_name', $author_id );
			$card_url     = get_author_posts_url( $author_id );

			// Free-plan SMS cap: skip if the device owner has exhausted their limit.
			if ( ! ks_can_send_sms( $author_id ) ) {
				ks_log( "[KiedySerwis] Batch SMS: pominięto urządzenie ID={$device->ID} – właściciel ID={$author_id} osiągnął limit SMS w planie darmowym." );
				continue;
			}

			$template = get_option(
				'ks_sms_message_template',
				'Przypomnienie od kiedyserwis.pl: Twoje urządzenie [Nazwa] wymaga serwisu. Firma: [Firma]. Zobacz wizytówkę i umów się: [Link]'
			);
			$message = str_replace(
				array( '[Nazwa]', '[Firma]', '[Link]' ),
				array( get_the_title( $device->ID ), $company_name, $card_url ),
				$template
			);

			ks_log( "[KiedySerwis] Batch SMS: wysyłam SMS dla urządzenia ID={$device->ID}, trigger={$trigger_date}." );

			// Trigger the custom action hook (connected to ks_send_sms)
			do_action( 'ks_trigger_sms_reminder', $phone, $message, $device->ID );

			// Update status and last-send date to prevent double sending.
			// The hook sets status to 'Błąd' on failure; on success we mark it 'Wysłano'
			// and record today's date so the 5-minute external cron cannot re-trigger it.
			if ( get_post_meta( $device->ID, 'ks_status_sms', true ) !== 'Błąd' ) {
				update_post_meta( $device->ID, 'ks_last_sms_date', $today );
				update_post_meta( $device->ID, 'ks_status_sms', 'Wysłano' );
				ks_increment_user_sms_count( $author_id );
				$sent_count++;
			}
		}

		$offset += $batch_size;

	} while ( count( $devices ) === $batch_size ); // Stop when the last batch was smaller than a full page

	ks_log( "[KiedySerwis] Batch SMS: zakończono. Wysłano: {$sent_count}." );

	// Restore the original user context.
	wp_set_current_user( $prev_user_id );

	return $sent_count;
}

/**
 * Central SMS sending function.
 *
 * Reads the active provider from options and dispatches through the correct API.
 * Automatically prepends the +48 country prefix for Polish numbers when missing.
 *
 * --- Wymagany plan smsgateway24.com ---
 * Wtyczka komunikuje się z smsgateway24.com przez dwa endpointy HTTP:
 *   1. GET /getdata/gettoken  – pobranie tokena sesji (e-mail + hasło)
 *   2. POST /getdata/addsms   – kolejkowanie SMS na wskazanym urządzeniu Android (device_id)
 *
 * Są to endpointy Android Gateway API – standardowej metody korzystania z serwisu
 * przez podłączony telefon. SMS fizycznie wychodzi z karty SIM Twojego urządzenia.
 *
 * WYMAGANY PLAN: Startup (jedno urządzenie).
 * Plan Profi („API requests") dotyczy wysyłki SMS bez własnego telefonu –
 * przez infrastrukturę smsgateway24.com. Wtyczka tego trybu nie używa.
 *
 * @param string $phone   Recipient phone number.
 * @param string $message Message body.
 * @return bool           True on success, false on failure.
 */
function ks_send_sms( $phone, $message ) {
	// Normalise phone: strip spaces/dashes, add +48 if no country code present
	$phone = preg_replace( '/[\s\-]/', '', $phone );
	if ( strpos( $phone, '+' ) !== 0 ) {
		$phone = '+48' . ltrim( $phone, '0' );
	}

	$provider = get_option( 'ks_sms_provider', 'android' );

	if ( $provider === 'android' ) {
		$email     = get_option( 'ks_sg24_email', '' );
		$password  = get_option( 'ks_sg24_password', '' );
		$device_id = get_option( 'ks_sg24_device_id', '' );
		$sim_slot  = (int) get_option( 'ks_sg24_sim_slot', '0' );

		if ( empty( $email ) || empty( $password ) ) {
			ks_log( '[KiedySerwis] ks_send_sms: Brak e-mail lub hasła do konta SmsGateway24.' );
			return false;
		}

		if ( empty( $device_id ) || (int) $device_id === 0 ) {
			ks_log( '[KiedySerwis] ks_send_sms: Brak ID urządzenia (ks_sg24_device_id). Skonfiguruj je w Ustawienia → KiedySerwis.' );
			return false;
		}

		// Step 1: Fetch a session token using email + password.
		// Endpoint: POST https://smsgateway24.com/getdata/gettoken
		// Using POST (not GET) to avoid proxy/CDN caching of the token response
		// and to match the official API documentation example.
		$token_response = wp_remote_post(
			'https://smsgateway24.com/getdata/gettoken',
			array(
				'timeout' => 15,
				'body'    => array(
					'email' => $email,
					'pass'  => $password,
				),
			)
		);

		if ( is_wp_error( $token_response ) ) {
			ks_log( '[KiedySerwis] ks_send_sms gettoken WP_Error: ' . $token_response->get_error_message() );
			return false;
		}

		$token_code = wp_remote_retrieve_response_code( $token_response );
		$token_body = wp_remote_retrieve_body( $token_response );
		$token_data = json_decode( $token_body, true );

		if ( $token_code < 200 || $token_code >= 300 || ! is_array( $token_data ) ) {
			ks_log( "[KiedySerwis] ks_send_sms gettoken błąd HTTP {$token_code}: {$token_body}" );
			return false;
		}

		if ( (int) $token_data['error'] !== 0 ) {
			$err_msg = isset( $token_data['message'] ) ? $token_data['message'] : $token_body;
			ks_log( "[KiedySerwis] ks_send_sms gettoken błąd API: {$err_msg}" );
			return false;
		}

		if ( empty( $token_data['token'] ) ) {
			ks_log( '[KiedySerwis] ks_send_sms gettoken: brak tokena w odpowiedzi API.' );
			return false;
		}

		$token = $token_data['token'];

		// Step 2: Send the SMS using the token.
		// Endpoint: POST https://smsgateway24.com/getdata/addsms
		$sms_response = wp_remote_post(
			'https://smsgateway24.com/getdata/addsms',
			array(
				'timeout' => 15,
				'body'    => array(
					'token'     => $token,
					'sendto'    => $phone,
					'body'      => $message,
					'device_id' => (int) $device_id,
					'sim'       => $sim_slot,
				),
			)
		);

		if ( is_wp_error( $sms_response ) ) {
			ks_log( '[KiedySerwis] ks_send_sms addsms WP_Error: ' . $sms_response->get_error_message() );
			return false;
		}

		$sms_code = wp_remote_retrieve_response_code( $sms_response );
		$sms_body = wp_remote_retrieve_body( $sms_response );

		ks_log( '[KiedySerwis] ks_send_sms addsms odpowiedź: ' . $sms_body );

		if ( $sms_code < 200 || $sms_code >= 300 ) {
			ks_log( "[KiedySerwis] ks_send_sms addsms błąd HTTP {$sms_code}: {$sms_body}" );
			return false;
		}

		$sms_data = json_decode( $sms_body, true );
		if ( ! is_array( $sms_data ) || (int) $sms_data['error'] !== 0 ) {
			$err_msg = isset( $sms_data['message'] ) ? $sms_data['message'] : $sms_body;
			ks_log( "[KiedySerwis] ks_send_sms addsms błąd API: {$err_msg}" );
			return false;
		}

		ks_log( '[KiedySerwis] ks_send_sms sukces. sms_id=' . ( $sms_data['sms_id'] ?? '?' ) );
		return true;
	}

	// Placeholder for future providers (e.g. SMSAPI.pl)
	ks_log( '[KiedySerwis] ks_send_sms: Nieobsługiwany dostawca: ' . $provider );
	return false;
}

/**
 * Hook: connect the existing ks_trigger_sms_reminder action to ks_send_sms.
 */
add_action( 'ks_trigger_sms_reminder', function( $phone, $message, $device_id ) {
	$result = ks_send_sms( $phone, $message );
	if ( ! $result ) {
		update_post_meta( $device_id, 'ks_status_sms', 'Błąd' );
	}
}, 10, 3 );

/**
 * Helper: deduct parts from warehouse based on POST data.
 *
 * Reads log_parts[PART_ID]=1 and log_parts_qty[PART_ID]=qty from $_POST,
 * verifies the part belongs to $user_id, then reduces ks_stan accordingly.
 *
 * @param int $user_id Technician user ID.
 */
function ks_deduct_posted_parts( $user_id, $device_id = 0 ) {
	$parts_raw = isset( $_POST['log_parts'] ) && is_array( $_POST['log_parts'] )
		? wp_unslash( $_POST['log_parts'] )
		: array();
	$qty_raw = isset( $_POST['log_parts_qty'] ) && is_array( $_POST['log_parts_qty'] )
		? array_map( 'intval', wp_unslash( $_POST['log_parts_qty'] ) )
		: array();

	$parts_used = array(); // Parts used in this service operation

	foreach ( $parts_raw as $part_id_str => $checked ) {
		$part_id = intval( $part_id_str );
		if ( $part_id <= 0 ) continue;
		// Centralized ownership check: only allow deducting parts owned by this user.
		if ( ! ks_verify_part_ownership( $part_id, $user_id ) ) continue;
		$current_stock = (int) get_post_meta( $part_id, 'ks_stan', true );
		$qty = min( max( 1, $qty_raw[ $part_id_str ] ?? 1 ), $current_stock );
		if ( $qty <= 0 ) continue;
		update_post_meta( $part_id, 'ks_stan', $current_stock - $qty );
		$parts_used[] = array(
			'id'   => $part_id,
			'name' => get_the_title( $part_id ),
			'qty'  => $qty,
		);
	}

	// Persist the used-parts list on the device as a cumulative dated history
	if ( $device_id > 0 && ! empty( $parts_used ) ) {
		// Load existing history (may be empty or from prior services)
		$history_raw = get_post_meta( $device_id, 'ks_parts_history', true );
		$history = array();
		if ( $history_raw ) {
			$decoded = json_decode( $history_raw, true );
			if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
				$history = $decoded;
			}
		}

		// Append a new entry with the current service date
		$service_date = isset( $_POST['data_serwisu'] ) && $_POST['data_serwisu']
			? sanitize_text_field( wp_unslash( $_POST['data_serwisu'] ) )
			: ks_warsaw_now()->format( 'Y-m-d' );
		$history[] = array(
			'date'  => $service_date . ' ' . ks_warsaw_now()->format( 'H:i' ),
			'parts' => $parts_used,
		);

		$encoded = wp_json_encode( $history );
		if ( false !== $encoded ) {
			update_post_meta( $device_id, 'ks_parts_history', $encoded );
		}
	} elseif ( $device_id > 0 && empty( $parts_used ) ) {
		// No parts selected — leave existing history intact (do nothing)
	}

	// Notify the technician if any part dropped below minimum stock
	ks_check_magazyn_low_stock( $user_id );
}

/**
 * Frontend Form Handling
 */
function ks_handle_device_creation() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_device_nonce'] ) || ! wp_verify_nonce( $_POST['ks_device_nonce'], 'ks_create_device' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$device_name      = sanitize_text_field( $_POST['device_name'] );
	$device_address   = sanitize_text_field( $_POST['device_address'] );
	$klient_tel       = sanitize_text_field( $_POST['klient_tel'] );
	$data_serwisu     = sanitize_text_field( $_POST['data_serwisu'] );
	$interwal         = intval( $_POST['interwal'] );
	$dni_wyprzedzenia = intval( $_POST['dni_wyprzedzenia'] );
	$notatki          = sanitize_textarea_field( $_POST['ks_notatki'] );

	if ( empty( $klient_tel ) ) {
		wp_safe_redirect( add_query_arg( 'error', 'missing_fields', home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	$current_user_id = get_current_user_id();

	// Plan Check: Can the user add a new device?
	if ( ! ks_can_add_device( $current_user_id ) ) {
		wp_safe_redirect( add_query_arg( 'error', 'limit_reached', home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	// Check if device with this phone already exists for this technician
	$existing = get_posts(array(
		'post_type'        => 'ks_urzadzenie',
		'author'           => $current_user_id,
		'meta_key'         => 'ks_klient_tel',
		'meta_value'       => $klient_tel,
		'posts_per_page'   => 1,
		'fields'           => 'ids',
		'suppress_filters' => false, // Allow pre_get_posts isolation to run.
	));

	if ( ! empty( $existing ) ) {
		$post_id = $existing[0];
		wp_update_post( array(
			'ID'         => $post_id,
			'post_title' => $device_name ?: get_the_title($post_id)
		) );
	} else {
		$new_device = array(
			'post_title'   => $device_name ?: 'Urządzenie ' . $klient_tel,
			'post_type'    => 'ks_urzadzenie',
			'post_status'  => 'publish',
			'post_author'  => $current_user_id,
		);
		$post_id = wp_insert_post( $new_device );
	}

	if ( $post_id ) {
		update_post_meta( $post_id, 'ks_klient_tel', $klient_tel );
		update_post_meta( $post_id, 'ks_adres_urzadzenia', $device_address );
		update_post_meta( $post_id, 'ks_data_serwisu', $data_serwisu );
		update_post_meta( $post_id, 'ks_interwal', $interwal );
		update_post_meta( $post_id, 'ks_dni_wyprzedzenia', $dni_wyprzedzenia );
		if ( ! empty( $notatki ) ) {
			$old_notes = get_post_meta( $post_id, 'ks_notatki', true );
			$entry = ks_warsaw_now()->format( 'Y-m-d H:i' ) . ": " . $notatki;
			$updated_notes = empty( $old_notes ) ? $entry : $entry . "\n---\n" . $old_notes;
			update_post_meta( $post_id, 'ks_notatki', $updated_notes );
		}
		update_post_meta( $post_id, 'ks_status_sms', $dni_wyprzedzenia < 0 ? 'Wyłączono' : 'Oczekuje' );
		delete_post_meta( $post_id, 'ks_last_sms_date' );
		// Also saves used parts to device meta for the protocol "send" form.
		if ( ks_is_premium_active( $current_user_id ) ) {
			ks_deduct_posted_parts( $current_user_id, $post_id );
		}

		// Force Cache Purge
		clean_post_cache($post_id);
		ks_purge_user_cache();

		$redirect_args = array('success' => 'device_added', 'updated' => time());

		// For premium users with a configured protocol, offer to send a service protocol
		$protocol_checklist = get_user_meta( $current_user_id, 'ks_protocol_checklist', true );
		$protocol_enabled   = get_user_meta( $current_user_id, 'ks_protocol_enabled', true ) === '1';
		if ( ks_is_premium_active( $current_user_id ) && $protocol_enabled && ! empty( $protocol_checklist ) ) {
			$redirect_args['ks_ask_protocol'] = '1';
		}

		// Check if service date is near or overdue
		if ( ! empty( $data_serwisu ) && ! empty( $interwal ) ) {
			$next_service_ts = strtotime( "+$interwal months", strtotime( $data_serwisu ) );
			$days_until = ( $next_service_ts - time() ) / DAY_IN_SECONDS;

			if ( $days_until <= 0 ) {
				$redirect_args['ks_notice'] = 'overdue';
				$redirect_args['ks_dev_id'] = $post_id;
				// Phone number intentionally excluded from the URL to prevent PII exposure
				// (browser history, server logs, referrer headers). The dashboard reads it
				// from post meta using ks_dev_id when it needs to display or use it.
			} elseif ( $days_until <= 30 ) {
				$redirect_args['ks_notice'] = 'near_term';
				$redirect_args['ks_dev_id'] = $post_id;
			}
		}

		wp_safe_redirect( add_query_arg( $redirect_args, home_url( '/panel-serwisanta/' ) ) );
	} else {
		wp_safe_redirect( add_query_arg( 'error', 'save_failed', home_url( '/panel-serwisanta/' ) ) );
	}
	exit;
}
add_action( 'admin_post_ks_add_device', 'ks_handle_device_creation' );

// 4. Handle Service Log (Update device details)
function ks_handle_service_log() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_log_nonce'] ) || ! wp_verify_nonce( $_POST['ks_log_nonce'], 'ks_log_service' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$device_id = intval( $_POST['device_id'] );

	// Centralized ownership check: ensures the device belongs to the current user.
	if ( ! ks_verify_device_ownership( $device_id ) ) {
		wp_die( 'Nieprawidłowe urządzenie.' );
	}

	$device_name      = sanitize_text_field( $_POST['device_name'] );
	$device_address   = sanitize_text_field( $_POST['device_address'] );
	$klient_tel       = sanitize_text_field( $_POST['klient_tel'] );
	$data_serwisu     = sanitize_text_field( $_POST['data_serwisu'] );
	$interwal         = intval( $_POST['interwal'] );
	$dni_wyprzedzenia = intval( $_POST['dni_wyprzedzenia'] );
	$new_note         = sanitize_textarea_field( $_POST['ks_notatki'] );

	wp_update_post( array(
		'ID'         => $device_id,
		'post_title' => $device_name
	) );

	update_post_meta( $device_id, 'ks_klient_tel', $klient_tel );
	update_post_meta( $device_id, 'ks_adres_urzadzenia', $device_address );
	update_post_meta( $device_id, 'ks_data_serwisu', $data_serwisu );
	update_post_meta( $device_id, 'ks_interwal', $interwal );
	update_post_meta( $device_id, 'ks_dni_wyprzedzenia', $dni_wyprzedzenia );

	if ( ! empty( $new_note ) ) {
		$old_notes = get_post_meta( $device_id, 'ks_notatki', true );
		$entry = ks_warsaw_now()->format( 'Y-m-d H:i' ) . ": " . $new_note;
		$updated_notes = empty( $old_notes ) ? $entry : $entry . "\n---\n" . $old_notes;
		update_post_meta( $device_id, 'ks_notatki', $updated_notes );
	}

	update_post_meta( $device_id, 'ks_status_sms', $dni_wyprzedzenia < 0 ? 'Wyłączono' : 'Oczekuje' ); // Reset status
	delete_post_meta( $device_id, 'ks_last_sms_date' );

	// Deduct any warehouse parts and save to device meta for smart protocol display
	if ( ks_is_premium_active( $current_uid ) ) {
		ks_deduct_posted_parts( $current_uid, $device_id );
	}

	// Force Cache Purge
	clean_post_cache($device_id);
	ks_purge_user_cache();

	$redirect_args = array( 'success' => 'service_logged', 'updated' => time() );

	// For premium users with a configured protocol, offer to send a service protocol
	$protocol_checklist = get_user_meta( $current_uid, 'ks_protocol_checklist', true );
	$protocol_enabled   = get_user_meta( $current_uid, 'ks_protocol_enabled', true ) === '1';
	if ( ks_is_premium_active( $current_uid ) && $protocol_enabled && ! empty( $protocol_checklist ) ) {
		$redirect_args['ks_ask_protocol'] = '1';
	}

	wp_safe_redirect( add_query_arg( $redirect_args, home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_log_service', 'ks_handle_service_log' );

// 4b. Handle Add Note (quick note without full service update)
function ks_handle_add_note() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_note_nonce'] ) || ! wp_verify_nonce( $_POST['ks_note_nonce'], 'ks_add_note' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$device_id = intval( $_POST['device_id'] );

	if ( ! ks_verify_device_ownership( $device_id ) ) {
		wp_die( 'Nieprawidłowe urządzenie.' );
	}

	$new_note = sanitize_textarea_field( $_POST['ks_notatka'] );

	if ( ! empty( $new_note ) ) {
		$old_notes     = get_post_meta( $device_id, 'ks_notatki', true );
		$entry         = ks_warsaw_now()->format( 'Y-m-d H:i' ) . ': ' . $new_note;
		$updated_notes = empty( $old_notes ) ? $entry : $entry . "\n---\n" . $old_notes;
		update_post_meta( $device_id, 'ks_notatki', $updated_notes );
		clean_post_cache( $device_id );
		ks_purge_user_cache();
	}

	wp_safe_redirect( add_query_arg( array( 'success' => 'note_added', 'updated' => time() ), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_add_note', 'ks_handle_add_note' );
function ks_handle_save_appointment() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_app_nonce'] ) || ! wp_verify_nonce( $_POST['ks_app_nonce'], 'ks_save_app' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$device_id = intval( $_POST['device_id'] );

	// Centralized ownership check.
	if ( ! ks_verify_device_ownership( $device_id ) ) {
		wp_die( 'Nieprawidłowe urządzenie.' );
	}

	$app_date = sanitize_text_field( $_POST['app_date'] );
	$app_time = sanitize_text_field( $_POST['app_time'] );

	update_post_meta( $device_id, 'ks_app_date', $app_date );
	update_post_meta( $device_id, 'ks_app_time', $app_time );
	// Clear end-time and reset status so stale data from a previous appointment
	// does not remain after a reschedule via this legacy form.
	delete_post_meta( $device_id, 'ks_app_end_time' );
	update_post_meta( $device_id, 'ks_app_status', 'scheduled' );

	// If a service_manager assigned the appointment to a worker, reassign the post author.
	$current_user = wp_get_current_user();
	if ( in_array( 'service_manager', (array) $current_user->roles, true ) ) {
		$app_worker_id = isset( $_POST['app_worker_id'] ) ? intval( $_POST['app_worker_id'] ) : 0;
		if ( $app_worker_id > 0 ) {
			$allowed = KS_Multi_Account::get_worker_ids_for_manager( $current_user->ID );
			if ( in_array( $app_worker_id, $allowed, true ) ) {
				wp_update_post( array( 'ID' => $device_id, 'post_author' => $app_worker_id ) );
			}
		}
	}

	// Force Cache Purge
	clean_post_cache($device_id);
	ks_purge_user_cache();

	wp_safe_redirect( add_query_arg( array('ks_tab' => 'calendar', 'updated' => time()), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_save_appointment', 'ks_handle_save_appointment' );

// 6. Handle Business Card Update
function ks_handle_save_business_card() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_card_nonce'] ) || ! wp_verify_nonce( $_POST['ks_card_nonce'], 'ks_save_card' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$user_id = get_current_user_id();

	$company_name = sanitize_text_field( $_POST['company_name'] );
	$phone        = sanitize_text_field( $_POST['company_phone'] );
	$desc         = sanitize_textarea_field( $_POST['company_desc'] );
	$city         = sanitize_text_field( $_POST['company_city'] );

    $company_url  = sanitize_text_field( $_POST['company_url'] );
    if ( ! empty( $company_url ) && ! preg_match( '#^https?://#i', $company_url ) ) {
        $company_url = 'https://' . $company_url;
    }
    $company_url  = esc_url_raw( $company_url );

	$company_slug = sanitize_title($company_name);

	update_user_meta( $user_id, 'nickname', $company_name );
	wp_update_user( array(
		'ID'           => $user_id,
		'display_name' => $company_name,
		'user_nicename' => $company_slug
	) );
	update_user_meta( $user_id, 'ks_company_slug', $company_slug );
    update_user_meta( $user_id, 'ks_company_name', $company_name );
	update_user_meta( $user_id, 'ks_company_phone', $phone );
	update_user_meta( $user_id, 'ks_company_desc', $desc );
	update_user_meta( $user_id, 'ks_company_city', $city );
    update_user_meta( $user_id, 'ks_company_url', $company_url );
	update_user_meta( $user_id, 'ks_profile_updated_at', current_time('timestamp') );

	// Handle Logo Upload
	if ( ! empty( $_FILES['company_logo']['name'] ) ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$file     = $_FILES['company_logo'];
		$max_size = 5 * 1024 * 1024; // 5 MB

		// Hard-block known dangerous extensions before any MIME-type check.
		// This is a belt-and-suspenders defence: WordPress's wp_check_filetype_and_ext
		// also catches these, but an explicit deny-list makes the intent unmistakable.
		$dangerous_extensions = array(
			'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'phar',
			'exe', 'bat', 'cmd', 'com', 'msi', 'dll', 'so',
			'sh', 'bash', 'zsh', 'fish', 'ps1', 'psm1', 'vbs', 'vbe',
			'js', 'mjs', 'cjs', 'jsx', 'ts', 'tsx',
			'py', 'pyc', 'rb', 'pl', 'lua', 'go', 'java', 'class', 'jar',
			'asp', 'aspx', 'cfm', 'cgi',
			'svg', 'svgz',
			'htm', 'html', 'xhtml', 'xml', 'xsl', 'xslt',
			'htaccess', 'htpasswd', 'ini', 'conf', 'config',
			'zip', 'tar', 'gz', 'tgz', 'bz2', 'rar', '7z',
		);
		$file_ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		if ( in_array( $file_ext, $dangerous_extensions, true ) ) {
			wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'wizytowka', 'logo_error' => 'format' ), home_url( '/panel-serwisanta/' ) ) );
			exit;
		}

		// Check file size.
		if ( $file['size'] > $max_size ) {
			wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'wizytowka', 'logo_error' => 'size' ), home_url( '/panel-serwisanta/' ) ) );
			exit;
		}

		// Validate using actual file content, not the user-supplied $file['type'].
		// Only safe raster image formats are accepted.
		$allowed_mimes = array(
			'jpg|jpeg|jpe' => 'image/jpeg',
			'png'          => 'image/png',
			'gif'          => 'image/gif',
			'webp'         => 'image/webp',
		);
		$file_type_info = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], $allowed_mimes );

		if ( empty( $file_type_info['type'] ) ) {
			wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'wizytowka', 'logo_error' => 'format' ), home_url( '/panel-serwisanta/' ) ) );
			exit;
		}

		$attachment_id = media_handle_upload( 'company_logo', 0 );

		if ( ! is_wp_error( $attachment_id ) ) {
			update_user_meta( $user_id, 'ks_company_logo', $attachment_id );
		}
	}

	// Clear profile meta to avoid stale data display
	update_user_meta( $user_id, 'ks_profile_updated_at', current_time('timestamp') );

	// Force Cache Purge
	ks_purge_user_cache($user_id);

	wp_safe_redirect( add_query_arg( array('ks_tab' => 'wizytowka', 'profile_updated' => '1', 'updated' => time()), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_save_card', 'ks_handle_save_business_card' );

// 7. Handle Extra Calendar Entry (non-device)
function ks_handle_save_custom_app() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_app_nonce'] ) || ! wp_verify_nonce( $_POST['ks_app_nonce'], 'ks_save_app' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$current_user_id = get_current_user_id();
	$title    = sanitize_text_field( $_POST['app_title'] );
	$address  = sanitize_text_field( $_POST['app_address'] );
	$app_date = sanitize_text_field( $_POST['app_date'] );
	$app_time = sanitize_text_field( $_POST['app_time'] );
	$note     = sanitize_textarea_field( $_POST['ks_notatki'] );

	$new_app = array(
		'post_title'   => $title,
		'post_type'    => 'ks_urzadzenie', // Using same CPT for simplicity but can be filtered
		'post_status'  => 'publish',
		'post_author'  => $current_user_id,
	);

	$post_id = wp_insert_post( $new_app );
	if($post_id) {
		update_post_meta( $post_id, 'ks_app_date', $app_date );
		update_post_meta( $post_id, 'ks_app_time', $app_time );
		update_post_meta( $post_id, 'ks_adres_urzadzenia', $address );
		update_post_meta( $post_id, 'ks_notatki', $note );
		update_post_meta( $post_id, 'ks_is_custom_app', 'true' );

		// Force Cache Purge
		clean_post_cache($post_id);
		ks_purge_user_cache();
	}

	wp_safe_redirect( add_query_arg( array('ks_tab' => 'calendar', 'updated' => time()), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_save_custom_app', 'ks_handle_save_custom_app' );

// 8. Handle Appointment Completion (Quick log from calendar)
function ks_handle_complete_appointment() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_log_nonce'] ) || ! wp_verify_nonce( $_POST['ks_log_nonce'], 'ks_complete_app' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$device_id = intval( $_POST['device_id'] );

	// Centralized ownership check.
	if ( ! ks_verify_device_ownership( $device_id ) ) {
		wp_die( 'Nieprawidłowe urządzenie.' );
	}

	$today = ks_warsaw_now()->format( 'Y-m-d' );
	update_post_meta( $device_id, 'ks_data_serwisu', $today );
	update_post_meta( $device_id, 'ks_status_sms', 'Oczekuje' );
	delete_post_meta( $device_id, 'ks_last_sms_date' );

	// Prepend "Wizyta zakończona" to history
	$old_notes = get_post_meta( $device_id, 'ks_notatki', true );
	$entry = ks_warsaw_now()->format( 'Y-m-d H:i' ) . ": Wizyta serwisowa zakończona pomyślnie.";
	$updated_notes = empty( $old_notes ) ? $entry : $entry . "\n---\n" . $old_notes;
	update_post_meta( $device_id, 'ks_notatki', $updated_notes );

	// Remove from planned calendar – clear all appointment-related meta.
	delete_post_meta( $device_id, 'ks_app_date' );
	delete_post_meta( $device_id, 'ks_app_time' );
	delete_post_meta( $device_id, 'ks_app_end_time' );
	delete_post_meta( $device_id, 'ks_app_status' );

	// Force Cache Purge
	clean_post_cache($device_id);
	ks_purge_user_cache();

	wp_safe_redirect( add_query_arg( array('ks_tab' => 'calendar', 'success' => 'service_logged', 'updated' => time()), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_complete_app', 'ks_handle_complete_appointment' );

// 9. Handle Entry Deletion
function ks_handle_delete_entry() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_delete_nonce'] ) || ! wp_verify_nonce( $_POST['ks_delete_nonce'], 'ks_delete_entry' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$device_id = intval( $_POST['device_id'] );

	// Centralized ownership check.
	if ( ! ks_verify_device_ownership( $device_id ) ) {
		wp_die( 'Nieprawidłowe urządzenie.' );
	}

	$is_custom = get_post_meta( $device_id, 'ks_is_custom_app', true );

	if ( $is_custom === 'true' ) {
		wp_delete_post( $device_id, true );
	} else {
		// Clear all appointment-related meta from the device record.
		delete_post_meta( $device_id, 'ks_app_date' );
		delete_post_meta( $device_id, 'ks_app_time' );
		delete_post_meta( $device_id, 'ks_app_end_time' );
		delete_post_meta( $device_id, 'ks_app_status' );
	}

	// Force Cache Purge
	clean_post_cache($device_id);
	ks_purge_user_cache();

	wp_safe_redirect( add_query_arg( array('ks_tab' => 'calendar', 'updated' => time()), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_delete_entry', 'ks_handle_delete_entry' );

// 10. Handle Device Deletion
function ks_handle_delete_device() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_delete_nonce'] ) || ! wp_verify_nonce( $_POST['ks_delete_nonce'], 'ks_delete_device' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$device_id = intval( $_POST['device_id'] );

	// Centralized ownership check.
	if ( ! ks_verify_device_ownership( $device_id ) ) {
		wp_die( 'Nieprawidłowe urządzenie.' );
	}

	wp_delete_post( $device_id, true );

	// Force Cache Purge
	ks_purge_user_cache();

	wp_safe_redirect( add_query_arg( array('ks_tab' => 'devices', 'updated' => time()), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_delete_device', 'ks_handle_delete_device' );

// 12. Handle Company Logo Deletion
function ks_handle_delete_logo() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_delete_logo_nonce'] ) || ! wp_verify_nonce( $_POST['ks_delete_logo_nonce'], 'ks_delete_logo' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$user_id = get_current_user_id();
	delete_user_meta( $user_id, 'ks_company_logo' );

	// Force Cache Purge
	ks_purge_user_cache( $user_id );

	wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'wizytowka', 'logo_deleted' => '1' ), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_delete_logo', 'ks_handle_delete_logo' );

/**
 * Manual SMS Sending
 */
function ks_handle_manual_sms_send() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_GET['ks_sms_nonce'] ) || ! wp_verify_nonce( $_GET['ks_sms_nonce'], 'ks_send_manual_sms' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$device_id = intval( $_GET['ks_dev_id'] );

	// Centralized ownership check.
	if ( ! ks_verify_device_ownership( $device_id ) ) {
		wp_die( 'Nieprawidłowe urządzenie.' );
	}

	$phone        = get_post_meta( $device_id, 'ks_klient_tel', true );
	$author_id    = get_current_user_id();

	// If current user is a service_worker, use the manager's profile URL in the SMS link.
	$sms_profile_id = $author_id;
	$current_user_obj = get_userdata( $author_id );
	if ( $current_user_obj && in_array( 'service_worker', (array) $current_user_obj->roles, true ) ) {
		$parent_manager_id = (int) get_user_meta( $author_id, '_parent_manager_id', true );
		if ( $parent_manager_id > 0 ) {
			$sms_profile_id = $parent_manager_id;
		}
	}

	$company_name = get_user_meta( $sms_profile_id, 'ks_company_name', true ) ?: get_the_author_meta( 'display_name', $sms_profile_id );
	$card_url     = get_author_posts_url( $sms_profile_id );

	// Free-plan SMS cap check.
	if ( ! ks_can_send_sms( $author_id ) ) {
		wp_safe_redirect( add_query_arg( array( 'error' => 'sms_limit_reached', 'updated' => time() ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	$template = get_option(
		'ks_sms_message_template',
		'Przypomnienie od kiedyserwis.pl: Twoje urządzenie [Nazwa] wymaga serwisu. Firma: [Firma]. Zobacz wizytówkę i umów się: [Link]'
	);
	$message = str_replace(
		array( '[Nazwa]', '[Firma]', '[Link]' ),
		array( get_the_title( $device_id ), $company_name, $card_url ),
		$template
	);

	// Trigger the custom action hook (connected to ks_send_sms)
	do_action( 'ks_trigger_sms_reminder', $phone, $message, $device_id );

	// Update status (hook may have already set 'Błąd')
	if ( get_post_meta( $device_id, 'ks_status_sms', true ) !== 'Błąd' ) {
		update_post_meta( $device_id, 'ks_last_sms_date', ks_warsaw_now()->format( 'Y-m-d' ) );
		update_post_meta( $device_id, 'ks_status_sms', 'Wysłano' );
		ks_increment_user_sms_count( $author_id );
	}

	wp_safe_redirect( add_query_arg( array('success' => 'sms_sent', 'updated' => time()), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_send_manual_sms', 'ks_handle_manual_sms_send' );

/**
 * Admin SMS Queue – Manual SMS Send
 * Allows administrators to manually send SMS reminders for overdue (red) queue rows.
 */
function ks_handle_admin_queue_send_sms() {
	if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	$device_id = intval( $_GET['ks_dev_id'] ?? 0 );

	if ( ! isset( $_GET['ks_nonce'] ) || ! wp_verify_nonce( $_GET['ks_nonce'], 'ks_admin_queue_send_sms_' . $device_id ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$device = get_post( $device_id );
	if ( ! $device ) {
		wp_die( 'Nieprawidłowe urządzenie.' );
	}

	$phone        = get_post_meta( $device_id, 'ks_klient_tel', true );
	$author_id    = $device->post_author;
	$company_name = get_user_meta( $author_id, 'ks_company_name', true ) ?: get_the_author_meta( 'display_name', $author_id );
	$card_url     = get_author_posts_url( $author_id );

	// Free-plan SMS cap: admins can manually force a send but we still track the count
	// to prevent platform abuse; if the owner is over limit, block the send.
	if ( ! ks_can_send_sms( $author_id ) ) {
		$redirect_url = admin_url( 'options-general.php?page=kiedyserwis-settings&tab=sms_queue&sms_limit_reached=1' );
		wp_safe_redirect( $redirect_url );
		exit;
	}

	$template = get_option(
		'ks_sms_message_template',
		'Przypomnienie od kiedyserwis.pl: Twoje urządzenie [Nazwa] wymaga serwisu. Firma: [Firma]. Zobacz wizytówkę i umów się: [Link]'
	);
	$message = str_replace(
		array( '[Nazwa]', '[Firma]', '[Link]' ),
		array( get_the_title( $device->ID ), $company_name, $card_url ),
		$template
	);

	do_action( 'ks_trigger_sms_reminder', $phone, $message, $device->ID );

	$sms_status = get_post_meta( $device_id, 'ks_status_sms', true );
	if ( $sms_status !== 'Błąd' ) {
		update_post_meta( $device_id, 'ks_last_sms_date', ks_warsaw_now()->format( 'Y-m-d' ) );
		update_post_meta( $device_id, 'ks_status_sms', 'Wysłano' );
		ks_increment_user_sms_count( $author_id );
		$result_param = 'sms_sent';
	} else {
		$result_param = 'sms_error';
	}

	$redirect_url = admin_url( 'options-general.php?page=kiedyserwis-settings&tab=sms_queue&' . $result_param . '=1' );
	wp_safe_redirect( $redirect_url );
	exit;
}
add_action( 'admin_post_ks_admin_queue_send_sms', 'ks_handle_admin_queue_send_sms' );

/**
 * Admin: Force-run the daily SMS cron immediately (for debugging / recovery).
 * Skips the send-hour guard – the admin is explicitly requesting it.
 */
function ks_handle_force_run_cron() {
	if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_nonce'] ) || ! wp_verify_nonce( $_POST['ks_nonce'], 'ks_force_run_cron' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$sent_count = ks_run_sms_batch_for_today();

	ks_log( "[KiedySerwis] Ręczne uruchomienie cron przez admina. Wysłano SMS: {$sent_count}" );

	$redirect_url = admin_url( 'options-general.php?page=kiedyserwis-settings&tab=sms_queue&cron_run=1&sent=' . $sent_count );
	wp_safe_redirect( $redirect_url );
	exit;
}
add_action( 'admin_post_ks_force_run_cron', 'ks_handle_force_run_cron' );

/**
 * Admin: Regenerate the external cron secret token.
 */
function ks_handle_regenerate_cron_secret() {
	if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}

	if ( ! isset( $_POST['ks_nonce'] ) || ! wp_verify_nonce( $_POST['ks_nonce'], 'ks_regenerate_cron_secret' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$new_secret = bin2hex( random_bytes( 24 ) );
	update_option( 'ks_cron_secret', $new_secret, false );

	ks_log( '[KiedySerwis] Token Crona zewnętrznego został zregenerowany.' );

	$redirect_url = admin_url( 'options-general.php?page=kiedyserwis-settings&tab=settings&cron_token_regenerated=1' );
	wp_safe_redirect( $redirect_url );
	exit;
}
add_action( 'admin_post_ks_regenerate_cron_secret', 'ks_handle_regenerate_cron_secret' );

function ks_handle_suggestion() {
	if ( ! is_user_logged_in() ) {
		wp_die( 'Brak uprawnień.' );
	}

	// Nonce check
	if ( ! isset( $_POST['ks_suggestion_nonce'] ) || ! wp_verify_nonce( $_POST['ks_suggestion_nonce'], 'ks_send_suggestion' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	// Honeypot anti-spam: field must be empty
	if ( ! empty( $_POST['ks_hp_field'] ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'sugestie', 'sug_status' => 'sent' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	$sug_subject = sanitize_text_field( $_POST['sug_subject'] ?? '' );
	$sug_message = sanitize_textarea_field( $_POST['sug_message'] ?? '' );

	if ( empty( $sug_subject ) || empty( $sug_message ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'sugestie', 'sug_status' => 'error' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	$current_user = wp_get_current_user();
	$from_name    = $current_user->display_name ?: ( $current_user->user_login ?: 'Serwisant' );
	$from_email   = $current_user->user_email;

	$email_subject = '[KiedySerwis.pl] Sugestia: ' . $sug_subject;
	$email_body    = "Nowa sugestia od serwisanta:\n\n"
		. "Nazwa: $from_name\n"
		. "E-mail: $from_email\n\n"
		. "Temat: $sug_subject\n\n"
		. "Treść:\n$sug_message";

	$headers = array(
		'Reply-To: ' . $from_name . ' <' . $from_email . '>',
	);

	$sent = wp_mail( 'biuro@kiedyserwis.pl', $email_subject, $email_body, $headers );

	$status = $sent ? 'sent' : 'error';
	wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'sugestie', 'sug_status' => $status ), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_send_suggestion', 'ks_handle_suggestion' );
function ks_register_settings() {
	register_setting( 'ks_settings_group', 'ks_sms_message_template' );
	register_setting( 'ks_settings_group', 'ks_pwa_name' );
	register_setting( 'ks_settings_group', 'ks_sms_send_hour', array( 'sanitize_callback' => 'absint' ) );
	// SMS gateway settings
	register_setting( 'ks_settings_group', 'ks_sms_provider',   array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'ks_settings_group', 'ks_sg24_email',     array( 'sanitize_callback' => 'sanitize_email' ) );
	register_setting( 'ks_settings_group', 'ks_sg24_password',  array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'ks_settings_group', 'ks_sg24_device_id', array( 'sanitize_callback' => 'absint' ) );
	register_setting( 'ks_settings_group', 'ks_sg24_sim_slot',  array( 'sanitize_callback' => 'absint' ) );
	// Cennik settings
	register_setting( 'ks_settings_group', 'ks_pricing_plans', array( 'sanitize_callback' => 'ks_sanitize_pricing_plans' ) );
}
add_action( 'admin_init', 'ks_register_settings' );

/**
 * Zwraca domyślne dane cennika (4 plany).
 *
 * @return array[]
 */
function ks_get_pricing_defaults() {
	return array(
		array(
			'badge'         => '',
			'period'        => '1 miesiąc',
			'name'          => 'Na chwilę',
			'price'         => '69',
			'price_unit'    => ',00 / mies.',
			'sub'           => '1 konto serwisanta',
			'features'      => "Automatyczne przypomnienia SMS\nBaza urządzeń bez limitu\nKalendarz zleceń\nCyfrowa wizytówka serwisanta",
			'btn_text'      => 'Wybierz plan',
			'btn_url'       => '#zamow',
			'btn_url_panel' => 'https://1koszyk.pl/p/product-30',
		),
		array(
			'badge'         => 'oszczędzasz 20%',
			'period'        => '6 miesięcy',
			'name'          => 'Na dłużej',
			'price'         => '55',
			'price_unit'    => ',00 / mies.',
			'sub'           => '330 zł płatne z góry',
			'features'      => "Automatyczne przypomnienia SMS\nBaza urządzeń bez limitu\nKalendarz zleceń\nCyfrowa wizytówka serwisanta",
			'btn_text'      => 'Wybierz plan',
			'btn_url'       => '#zamow',
			'btn_url_panel' => 'https://1koszyk.pl/p/product-180',
		),
		array(
			'badge'         => 'oszczędzasz 35%',
			'period'        => '1 rok',
			'name'          => 'Na dobre',
			'price'         => '45',
			'price_unit'    => ',00 / mies.',
			'sub'           => '540 zł płatne z góry',
			'features'      => "Automatyczne przypomnienia SMS\nBaza urządzeń bez limitu\nKalendarz zleceń\nCyfrowa wizytówka serwisanta\nProtokoły serwisowe (PDF / e-mail)\nMagazyn części zamiennych",
			'btn_text'      => 'Wybierz plan',
			'btn_url'       => '#zamow',
			'btn_url_panel' => 'https://1koszyk.pl/p/product-365',
		),
		array(
			'badge'         => 'DO 10 SERWISANTÓW',
			'period'        => '1 rok — Multi',
			'name'          => 'Dla Firmy',
			'price'         => '149',
			'price_unit'    => ',00 / mies.',
			'sub'           => '1788 zł płatne z góry',
			'features'      => "Panel managera — zarządzanie zespołem\nPrzypisywanie zadań pracownikom\nWspólna baza urządzeń całej firmy\nDo 10 kont serwisantów\nProtokoły serwisowe (PDF / e-mail)\nMagazyn części zamiennych",
			'btn_text'      => 'Skontaktuj się',
			'btn_url'       => '#zamow',
			'btn_url_panel' => 'https://1koszyk.pl/p/product-firma',
		),
	);
}

/**
 * Zwraca dane 4 planów cennikowych, łącząc zapisane opcje z wartościami domyślnymi.
 *
 * @return array[]
 */
function ks_get_pricing_plans() {
	$saved    = get_option( 'ks_pricing_plans', array() );
	$defaults = ks_get_pricing_defaults();
	if ( empty( $saved ) || ! is_array( $saved ) ) {
		return $defaults;
	}
	$plans = array();
	foreach ( $defaults as $i => $def ) {
		$override = isset( $saved[ $i ] ) && is_array( $saved[ $i ] ) ? $saved[ $i ] : array();
		$plans[]  = array_merge( $def, $override );
	}
	return $plans;
}

/**
 * Sanitizuje dane cennika przed zapisem.
 *
 * @param mixed $input
 * @return array[]
 */
function ks_sanitize_pricing_plans( $input ) {
	if ( ! is_array( $input ) ) {
		return array();
	}
	$sanitized   = array();
	$text_fields = array( 'badge', 'period', 'name', 'price', 'price_unit', 'sub', 'btn_text' );
	foreach ( range( 0, 3 ) as $i ) {
		$plan = isset( $input[ $i ] ) && is_array( $input[ $i ] ) ? $input[ $i ] : array();
		$s    = array();
		foreach ( $text_fields as $field ) {
			$s[ $field ] = isset( $plan[ $field ] ) ? sanitize_text_field( $plan[ $field ] ) : '';
		}
		$s['features']      = isset( $plan['features'] )      ? sanitize_textarea_field( $plan['features'] )  : '';
		$s['btn_url']       = isset( $plan['btn_url'] )       ? esc_url_raw( $plan['btn_url'] )               : '';
		$s['btn_url_panel'] = isset( $plan['btn_url_panel'] ) ? esc_url_raw( $plan['btn_url_panel'] )         : '';
		$sanitized[]        = $s;
	}
	return $sanitized;
}

function ks_add_admin_menu() {
	add_options_page(
		'KiedySerwis Ustawienia',
		'KiedySerwis',
		'manage_options',
		'kiedyserwis-settings',
		'ks_settings_page_html'
	);
}
add_action( 'admin_menu', 'ks_add_admin_menu' );

function ks_settings_page_html() {
	// Handle test SMS submission
	$test_notice = '';
	if ( isset( $_POST['ks_test_sms_nonce'] ) && wp_verify_nonce( $_POST['ks_test_sms_nonce'], 'ks_test_sms' ) && current_user_can( 'manage_options' ) ) {
		$admin_phone = sanitize_text_field( $_POST['ks_test_phone'] ?? '' );
		if ( $admin_phone ) {
			$template = get_option(
				'ks_sms_message_template',
				'Przypomnienie od kiedyserwis.pl: Twoje urządzenie [Nazwa] wymaga serwisu. Firma: [Firma]. Zobacz wizytówkę i umów się: [Link]'
			);
			$test_msg = str_replace(
				array( '[Nazwa]', '[Firma]', '[Link]' ),
				array( 'Urządzenie Testowe', 'Firma Testowa', home_url() ),
				$template
			);
			$ok = ks_send_sms( $admin_phone, $test_msg );
			$test_notice = $ok
				? '<div class="notice notice-success" role="alert"><p><span aria-hidden="true">✅</span> SMS testowy wysłany na <strong>' . esc_html( $admin_phone ) . '</strong>.</p></div>'
				: '<div class="notice notice-error" role="alert"><p><span aria-hidden="true">❌</span> Błąd wysyłki SMS. Sprawdź ustawienia bramki i plik <code>wp-content/ks-logs/' . esc_html( basename( ks_get_log_path() ) ) . '</code>.</p></div>';
		} else {
			$test_notice = '<div class="notice notice-warning" role="alert"><p>Podaj numer telefonu, na który ma być wysłany SMS testowy.</p></div>';
		}
	}

	if ( isset( $_GET['cron_token_regenerated'] ) ) {
		$test_notice .= '<div class="notice notice-success is-dismissible"><p>✅ Token Crona zewnętrznego został zregenerowany. Zaktualizuj URL w panelu Seohost.pl.</p></div>';
	}

	$provider     = get_option( 'ks_sms_provider', 'android' );
	$active_tab   = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'settings';
	$settings_url = admin_url( 'options-general.php?page=kiedyserwis-settings' );
	?>
	<div class="wrap">
		<h1>KiedySerwis Core – Ustawienia</h1>
		<?php echo $test_notice; ?>

		<nav class="nav-tab-wrapper" aria-label="Zakładki ustawień">
			<a href="<?php echo esc_url( $settings_url . '&tab=settings' ); ?>"
			   class="nav-tab <?php echo $active_tab === 'settings' ? 'nav-tab-active' : ''; ?>">
				Ustawienia
			</a>
			<a href="<?php echo esc_url( $settings_url . '&tab=cennik' ); ?>"
			   class="nav-tab <?php echo $active_tab === 'cennik' ? 'nav-tab-active' : ''; ?>">
				Cennik
			</a>
			<a href="<?php echo esc_url( $settings_url . '&tab=sms_queue' ); ?>"
			   class="nav-tab <?php echo $active_tab === 'sms_queue' ? 'nav-tab-active' : ''; ?>">
				Kolejka SMS
			</a>
			<a href="<?php echo esc_url( $settings_url . '&tab=newsletter' ); ?>"
			   class="nav-tab <?php echo $active_tab === 'newsletter' ? 'nav-tab-active' : ''; ?>">
				Newsletter
			</a>
		</nav>

		<?php if ( $active_tab === 'cennik' ) : ?>

		<h2 style="margin-top:20px;">Ustawienia Cennika</h2>
		<p>Tutaj możesz edytować treść i linki wszystkich pakietów wyświetlanych na stronie cennika (shortcode <code>[ks_cennik]</code>) oraz w panelu serwisanta.</p>

		<form method="post" action="options.php">
			<?php settings_fields( 'ks_settings_group' ); ?>
			<?php
			$pricing_plans  = ks_get_pricing_plans();
			$plan_labels    = array(
				'Plan 1 — Na chwilę',
				'Plan 2 — Na dłużej',
				'Plan 3 — Na dobre (wyróżniony)',
				'Plan 4 — Dla Firmy',
			);
			foreach ( $pricing_plans as $i => $plan ) :
			?>
			<h3 style="border-bottom:1px solid #ddd; padding-bottom:8px; margin-top:28px;">
				<?php echo esc_html( $plan_labels[ $i ] ); ?>
			</h3>
			<table class="form-table">
				<tr>
					<th scope="row"><label for="ks_pp_<?php echo $i; ?>_badge">Odznaka (badge)</label></th>
					<td>
						<input type="text"
						       id="ks_pp_<?php echo $i; ?>_badge"
						       name="ks_pricing_plans[<?php echo $i; ?>][badge]"
						       value="<?php echo esc_attr( $plan['badge'] ); ?>"
						       class="regular-text">
						<p class="description">Tekst małej etykietki nad kartą (np. <code>oszczędzasz 20%</code>). Zostaw puste, aby ukryć.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ks_pp_<?php echo $i; ?>_period">Okres / Typ planu</label></th>
					<td>
						<input type="text"
						       id="ks_pp_<?php echo $i; ?>_period"
						       name="ks_pricing_plans[<?php echo $i; ?>][period]"
						       value="<?php echo esc_attr( $plan['period'] ); ?>"
						       class="regular-text">
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ks_pp_<?php echo $i; ?>_name">Nazwa pakietu</label></th>
					<td>
						<input type="text"
						       id="ks_pp_<?php echo $i; ?>_name"
						       name="ks_pricing_plans[<?php echo $i; ?>][name]"
						       value="<?php echo esc_attr( $plan['name'] ); ?>"
						       class="regular-text">
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ks_pp_<?php echo $i; ?>_price">Cena (liczba)</label></th>
					<td>
						<input type="text"
						       id="ks_pp_<?php echo $i; ?>_price"
						       name="ks_pricing_plans[<?php echo $i; ?>][price]"
						       value="<?php echo esc_attr( $plan['price'] ); ?>"
						       class="small-text">
						&nbsp;
						<input type="text"
						       name="ks_pricing_plans[<?php echo $i; ?>][price_unit]"
						       value="<?php echo esc_attr( $plan['price_unit'] ); ?>"
						       class="regular-text"
						       placeholder=",00 / mies."
						       aria-label="Jednostka ceny">
						<p class="description">Cena + jednostka (np. <code>69</code> + <code>,00 / mies.</code>).</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ks_pp_<?php echo $i; ?>_sub">Podpis ceny</label></th>
					<td>
						<input type="text"
						       id="ks_pp_<?php echo $i; ?>_sub"
						       name="ks_pricing_plans[<?php echo $i; ?>][sub]"
						       value="<?php echo esc_attr( $plan['sub'] ); ?>"
						       class="regular-text">
						<p class="description">Tekst pod ceną, np. <code>330 zł płatne z góry</code>.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ks_pp_<?php echo $i; ?>_features">Lista zalet</label></th>
					<td>
						<textarea id="ks_pp_<?php echo $i; ?>_features"
						          name="ks_pricing_plans[<?php echo $i; ?>][features]"
						          rows="6"
						          class="large-text"><?php echo esc_textarea( $plan['features'] ); ?></textarea>
						<p class="description">Jedna pozycja na linię. Każda linia = jeden element listy z checkmarkiem.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ks_pp_<?php echo $i; ?>_btn_text">Tekst przycisku</label></th>
					<td>
						<input type="text"
						       id="ks_pp_<?php echo $i; ?>_btn_text"
						       name="ks_pricing_plans[<?php echo $i; ?>][btn_text]"
						       value="<?php echo esc_attr( $plan['btn_text'] ); ?>"
						       class="regular-text">
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ks_pp_<?php echo $i; ?>_btn_url">Link – strona cennika</label></th>
					<td>
						<input type="url"
						       id="ks_pp_<?php echo $i; ?>_btn_url"
						       name="ks_pricing_plans[<?php echo $i; ?>][btn_url]"
						       value="<?php echo esc_attr( $plan['btn_url'] ); ?>"
						       class="large-text">
						<p class="description">URL przycisku na publicznej stronie cennika (shortcode <code>[ks_cennik]</code>).</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="ks_pp_<?php echo $i; ?>_btn_url_panel">Link – panel serwisanta</label></th>
					<td>
						<input type="url"
						       id="ks_pp_<?php echo $i; ?>_btn_url_panel"
						       name="ks_pricing_plans[<?php echo $i; ?>][btn_url_panel]"
						       value="<?php echo esc_attr( $plan['btn_url_panel'] ); ?>"
						       class="large-text">
						<p class="description">URL przycisku w panelu serwisanta. Parametr z ID użytkownika (<code>?attr1=…</code>) jest dodawany automatycznie.</p>
					</td>
				</tr>
			</table>
			<?php endforeach; ?>

			<?php submit_button( 'Zapisz cennik' ); ?>
		</form>

		<?php elseif ( $active_tab === 'sms_queue' ) : ?>

		<h2 style="margin-top:20px;">Kolejka SMS</h2>
		<?php
		$today        = ks_warsaw_now()->format( 'Y-m-d' );
		$send_hour    = ks_get_sms_send_hour();
		$warsaw_hour  = (int) ks_warsaw_now()->format( 'G' );
		$send_hour_passed = $warsaw_hour >= $send_hour;

		// --- CRON STATUS PANEL ---
		$next_cron_ts    = wp_next_scheduled( 'ks_daily_sms_cron' );
		$cron_disabled   = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
		$force_run_nonce = wp_create_nonce( 'ks_force_run_cron' );

		if ( isset( $_GET['cron_run'] ) ) {
			$sent_c = min( absint( $_GET['sent'] ?? 0 ), 10000 );
			echo '<div class="notice notice-success is-dismissible"><p>✅ Sprawdzenie kolejki ukończone. Wysłano SMS: <strong>' . $sent_c . '</strong>.</p></div>';
		}
		?>
		<div style="background:#f8f8f8; border:1px solid #ddd; border-radius:4px; padding:12px 16px; margin-bottom:16px;">
			<strong>Status Cron:</strong>
			<?php if ( $cron_disabled ) : ?>
				<span style="color:#B45309;">ℹ️ WP-Cron wyłączony – używasz zewnętrznego Crona serwera.</span>
			<?php elseif ( $next_cron_ts ) : ?>
				<?php
				$next_warsaw = new DateTime( '@' . $next_cron_ts );
				$next_warsaw->setTimezone( new DateTimeZone( 'Europe/Warsaw' ) );
				?>
				<span style="color:#166534;">✅ WP-Cron: następne uruchomienie <strong><?php echo esc_html( $next_warsaw->format( 'd.m.Y H:i' ) ); ?></strong></span>
			<?php else : ?>
				<span style="color:#DC2626; font-weight:600;">❌ WP-Cron nie jest zaplanowany! Użyj zewnętrznego Crona lub deaktywuj i aktywuj wtyczkę.</span>
			<?php endif; ?>
			&nbsp;|&nbsp;
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
				<input type="hidden" name="action" value="ks_force_run_cron">
				<input type="hidden" name="ks_nonce" value="<?php echo esc_attr( $force_run_nonce ); ?>">
				<button type="submit" class="button button-primary button-small"
				        onclick="return confirm('Wymusić sprawdzenie kolejki SMS teraz (wyśle dzisiejsze SMSy)?');">
					▶ Wymuś sprawdzenie kolejki teraz
				</button>
			</form>
		</div>

		<p>Urządzenia oczekujące na wysłanie SMS-a z przypomnieniem o serwisie. SMS zostanie wysłany automatycznie o skonfigurowanej godzinie (<strong><?php printf( '%02d:00', $send_hour ); ?></strong>) w dniu uruchomienia przypomnienia.</p>
		<?php

		// Fetch all devices that have a service date, phone and SMS not yet sent
		$queue_args = array(
			'post_type'              => 'ks_urzadzenie',
			'posts_per_page'         => -1,
			'post_status'            => 'publish',
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'ks_data_serwisu',
					'compare' => 'EXISTS',
				),
				array(
					'key'     => 'ks_klient_tel',
					'compare' => 'EXISTS',
				),
				array(
					'relation' => 'OR',
					array(
						'key'     => 'ks_status_sms',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => 'ks_status_sms',
						'value'   => 'Wysłano',
						'compare' => '!=',
					),
				),
				array(
					'key'     => 'ks_is_custom_app',
					'compare' => 'NOT EXISTS',
				),
			),
		);
		$queue_devices = get_posts( $queue_args );

		// Build queue: compute trigger date for each device and keep only upcoming
		$queue_rows = array();
		foreach ( $queue_devices as $qdev ) {
			$last_service = get_post_meta( $qdev->ID, 'ks_data_serwisu', true );
			$interval     = (int) get_post_meta( $qdev->ID, 'ks_interwal', true );
			$days_before  = (int) get_post_meta( $qdev->ID, 'ks_dni_wyprzedzenia', true );
			$phone        = get_post_meta( $qdev->ID, 'ks_klient_tel', true );
			$sms_status   = get_post_meta( $qdev->ID, 'ks_status_sms', true );

			if ( empty( $last_service ) || empty( $interval ) || empty( $phone ) ) {
				continue;
			}

			// Skip devices where SMS notifications are disabled ("Nie wysyłaj").
			if ( $days_before < 0 ) {
				continue;
			}

			$next_service_ts   = strtotime( "+$interval months", strtotime( $last_service ) );
			$next_service_date = wp_date( 'Y-m-d', $next_service_ts );
			$trigger_ts        = strtotime( "-$days_before days", $next_service_ts );
			$trigger_date      = wp_date( 'Y-m-d', $trigger_ts );

			// Include only devices that haven't yet had SMS sent and are in (or approaching) the trigger window
			// i.e. trigger_date >= today (SMS day not yet passed) OR in the upcoming window (trigger_date < today < next_service_date)
			if ( $trigger_date < $today && $today >= $next_service_date ) {
				// Overdue – past both trigger and service date, skip
				continue;
			}

			$send_datetime = $trigger_date . sprintf( ' %02d:00', $send_hour );
			$author_id     = $qdev->post_author;
			$author_name   = get_user_meta( $author_id, 'ks_company_name', true ) ?: get_the_author_meta( 'display_name', $author_id );

			$queue_rows[] = array(
				'id'               => $qdev->ID,
				'name'             => get_the_title( $qdev->ID ),
				'phone'            => $phone,
				'trigger_date'     => $trigger_date,
				'send_datetime'    => $send_datetime,
				'next_service'     => $next_service_date,
				'sms_status'       => $sms_status ?: 'Oczekuje',
				'author'           => $author_name,
				'is_today'         => $trigger_date === $today,
				'is_past_trigger'  => $trigger_date < $today,
			);
		}

		// Sort by trigger date ascending
		usort( $queue_rows, function( $a, $b ) {
			return strcmp( $a['trigger_date'], $b['trigger_date'] );
		} );
		?>

		<?php if ( empty( $queue_rows ) ) : ?>
			<p><em>Brak urządzeń oczekujących na wysłanie SMS-a.</em></p>
		<?php else : ?>
			<?php if ( isset( $_GET['sms_sent'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ SMS wysłany pomyślnie.</p></div>
			<?php elseif ( isset( $_GET['sms_error'] ) ) : ?>
				<div class="notice notice-error is-dismissible"><p>❌ Błąd wysyłki SMS. Sprawdź ustawienia bramki.</p></div>
			<?php endif; ?>
			<p><?php echo count( $queue_rows ); ?> urządzeń w kolejce.</p>
			<table class="widefat striped">
				<thead>
					<tr>
						<th>Urządzenie</th>
						<th>Serwisant</th>
						<th>Numer telefonu</th>
						<th>Data wysłania SMS</th>
						<th>Następny serwis</th>
						<th>Status SMS</th>
						<th>Akcja</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $queue_rows as $row ) : ?>
					<tr<?php echo $row['is_today'] ? ' style="background:#FEF9C3;"' : ( $row['is_past_trigger'] ? ' style="background:#FEF2F2;"' : '' ); ?>>
						<td>
							<a href="<?php echo esc_url( get_edit_post_link( $row['id'] ) ); ?>">
								<?php echo esc_html( $row['name'] ); ?>
							</a>
						</td>
						<td><?php echo esc_html( $row['author'] ); ?></td>
						<td><?php echo esc_html( $row['phone'] ); ?></td>
						<td>
							<?php echo esc_html( $row['send_datetime'] ); ?>
							<?php if ( $row['is_today'] ) : ?>
								<span style="color:#B45309; font-weight:600;"> — dziś!</span>
							<?php elseif ( $row['is_past_trigger'] ) : ?>
								<span style="color:#DC2626; font-weight:600;"> — termin minął</span>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( $row['next_service'] ); ?></td>
						<td><?php echo esc_html( $row['sms_status'] ); ?></td>
						<td>
							<?php if ( $row['is_past_trigger'] || ( $row['is_today'] && $send_hour_passed ) ) : ?>
							<?php
							$admin_sms_nonce = wp_create_nonce( 'ks_admin_queue_send_sms_' . $row['id'] );
							$admin_sms_url   = admin_url( 'admin-post.php?action=ks_admin_queue_send_sms&ks_dev_id=' . $row['id'] . '&ks_nonce=' . $admin_sms_nonce );
							?>
							<a href="<?php echo esc_url( $admin_sms_url ); ?>"
							   class="button button-secondary"
							   onclick="return confirm('Czy na pewno chcesz wysłać SMS do tego urządzenia?');">
								Wyślij SMS
							</a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description" style="margin-top:10px;">
				Wiersze <span style="background:#FEF9C3; padding:1px 4px;">żółte</span> = SMS wysyłany dzisiaj o <?php printf( '%02d:00', $send_hour ); ?>.
				Wiersze <span style="background:#FEF2F2; padding:1px 4px;">czerwone</span> = trigger minął bez wysłania SMS (np. cron nie działał).
				Przycisk <strong>Wyślij SMS</strong> pojawia się dla wierszy czerwonych oraz żółtych gdy godzina wysyłki już minęła.
			</p>
		<?php endif; ?>

		<?php elseif ( $active_tab === 'newsletter' ) : ?>

		<h2 style="margin-top:20px;">Newsletter – Lista subskrybentów</h2>
		<p>Poniżej znajdują się adresy e-mail użytkowników, którzy podczas rejestracji wyrazili zgodę na otrzymywanie newslettera KiedySerwis.pl.</p>
		<?php
		$subscribers = get_option( 'ks_newsletter_subscribers', array() );
		if ( empty( $subscribers ) ) :
		?>
			<p><em>Brak subskrybentów – nikt jeszcze nie wyraził zgody na newsletter podczas rejestracji.</em></p>
		<?php else : ?>
			<p><strong>Liczba subskrybentów:</strong> <?php echo count( $subscribers ); ?></p>
			<table class="widefat fixed striped" style="max-width:600px;">
				<thead>
					<tr>
						<th scope="col">#</th>
						<th scope="col">Adres e-mail</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $subscribers as $i => $sub_email ) : ?>
					<tr>
						<td><?php echo (int) $i + 1; ?></td>
						<td><?php echo esc_html( $sub_email ); ?></td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p style="margin-top:12px;">
				<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'kiedyserwis-settings', 'tab' => 'newsletter', 'ks_export_newsletter' => '1' ), admin_url( 'options-general.php' ) ) ); ?>" class="button button-secondary">
					⬇ Pobierz jako CSV
				</a>
			</p>
		<?php endif; ?>

		<?php else : /* tab = settings */ ?>

		<form method="post" action="options.php">
			<?php
			settings_fields( 'ks_settings_group' );
			do_settings_sections( 'ks_settings_group' );
			?>
			<h2 class="title">Ogólne</h2>
			<table class="form-table">
				<tr>
					<th>Szablon SMS</th>
					<td>
						<textarea name="ks_sms_message_template" rows="3" class="large-text"><?php echo esc_textarea( get_option( 'ks_sms_message_template', 'Przypomnienie od kiedyserwis.pl: Twoje urządzenie [Nazwa] wymaga serwisu. Firma: [Firma]. Zobacz wizytówkę i umów się: [Link]' ) ); ?></textarea>
						<p class="description">Dostępne zmienne: <code>[Nazwa]</code>, <code>[Firma]</code>, <code>[Link]</code>.</p>
					</td>
				</tr>
				<tr>
					<th>Nazwa PWA</th>
					<td><input type="text" name="ks_pwa_name" value="<?php echo esc_attr( get_option( 'ks_pwa_name', 'KiedySerwis Dashboard' ) ); ?>" class="regular-text"></td>
				</tr>
				<tr>
					<th><label for="ks_sms_send_hour">Godzina wysyłki SMS</label></th>
					<td>
						<select name="ks_sms_send_hour" id="ks_sms_send_hour">
							<?php
							$saved_hour = ks_get_sms_send_hour();
							for ( $h = 0; $h <= 23; $h++ ) {
								printf(
									'<option value="%1$d"%2$s>%3$s</option>',
									$h,
									selected( $saved_hour, $h, false ),
									sprintf( '%02d:00', $h )
								);
							}
							?>
						</select>
						<p class="description">Automatyczne SMS-y z przypomnieniami będą wysyłane nie wcześniej niż o wybranej godzinie. Zalecana godzina: 10:00–15:00.</p>
					</td>
				</tr>
			</table>

			<h2 class="title">Konfiguracja bramki SMS</h2>

			<div style="background:#eaf4fb; border-left:4px solid #2196f3; padding:12px 16px; margin-bottom:16px; border-radius:0 4px 4px 0;">
				<strong>📱 Wymagany plan smsgateway24.com: <span style="color:#1565c0;">Startup</span> — API Key nie jest potrzebny</strong><br><br>
				<strong>Jak działa logowanie?</strong> Wtyczka loguje się do smsgateway24.com
				<strong>jak zwykły użytkownik</strong> — podajesz swój e-mail i hasło do konta, a serwis
				zwraca jednorazowy token sesji. Ten token służy następnie do kolejkowania SMS na Twoim
				podłączonym telefonie Android. <strong>Nie ma tu żadnego „API Key"</strong> — pola
				e-mail i hasło to Twoje dane logowania do strony smsgateway24.com, nic więcej.<br><br>
				<strong>Jaki plan jest potrzebny?</strong> Plan <strong>Startup</strong> (jedno urządzenie Android)
				w zupełności wystarczy. SMS fizycznie wychodzi z karty SIM Twojego telefonu.<br>
				Plan <strong>Profi</strong> (<em>„API requests"</em>) to zupełnie inny produkt — wysyłka SMS
				<em>bez własnego telefonu</em>, przez serwery smsgateway24.com. Wtyczka tego trybu
				<strong>nie</strong> używa.
			</div>

			<table class="form-table">
				<tr>
					<th><label for="ks_sms_provider">Dostawca SMS</label></th>
					<td>
						<select name="ks_sms_provider" id="ks_sms_provider">
							<option value="android" <?php selected( $provider, 'android' ); ?>>Android Gateway (smsgateway24.com)</option>
							<option value="smsapi" <?php selected( $provider, 'smsapi' ); ?>>SMSAPI.pl (wkrótce)</option>
						</select>
					</td>
				</tr>
				<tr class="ks-sg24-row">
					<th><label for="ks_sg24_email">E-mail (SmsGateway24)</label></th>
					<td>
						<input type="email" name="ks_sg24_email" id="ks_sg24_email"
							value="<?php echo esc_attr( get_option( 'ks_sg24_email', '' ) ); ?>"
							class="regular-text" autocomplete="username">
						<p class="description">Login (adres e-mail) do konta na <a href="https://smsgateway24.com" target="_blank">smsgateway24.com</a>.</p>
					</td>
				</tr>
				<tr class="ks-sg24-row">
					<th><label for="ks_sg24_password">Hasło (SmsGateway24)</label></th>
					<td>
						<input type="password" name="ks_sg24_password" id="ks_sg24_password"
							value="<?php echo esc_attr( get_option( 'ks_sg24_password', '' ) ); ?>"
							class="regular-text" autocomplete="current-password">
						<p class="description">Hasło do konta na smsgateway24.com. Używane do jednorazowego pobrania tokena przed każdą wysyłką SMS.</p>
					</td>
				</tr>
				<tr class="ks-sg24-row">
					<th><label for="ks_sg24_device_id">ID urządzenia</label></th>
					<td>
						<input type="number" name="ks_sg24_device_id" id="ks_sg24_device_id"
							value="<?php echo esc_attr( get_option( 'ks_sg24_device_id', '' ) ); ?>"
							class="small-text" min="1">
						<p class="description">Device ID z panelu smsgateway24.com &rarr; Devices.</p>
					</td>
				</tr>
				<tr class="ks-sg24-row">
					<th><label for="ks_sg24_sim_slot">Slot karty SIM</label></th>
					<td>
						<input type="number" name="ks_sg24_sim_slot" id="ks_sg24_sim_slot"
							value="<?php echo esc_attr( get_option( 'ks_sg24_sim_slot', '0' ) ); ?>"
							class="small-text" min="0" max="1">
						<p class="description">0 = SIM 1, 1 = SIM 2 (zgodnie z API smsgateway24.com).</p>
					</td>
				</tr>
			</table>

			<?php submit_button( 'Zapisz ustawienia' ); ?>
		</form>

		<hr>
		<h2 class="title">Cron serwera (zewnętrzny)</h2>
		<p>Używasz zewnętrznego Crona (np. Seohost.pl)? Wklej poniższe polecenie jako zadanie cykliczne wywoływane <strong>co minutę</strong>. System samodzielnie sprawdza godzinę i wysyła SMS-y dopiero od skonfigurowanej godziny wysyłki.</p>
		<?php
		$ext_cron_url     = ks_get_external_cron_url();
		$ext_cron_curl    = 'curl --silent -X POST ' . escapeshellarg( $ext_cron_url ) . ' > /dev/null 2>&1';
		$regen_cron_nonce = wp_create_nonce( 'ks_regenerate_cron_secret' );
		?>
		<div style="background:#f0f6fc; border:1px solid #b0c4de; border-radius:4px; padding:14px 16px; margin-bottom:16px;">
			<label for="ks_cron_curl_field" style="font-weight:600; display:block; margin-bottom:6px;">Polecenie curl (zalecane – metoda POST):</label>
			<div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
				<input type="text" id="ks_cron_curl_field"
				       aria-label="Polecenie curl dla zewnętrznego Crona SMS"
				       value="<?php echo esc_attr( $ext_cron_curl ); ?>"
				       readonly
				       style="width:100%; max-width:680px; font-family:monospace; font-size:12px;"
				       onclick="this.select();">
				<button type="button" class="button button-secondary"
				        onclick="var btn=this; navigator.clipboard.writeText(document.getElementById('ks_cron_curl_field').value).then(function(){btn.textContent='✅ Skopiowano!';}).catch(function(){btn.textContent='❌ Błąd kopiowania – zaznacz i skopiuj ręcznie.';});">
					📋 Kopiuj
				</button>
			</div>
			<p class="description" style="margin-top:8px;">
				⚠️ <strong>Ważne – używaj metody POST, nie GET.</strong>
				Serwery hostingowe (LiteSpeed, Nginx, Varnish) zapisują w pamięci podręcznej odpowiedzi na żądania GET.
				Każde kolejne wywołanie tego samego URL metodą GET zwraca zapisaną odpowiedź bez uruchamiania PHP — SMS-y nie są wtedy wysyłane, a w logu <code>wp-content/ks-logs/<?php echo esc_html( basename( ks_get_log_path() ) ); ?></code> nie pojawiają się żadne nowe wpisy.
				Metoda POST nigdy nie jest buforowana przez serwer.
			</p>
			<label for="ks_cron_url_field" style="font-weight:600; display:block; margin-top:12px; margin-bottom:4px;">URL (tylko do wglądu – używaj polecenia curl powyżej):</label>
			<input type="text" id="ks_cron_url_field"
			       aria-label="URL zewnętrznego Crona SMS"
			       value="<?php echo esc_attr( $ext_cron_url ); ?>"
			       readonly
			       style="width:100%; max-width:680px; font-family:monospace; font-size:12px;"
			       onclick="this.select();">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px;">
				<input type="hidden" name="action" value="ks_regenerate_cron_secret">
				<input type="hidden" name="ks_nonce" value="<?php echo esc_attr( $regen_cron_nonce ); ?>">
				<button type="submit" class="button button-secondary button-small"
				        onclick="return confirm('Regenerować token? Aktualny URL Crona przestanie działać – będziesz musiał go zaktualizować.');">
					🔄 Regeneruj token
				</button>
			</form>
		</div>

		<hr>
		<h2 class="title">Webhook płatności (1koszyk.pl)</h2>
		<p>
			Skonfiguruj poniższy URL i sekret w panelu 1koszyk.pl jako webhook potwierdzający płatność.
			Sekret musi być wysyłany przez 1koszyk.pl w nagłówku HTTP <code>X-KS-Webhook-Secret</code>
			przy każdym wywołaniu webhooka.
		</p>
		<?php
		$webhook_url    = rest_url( 'ks/v1/payment-webhook' );
		$webhook_secret = ks_get_webhook_secret();
		?>
		<div style="background:#f0f6fc; border:1px solid #b0c4de; border-radius:4px; padding:14px 16px; margin-bottom:16px;">
			<label style="font-weight:600; display:block; margin-bottom:6px;">URL Webhooka:</label>
			<div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin-bottom:12px;">
				<input type="text"
				       aria-label="URL webhooka płatności"
				       value="<?php echo esc_attr( $webhook_url ); ?>"
				       readonly
				       style="width:100%; max-width:680px; font-family:monospace; font-size:12px;"
				       onclick="this.select();">
			</div>
			<label style="font-weight:600; display:block; margin-bottom:6px;">Sekret webhooka (X-KS-Webhook-Secret):</label>
			<div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
				<input type="text"
				       id="ks_webhook_secret_field"
				       aria-label="Sekret webhooka płatności"
				       value="<?php echo esc_attr( $webhook_secret ); ?>"
				       readonly
				       style="width:100%; max-width:680px; font-family:monospace; font-size:12px;"
				       onclick="this.select();">
				<button type="button" class="button button-secondary"
				        onclick="var btn=this; navigator.clipboard.writeText(document.getElementById('ks_webhook_secret_field').value).then(function(){btn.textContent='✅ Skopiowano!';}).catch(function(){btn.textContent='❌ Skopiuj ręcznie.';});">
					📋 Kopiuj sekret
				</button>
			</div>
			<p class="description" style="margin-top:8px;">⚠️ Traktuj ten sekret jak hasło – nie udostępniaj go publicznie. Webhook bez poprawnego sekretu zwróci błąd 401.</p>
		</div>

		<hr>
		<h2 class="title">Wyślij SMS testowy</h2>
		<p>Wyślij próbną wiadomość używając powyższego szablonu i skonfigurowanej bramki.</p>
		<form method="post">
			<?php wp_nonce_field( 'ks_test_sms', 'ks_test_sms_nonce' ); ?>
			<table class="form-table">
				<tr>
					<th><label for="ks_test_phone">Numer telefonu</label></th>
					<td>
						<input type="tel" name="ks_test_phone" id="ks_test_phone"
							value=""
							class="regular-text" placeholder="+48500600700">
						<p class="description">Numer, na który zostanie wysłany SMS testowy.</p>
					</td>
				</tr>
			</table>
			<?php submit_button( 'Wyślij SMS testowy', 'secondary', 'ks_send_test_sms' ); ?>
		</form>

		<?php endif; ?>

	</div>
	<script>
	(function(){
		var sel = document.getElementById('ks_sms_provider');
		var rows = document.querySelectorAll('.ks-sg24-row');
		function toggle() {
			var show = sel.value === 'android';
			rows.forEach(function(r){ r.style.display = show ? '' : 'none'; });
		}
		if (sel) { sel.addEventListener('change', toggle); toggle(); }
	})();
	</script>
	<?php
}

/**
 * SEO & URL Rewriting for Business Cards
 */

function ks_custom_author_base() {
    global $wp_rewrite;
    $wp_rewrite->author_base = 'serwisant';
}
add_action('init', 'ks_custom_author_base');

function ks_add_custom_rewrite_rules() {
    add_rewrite_rule(
        '^serwisant/([^/]+)/?$',
        'index.php?ks_company_slug=$matches[1]',
        'top'
    );
}
add_action('init', 'ks_add_custom_rewrite_rules');

function ks_register_query_vars($vars) {
    $vars[] = 'ks_company_slug';
    return $vars;
}
add_filter('query_vars', 'ks_register_query_vars');

function ks_custom_template_loader($template) {
    $slug = get_query_var('ks_company_slug');
    if ($slug) {
        return plugin_dir_path(__FILE__) . 'templates/author-card.php';
    }
    return $template;
}
add_filter('template_include', 'ks_custom_template_loader');


/**
 * Custom Auth Flow Handling
 */

// 1. Handle Registration (Transient-based to avoid unverified users in DB)
function ks_handle_registration() {
	if ( ! isset( $_POST['ks_reg_nonce'] ) || ! wp_verify_nonce( $_POST['ks_reg_nonce'], 'ks_user_registration' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	// Wymagana zgoda na Regulamin i Politykę Prywatności.
	if ( empty( $_POST['ks_terms_consent'] ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_action' => 'register', 'reg_error' => 'no_terms' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	$email   = sanitize_email( $_POST['user_email'] );
	$company = sanitize_text_field( $_POST['user_company_name'] );
	$phone   = sanitize_text_field( $_POST['user_company_phone'] ?? '' );
	$newsletter = ! empty( $_POST['ks_newsletter_consent'] );

	if ( ! is_email( $email ) || empty( $company ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_action' => 'register', 'reg_error' => 'invalid_data' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	if ( email_exists( $email ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_action' => 'register', 'reg_error' => 'email_exists' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	// Jeśli użytkownik wyraził zgodę na newsletter, zapisz e-mail w opcji.
	if ( $newsletter ) {
		$subscribers = get_option( 'ks_newsletter_subscribers', array() );
		if ( ! in_array( $email, $subscribers, true ) ) {
			$subscribers[] = $email;
			update_option( 'ks_newsletter_subscribers', $subscribers );
		}
	}

	$activation_key = wp_generate_password( 30, false );
	$reg_data = array(
		'email'              => $email,
		'company'            => $company,
		'phone'              => $phone,
		'referral_code'      => sanitize_text_field( $_POST['ks_referral_code'] ?? '' ),
		'newsletter_consent' => $newsletter,
	);

	// Store data in transient for 48 hours
	set_transient( 'ks_reg_' . $activation_key, $reg_data, 48 * HOUR_IN_SECONDS );

	// Send Email
	$activation_link = add_query_arg( array(
		'ks_action' => 'verify',
		'ks_key'    => $activation_key
	), home_url( '/panel-serwisanta/' ) );

	$subject = 'Witaj w KiedySerwis! Potwierdź swój e-mail';
	$message = "Witaj!\n\nKliknij w poniższy link, aby potwierdzić swój adres e-mail i ustawić hasło do panelu Twojej firmy ($company):\n\n$activation_link\n\nPozdrawiamy,\nZespół KiedySerwis.pl";
	$headers = array( 'From: KiedySerwis.pl <biuro@kiedyserwis.pl>' );

	wp_mail( $email, $subject, $message, $headers );

	wp_safe_redirect( add_query_arg( 'reg_status', 'check_email', home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_nopriv_ks_register', 'ks_handle_registration' );

/**
 * Newsletter CSV export – triggered by admin visiting the newsletter tab with ks_export_newsletter=1.
 */
add_action( 'admin_init', function () {
	if (
		! isset( $_GET['ks_export_newsletter'] ) ||
		! current_user_can( 'manage_options' ) ||
		! isset( $_GET['page'] ) ||
		$_GET['page'] !== 'kiedyserwis-settings'
	) {
		return;
	}

	$subscribers = get_option( 'ks_newsletter_subscribers', array() );

	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="ks-newsletter-subscribers-' . date( 'Y-m-d' ) . '.csv"' );
	header( 'Pragma: no-cache' );
	header( 'Expires: 0' );

	$output = fopen( 'php://output', 'w' );
	fprintf( $output, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) ); // UTF-8 BOM
	fputcsv( $output, array( 'Lp.', 'E-mail' ) );
	foreach ( $subscribers as $i => $email ) {
		fputcsv( $output, array( $i + 1, $email ) );
	}
	fclose( $output );
	exit;
} );

// 2. Handle Login
function ks_handle_login() {
	if ( ! isset( $_POST['ks_login_nonce'] ) || ! wp_verify_nonce( $_POST['ks_login_nonce'], 'ks_user_login' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$username = sanitize_text_field( $_POST['log'] );
	$user_obj = get_user_by( 'login', $username );
	if ( ! $user_obj ) {
		$user_obj = get_user_by( 'email', $username );
	}

	if ( $user_obj ) {
		$status = get_user_meta( $user_obj->ID, 'ks_account_status', true );
		if ( $status === 'pending' ) {
			wp_safe_redirect( add_query_arg( 'login_error', 'pending', home_url( '/panel-serwisanta/' ) ) );
			exit;
		}
	}

	$creds = array(
		'user_login'    => $username,
		'user_password' => $_POST['pwd'],
		'remember'      => isset( $_POST['rememberme'] )
	);

	$user = wp_signon( $creds, false );

	if ( is_wp_error( $user ) ) {
		wp_safe_redirect( add_query_arg( 'login_error', 'failed', home_url( '/panel-serwisanta/' ) ) );
	} else {
		wp_safe_redirect( home_url( '/panel-serwisanta/' ) );
	}
	exit;
}
add_action( 'admin_post_nopriv_ks_login', 'ks_handle_login' );

// 3. Handle Password Setting / Activation (Creation of User)
function ks_handle_activation() {
	if ( ! isset( $_POST['ks_activation_nonce'] ) || ! wp_verify_nonce( $_POST['ks_activation_nonce'], 'ks_set_password' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$key   = sanitize_text_field( $_POST['activation_key'] );
	$pass1 = $_POST['pass1'];
	$pass2 = $_POST['pass2'];

	$reg_data = get_transient( 'ks_reg_' . $key );

	if ( ! $reg_data ) {
		wp_die( 'Link aktywacyjny wygasł lub jest nieprawidłowy.' );
	}

	if ( $pass1 !== $pass2 || empty( $pass1 ) ) {
		wp_safe_redirect( add_query_arg( array(
			'ks_action' => 'verify',
			'ks_key'    => $key,
			'error'     => 'mismatch'
		), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	// Create User Now
	$user_id = wp_create_user( $reg_data['email'], $pass1, $reg_data['email'] );

	if ( ! is_wp_error( $user_id ) ) {
		$user = new WP_User( $user_id );
		$user->set_role( 'serwisant' );
		update_user_meta( $user_id, 'nickname', $reg_data['company'] );
		wp_update_user( array( 'ID' => $user_id, 'display_name' => $reg_data['company'] ) );
		update_user_meta( $user_id, 'ks_user_verified', 'true' );
		update_user_meta( $user_id, 'ks_account_status', 'active' );
		// Save company phone collected during registration so the business card
		// is populated immediately without requiring the user to fill in the profile.
		if ( ! empty( $reg_data['phone'] ) ) {
			update_user_meta( $user_id, 'ks_company_phone', sanitize_text_field( $reg_data['phone'] ) );
		}
		update_user_meta( $user_id, 'ks_company_name', sanitize_text_field( $reg_data['company'] ) );

		// Auto-generate a unique referral code for the new user.
		ks_get_or_create_referral_code( $user_id );

		// Save newsletter consent (user meta for audit trail).
		if ( ! empty( $reg_data['newsletter_consent'] ) ) {
			update_user_meta( $user_id, 'ks_newsletter_consent', '1' );
		}

		// Link referral if a valid code was submitted during registration.
		if ( ! empty( $reg_data['referral_code'] ) ) {
			$referrer_users = get_users( array(
				'meta_key'   => 'ks_referral_code',
				'meta_value' => sanitize_text_field( $reg_data['referral_code'] ),
				'fields'     => 'ids',
				'number'     => 1,
			) );
			if ( ! empty( $referrer_users ) && (int) $referrer_users[0] !== $user_id ) {
				update_user_meta( $user_id, 'ks_referred_by', (int) $referrer_users[0] );
				// Reward the newly registered user with a 14-day premium trial.
				update_user_meta( $user_id, 'ks_plan_status', 'premium14' );
				update_user_meta( $user_id, 'ks_plan_expiry', time() + 14 * DAY_IN_SECONDS );
			}
		}

		delete_transient( 'ks_reg_' . $key );

		wp_safe_redirect( add_query_arg( 'reg_status', 'activated', home_url( '/panel-serwisanta/' ) ) );
	} else {
		wp_die( 'Błąd podczas tworzenia użytkownika.' );
	}
	exit;
}
add_action( 'admin_post_nopriv_ks_activate', 'ks_handle_activation' );

// 4. Cleanup Pending Users (Bots protection)
function ks_cleanup_pending_users() {
	$args = array(
		'meta_key'     => 'ks_account_status',
		'meta_value'   => 'pending',
		'date_query'   => array(
			array(
				'before' => '48 hours ago',
			),
		),
		'fields'       => 'ID',
	);

	$pending_users = get_users( $args );

	foreach ( $pending_users as $user_id ) {
		wp_delete_user( $user_id );
	}
}
add_action( 'wp_scheduled_delete', 'ks_cleanup_pending_users' );

/**
 * Frontend Dashboard Shortcode
 */
function ks_dashboard_shortcode() {
	if ( ! is_user_logged_in() ) {
		ob_start();
		include plugin_dir_path( __FILE__ ) . 'templates/auth-forms.php';
		return ob_get_clean();
	}

	if ( ! current_user_can( 'edit_posts' ) ) {
		return '<p>Brak uprawnień technika.</p>';
	}

	// Prevent ALL page caching for the dashboard (browser + server-side plugins).
	// This ensures device/calendar counts are always fresh after any operation.
	if ( ! headers_sent() ) {
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		header( 'Pragma: no-cache' );
		header( 'Expires: Sat, 26 Jul 1997 05:00:00 GMT' );
	}
	// LiteSpeed Cache: mark this response as non-cacheable and private.
	do_action( 'litespeed_control_set_nocache', 'ks-dashboard' );
	do_action( 'litespeed_control_set_private', 'ks-dashboard' );
	// WP Super Cache / W3TC / WP Rocket: constant recognised by most cache plugins.
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}

	ob_start();
	include plugin_dir_path( __FILE__ ) . 'templates/dashboard-view.php';
	return ob_get_clean();
}
add_shortcode( 'ks_dashboard', 'ks_dashboard_shortcode' );

/**
 * Shortcode [ks_cennik] – renderuje responsywny cennik 4-kolumnowy.
 *
 * @return string HTML cennika.
 */
function ks_cennik_shortcode() {
	ob_start();
	include plugin_dir_path( __FILE__ ) . 'templates/cennik-shortcode.php';
	return ob_get_clean();
}
add_shortcode( 'ks_cennik', 'ks_cennik_shortcode' );

/**
 * PWA & Assets Integration
 */

// Enqueue modern UI assets
function ks_enqueue_frontend_assets() {
	// Google Fonts: Inter
	wp_enqueue_style( 'ks-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', array(), null );

	// Lucide Icons
	wp_enqueue_script( 'ks-lucide', 'https://unpkg.com/lucide@latest', array(), null, true );
	wp_add_inline_script( 'ks-lucide', 'lucide.createIcons();' );
}
add_action( 'wp_enqueue_scripts', 'ks_enqueue_frontend_assets' );

// Add manifest to head
function ks_pwa_manifest_link() {
	echo '<link rel="manifest" href="' . plugin_dir_url( __FILE__ ) . 'assets/manifest.json">';
	echo '<meta name="theme-color" content="#4F46E5">'; // Updated to Indigo
	echo '<link rel="apple-touch-icon" href="' . plugin_dir_url( __FILE__ ) . 'assets/icon-192.png">';
}
add_action( 'wp_head', 'ks_pwa_manifest_link' );


// Service Worker registration intentionally disabled – it triggered browser
// "Private Network Access" permission prompts which confused technicians.

/**
 * Author Archive Template (Digital Business Card)
 */
function ks_author_card_template( $template ) {
	if ( is_author() ) {
		$author = get_queried_object();
		if ( isset($author->roles) && in_array('serwisant', $author->roles) ) {
			$new_template = plugin_dir_path( __FILE__ ) . 'templates/author-card.php';
			if ( file_exists( $new_template ) ) {
				return $new_template;
			}
		}
	}
	return $template;
}
add_filter( 'template_include', 'ks_author_card_template' );

/**
 * Nextend Social Login Integration (Future Proofing)
 */
add_action('nsl_register_new_user', function($user_id, $provider) {
    update_user_meta($user_id, 'ks_account_status', 'active');
    update_user_meta($user_id, 'ks_user_verified', 'true');
    ks_get_or_create_referral_code($user_id);
}, 10, 2);

/**
 * ============================================================
 * MODULE: SYSTEM POLECEŃ (REFERRAL)
 * ============================================================
 */

/**
 * Generate a unique 5-character referral code (lowercase letters + digits).
 *
 * @return string
 */
function ks_generate_referral_code() {
	$chars     = 'abcdefghijklmnopqrstuvwxyz0123456789';
	$chars_len = strlen( $chars );
	do {
		$code = '';
		for ( $i = 0; $i < 5; $i++ ) {
			$code .= $chars[ wp_rand( 0, $chars_len - 1 ) ];
		}
		$existing = get_users( array(
			'meta_key'   => 'ks_referral_code',
			'meta_value' => $code,
			'fields'     => 'ids',
			'number'     => 1,
		) );
	} while ( ! empty( $existing ) );
	return $code;
}

/**
 * Get existing referral code for a user, or generate and store a new one.
 *
 * @param int $user_id
 * @return string
 */
function ks_get_or_create_referral_code( $user_id ) {
	$code = get_user_meta( $user_id, 'ks_referral_code', true );
	if ( ! $code ) {
		$code = ks_generate_referral_code();
		update_user_meta( $user_id, 'ks_referral_code', $code );
	}
	return $code;
}

/**
 * Award 30 bonus days to the referrer when a referred user upgrades to premium/multi.
 * Only rewards once per referred user (guarded by ks_referral_rewarded flag).
 *
 * Special cases for multi-account (Manager Serwisu):
 *   - If the referrer is a service_worker, the bonus is credited to their parent
 *     service_manager (Manager Serwisu) instead, preserving the multi plan status.
 *   - If the credited account already has plan_status = 'multi', the multi status
 *     is preserved and only the expiry is extended (never downgraded to 'premium').
 *
 * @param int $referred_user_id  The user who just upgraded.
 */
function ks_award_referral_bonus( $referred_user_id ) {
	$referrer_id = (int) get_user_meta( $referred_user_id, 'ks_referred_by', true );
	if ( ! $referrer_id || ! get_userdata( $referrer_id ) ) {
		return;
	}

	// Prevent double-crediting on subsequent renewals.
	if ( get_user_meta( $referred_user_id, 'ks_referral_rewarded', true ) ) {
		return;
	}
	update_user_meta( $referred_user_id, 'ks_referral_rewarded', '1' );

	// If the referrer is a service_worker, redirect the bonus to their parent manager.
	$referrer_user = get_userdata( $referrer_id );
	if ( $referrer_user && in_array( 'service_worker', (array) $referrer_user->roles, true ) ) {
		$parent_manager_id = (int) get_user_meta( $referrer_id, '_parent_manager_id', true );
		if ( $parent_manager_id && get_userdata( $parent_manager_id ) ) {
			$referrer_id = $parent_manager_id;
		}
	}

	$bonus_days     = 30;
	$current_expiry = (int) get_user_meta( $referrer_id, 'ks_plan_expiry', true );
	$current_status = get_user_meta( $referrer_id, 'ks_plan_status', true ) ?: 'free';

	// For free (or expired) referrers, start premium from now.
	$base_time  = ( $current_expiry > time() ) ? $current_expiry : time();
	$new_expiry = $base_time + ( $bonus_days * DAY_IN_SECONDS );

	// Preserve 'multi' status – never downgrade a Manager Serwisu to 'premium'.
	$new_status = ( $current_status === 'multi' ) ? 'multi' : 'premium';

	update_user_meta( $referrer_id, 'ks_plan_status', $new_status );
	update_user_meta( $referrer_id, 'ks_plan_expiry', $new_expiry );

	// Accumulate total bonus days for display in "Polecaj, zyskuj".
	$prev_bonus = (int) get_user_meta( $referrer_id, 'ks_referral_bonus_days', true );
	update_user_meta( $referrer_id, 'ks_referral_bonus_days', $prev_bonus + $bonus_days );

	ks_purge_user_cache( $referrer_id );

	ks_log( "[KiedySerwis] Referral reward: {$bonus_days} days added to user {$referrer_id} (status: {$new_status}) for referring user {$referred_user_id}." );
}

/**
 * Plan & Monetization Logic Foundation ("Twój Plan")
 */

function ks_get_plan_data( $user_id ) {
	// service_worker inherits plan from their parent manager.
	$user = get_userdata( $user_id );
	if ( $user && in_array( 'service_worker', (array) $user->roles, true ) ) {
		$manager_id = (int) get_user_meta( $user_id, '_parent_manager_id', true );
		if ( $manager_id ) {
			return ks_get_plan_data( $manager_id );
		}
	}

	$status = get_user_meta( $user_id, 'ks_plan_status', true ) ?: 'free';
	$expiry = (int) get_user_meta( $user_id, 'ks_plan_expiry', true ) ?: 0;
	$limit  = (int) get_user_meta( $user_id, 'ks_free_limit', true ) ?: 10;

	// Auto-expire: downgrade to free when premium subscription has lapsed
	if ( in_array( $status, array( 'premium', 'premium14' ), true ) && $expiry > 0 && $expiry < time() ) {
		update_user_meta( $user_id, 'ks_plan_status', 'free' );
		$status = 'free';
	}

	return array(
		'status' => $status,
		'expiry' => $expiry,
		'limit'  => $limit,
	);
}

function ks_is_premium_active( $user_id ) {
	$data = ks_get_plan_data( $user_id );
	if ( in_array( $data['status'], array( 'premium', 'premium14', 'multi' ), true ) && $data['expiry'] > time() ) {
		return true;
	}
	return false;
}

function ks_can_add_device( $user_id ) {
	// 1. If Premium is active - unlimited
	if ( ks_is_premium_active( $user_id ) ) {
		return true;
	}

	// 2. Free plan (or auto-downgraded expired premium): check device count against limit
	$data = ks_get_plan_data( $user_id );
	$count_query = new WP_Query( array(
		'post_type'              => 'ks_urzadzenie',
		'author'                 => $user_id,
		'post_status'            => 'publish',
		'posts_per_page'         => 1,       // We only need the count, not the data
		'fields'                 => 'ids',
		'no_found_rows'          => false,   // Must be false to get found_posts
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
		'meta_query'             => array(
			array(
				'key'     => 'ks_is_custom_app',
				'compare' => 'NOT EXISTS',
			),
		),
	) );

	return $count_query->found_posts < $data['limit'];
}

function ks_can_access_feature( $user_id, $feature_id ) {
	// Future-proofing: By default, everything is available to Premium users
	return ks_is_premium_active( $user_id );
}

/**
 * Returns the maximum number of SMS messages a free-plan user may send in total.
 * Matches the device limit so every device gets one reminder before the cap is hit.
 */
function ks_get_free_sms_limit() {
	return 10;
}

/**
 * Returns the total number of SMS messages sent for a given user (all-time).
 *
 * @param int $user_id
 * @return int
 */
function ks_get_user_sms_sent_count( $user_id ) {
	return (int) get_user_meta( $user_id, 'ks_sms_sent_total', true );
}

/**
 * Increments the per-user SMS counter by 1 and returns the new total.
 *
 * @param int $user_id
 * @return int New total count.
 */
function ks_increment_user_sms_count( $user_id ) {
	$current = ks_get_user_sms_sent_count( $user_id );
	$new     = $current + 1;
	update_user_meta( $user_id, 'ks_sms_sent_total', $new );
	return $new;
}

/**
 * Returns TRUE if the user is allowed to send another SMS.
 * Premium users are always allowed. Free users are capped at ks_get_free_sms_limit().
 *
 * @param int $user_id
 * @return bool
 */
function ks_can_send_sms( $user_id ) {
	if ( ks_is_premium_active( $user_id ) ) {
		return true;
	}
	return ks_get_user_sms_sent_count( $user_id ) < ks_get_free_sms_limit();
}

/**
 * External Server-Cron Endpoint
 *
 * Called by Seohost.pl (or any external scheduler) every minute starting at
 * the configured send hour. Accepts both GET and POST; POST must be used in
 * the cron command to bypass server-level caching (LiteSpeed, Nginx, Varnish).
 * URL: POST /wp-json/ks/v1/run-sms-queue?token=SECRET
 * No WordPress login required – protected by the shared secret token.
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'ks/v1', '/run-sms-queue', array(
		// Accept both GET and POST.
		// POST must be used in the server cron command because server-level caches
		// (LiteSpeed, Nginx FastCGI, Varnish, etc.) never cache POST requests,
		// whereas GET responses to the same URL are cached – silently bypassing PHP.
		'methods'             => array( 'GET', 'POST' ),
		'callback'            => 'ks_handle_external_cron',
		'permission_callback' => '__return_true', // token check happens inside callback
	) );
} );

function ks_handle_external_cron( WP_REST_Request $request ) {
	// Send no-cache headers immediately so the response is never stored by any
	// intermediate cache (caching plugins, CDN, reverse proxy).
	// This is a safety net for GET requests; the cron command should use POST.
	nocache_headers();

	// Use raw param value – sanitize_text_field() must not be applied to security tokens
	// as it may strip or modify characters and cause valid tokens to fail comparison.
	$raw_token      = $request->get_param( 'token' );
	$expected_token = ks_get_cron_secret();

	if ( ! is_string( $raw_token ) || ! hash_equals( $expected_token, $raw_token ) ) {
		ks_log( '[KiedySerwis] External cron: błędny lub brakujący token.' );
		return new WP_REST_Response( array( 'error' => 'Unauthorized' ), 401 );
	}

	// Honour the configured send hour – bail out if the external cron fires too early.
	$current_hour = (int) ks_warsaw_now()->format( 'G' );
	$send_hour    = ks_get_sms_send_hour();
	if ( $current_hour < $send_hour ) {
		ks_log( "[KiedySerwis] External cron: za wcześnie ({$current_hour}:xx < {$send_hour}:00) – pominięto wysyłkę." );
		$response = new WP_REST_Response( array(
			'status'  => 'skipped',
			'reason'  => 'too_early',
			'current' => $current_hour,
			'send_at' => $send_hour,
			'time'    => ks_warsaw_now()->format( 'Y-m-d H:i:s' ),
		), 200 );
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
		$response->header( 'Pragma', 'no-cache' );
		return $response;
	}

	$sent_count = ks_run_sms_batch_for_today();

	ks_log( "[KiedySerwis] External cron: wysłano SMS: {$sent_count}" );

	$response = new WP_REST_Response( array(
		'status' => 'ok',
		'sent'   => $sent_count,
		'time'   => ks_warsaw_now()->format( 'Y-m-d H:i:s' ),
	), 200 );
	$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
	$response->header( 'Pragma', 'no-cache' );
	return $response;
}

/**
 * 1koszyk Webhook Receiver
 */

add_action( 'rest_api_init', function () {
	register_rest_route( 'ks/v1', '/payment-webhook', array(
		'methods'  => 'POST',
		'callback' => 'ks_handle_1koszyk_webhook',
		'permission_callback' => '__return_true', // 1koszyk will call this
	) );
} );

function ks_handle_1koszyk_webhook( WP_REST_Request $request ) {
	// Verify the shared webhook secret to prevent unauthorized privilege escalation.
	// The secret must be configured in 1koszyk.pl's webhook settings and sent as the
	// X-KS-Webhook-Secret HTTP header or as the ks_secret POST body parameter.
	$expected_secret = ks_get_webhook_secret();
	$provided_secret = $request->get_header( 'X-KS-Webhook-Secret' );
	if ( empty( $provided_secret ) ) {
		$params_raw      = $request->get_params();
		$provided_secret = isset( $params_raw['ks_secret'] ) ? $params_raw['ks_secret'] : '';
	}

	if ( ! is_string( $provided_secret ) || ! hash_equals( $expected_secret, $provided_secret ) ) {
		ks_log( '[KiedySerwis] Payment webhook: unauthorized request – incorrect or missing secret.' );
		return new WP_REST_Response( array( 'error' => 'Unauthorized' ), 401 );
	}

	$params = $request->get_params();

	// Log only non-sensitive fields for debugging.
	ks_log( '1koszyk Webhook Incoming: status=' . ( $params['status'] ?? '' ) . ' product_id=' . ( $params['product_id'] ?? '' ) . ' attr1=' . ( $params['attr1'] ?? '' ) );

	// We expect status from 1koszyk, normally it's in 'status' field and it's 'completed' or 'success'
	$status     = isset( $params['status'] )     ? sanitize_text_field( $params['status'] )     : '';
	$user_id    = isset( $params['attr1'] )      ? intval( $params['attr1'] )                   : 0;
	$product_id = isset( $params['product_id'] ) ? sanitize_text_field( $params['product_id'] ) : '';

	// Ensure the target user actually exists before updating their plan.
	if ( $user_id > 0 && ! get_userdata( $user_id ) ) {
		ks_log( "[KiedySerwis] Payment webhook: user_id {$user_id} does not exist." );
		return new WP_REST_Response( array( 'status' => 'ignored', 'message' => 'User not found' ), 200 );
	}

	if ( $user_id > 0 && ( $status === 'completed' || $status === 'success' || $status === 'paid' ) ) {
		$days_to_add = 30; // Default
		if ( strpos( $product_id, '365' ) !== false ) {
			$days_to_add = 365;
		}

		$current_expiry = (int) get_user_meta( $user_id, 'ks_plan_expiry', true );
		$base_time  = ( $current_expiry > time() ) ? $current_expiry : time();
		$new_expiry = $base_time + ( $days_to_add * DAY_IN_SECONDS );

		update_user_meta( $user_id, 'ks_plan_status', 'premium' );
		update_user_meta( $user_id, 'ks_plan_expiry', $new_expiry );
		update_user_meta( $user_id, 'ks_plan_days', $days_to_add );

		// Award referral bonus to the referrer (only on first premium upgrade).
		ks_award_referral_bonus( $user_id );

		// Purge cache so plan status is visible immediately in the panel
		ks_purge_user_cache( $user_id );

		ks_log( "1koszyk Success: User $user_id updated. New expiry: " . date( 'Y-m-d H:i:s', $new_expiry ) );

		return new WP_REST_Response( array( 'status' => 'success', 'message' => 'User updated' ), 200 );
	}

	return new WP_REST_Response( array( 'status' => 'ignored', 'message' => 'No action taken' ), 200 );
}

/**
 * ============================================================
 * MODULE: PROTOKÓŁ SERWISOWY – handlers
 * ============================================================
 */

/**
 * Save protocol settings (checklist items, custom fields, rating flag).
 */
function ks_handle_save_protocol_settings() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	if ( ! isset( $_POST['ks_protocol_settings_nonce'] ) || ! wp_verify_nonce( $_POST['ks_protocol_settings_nonce'], 'ks_save_protocol_settings' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$user_id = get_current_user_id();

	if ( ! ks_is_premium_active( $user_id ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'protokol' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	// Protocol is always enabled – no toggle
	update_user_meta( $user_id, 'ks_protocol_enabled', '1' );

	// Checklist items – submitted as an array of individual fields (one per row);
	// store as plain UTF-8 text (one per line) to preserve Polish characters.
	$checklist_raw = '';
	if ( isset( $_POST['ks_protocol_checklist'] ) && is_array( $_POST['ks_protocol_checklist'] ) ) {
		$items = array_filter(
			array_map( 'sanitize_text_field', wp_unslash( $_POST['ks_protocol_checklist'] ) ),
			function( $v ) { return $v !== ''; }
		);
		$checklist_raw = implode( "\n", array_values( $items ) );
	}
	update_user_meta( $user_id, 'ks_protocol_checklist', $checklist_raw );

	// Footer note
	$footer = isset( $_POST['ks_protocol_footer'] ) ? sanitize_textarea_field( $_POST['ks_protocol_footer'] ) : '';
	update_user_meta( $user_id, 'ks_protocol_footer', $footer );

	// Company stamp data (ks_protokol_* prefix)
	$proto_fields = array(
		'ks_protokol_company_name'    => 'sanitize_text_field',
		'ks_protokol_company_address' => 'sanitize_text_field',
		'ks_protokol_company_nip'     => 'sanitize_text_field',
		'ks_protokol_company_email'   => 'sanitize_email',
		'ks_protokol_company_phone'   => 'sanitize_text_field',
		'ks_protokol_company_contact' => 'sanitize_text_field',
	);
	foreach ( $proto_fields as $meta_key => $sanitize_fn ) {
		if ( isset( $_POST[ $meta_key ] ) ) {
			update_user_meta( $user_id, $meta_key, $sanitize_fn( wp_unslash( $_POST[ $meta_key ] ) ) );
		}
	}

	// Purge page cache so the updated settings are visible immediately
	ks_purge_user_cache( $user_id );

	wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'protokol', 'protokol_saved' => '1' ), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_save_protocol_settings', 'ks_handle_save_protocol_settings' );

/**
 * Send service protocol email (HTML formatted, with signature image).
 */
function ks_handle_send_protocol() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	if ( ! isset( $_POST['ks_send_protocol_nonce'] ) || ! wp_verify_nonce( $_POST['ks_send_protocol_nonce'], 'ks_send_protocol' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$user_id   = get_current_user_id();
	$device_id = intval( $_POST['device_id'] ?? 0 );
	$email     = sanitize_email( wp_unslash( $_POST['protocol_email'] ?? '' ) );

	// Strict email validation
	if ( ! ks_is_premium_active( $user_id ) || ! $device_id ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'protokol', 'proto_error' => '1' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}
	if ( ! $email || ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'protokol', 'proto_error' => 'invalid_email' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	// Centralized ownership check.
	if ( ! ks_verify_device_ownership( $device_id, $user_id ) ) {
		wp_die( 'Nieprawidłowe urządzenie.' );
	}

	// Collect submitted checklist items – plain text values preserved.
	$checked_items = isset( $_POST['proto_items'] ) && is_array( $_POST['proto_items'] )
		? array_map( 'sanitize_text_field', wp_unslash( $_POST['proto_items'] ) )
		: array();

	// Client data
	$client_name  = sanitize_text_field( wp_unslash( $_POST['ks_client_name'] ?? '' ) );
	$client_phone = sanitize_text_field( wp_unslash( $_POST['ks_client_phone'] ?? '' ) );

	// Notes
	$proto_notes = sanitize_textarea_field( wp_unslash( $_POST['ks_protokol_notes'] ?? '' ) );

	// Send copy to technician
	$send_copy    = ! empty( $_POST['ks_send_copy_to_tech'] );
	$tech_email   = $send_copy ? sanitize_email( wp_unslash( $_POST['ks_tech_copy_email'] ?? '' ) ) : '';

	// Save device extra fields and get values
	$device_serial = sanitize_text_field( wp_unslash( $_POST['ks_device_serial'] ?? '' ) );
	$device_year   = sanitize_text_field( wp_unslash( $_POST['ks_device_year'] ?? '' ) );
	if ( $device_serial !== '' ) {
		update_post_meta( $device_id, 'ks_device_serial', $device_serial );
	}
	if ( $device_year !== '' ) {
		update_post_meta( $device_id, 'ks_device_year', $device_year );
	}

	// Signature (base64 PNG from canvas) – save as file for absolute URL in email
	$signature_url = '';
	if ( ! empty( $_POST['proto_signature'] ) ) {
		$raw_sig = wp_unslash( $_POST['proto_signature'] );
		if ( preg_match( '/^data:image\/(png|jpeg);base64,/', $raw_sig ) ) {
			$base64_data = substr( $raw_sig, strpos( $raw_sig, ',' ) + 1 );
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			$image_data  = base64_decode( $base64_data, true );
			if ( false !== $image_data ) {
				$upload_dir = wp_upload_dir();
				$sig_dir    = trailingslashit( $upload_dir['basedir'] ) . 'ks-signatures/';
				$sig_base   = trailingslashit( $upload_dir['baseurl'] ) . 'ks-signatures/';
				if ( ! is_dir( $sig_dir ) ) {
					wp_mkdir_p( $sig_dir );
				}
				// Write .htaccess to block direct listing on Apache servers
				$htaccess = $sig_dir . '.htaccess';
				if ( ! file_exists( $htaccess ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
					file_put_contents( $htaccess, "Options -Indexes\n" );
				}
				$filename = 'sig-' . $user_id . '-' . time() . '.png';
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
				if ( false !== file_put_contents( $sig_dir . $filename, $image_data ) ) {
					$signature_url = $sig_base . $filename;
				}
			}
		}
	}

	// Build HTML email
	$company_name  = get_user_meta( $user_id, 'ks_protokol_company_name', true )
		?: ( get_user_meta( $user_id, 'ks_company_name', true ) ?: get_the_author_meta( 'display_name', $user_id ) );
	$company_address = get_user_meta( $user_id, 'ks_protokol_company_address', true );
	$company_nip     = get_user_meta( $user_id, 'ks_protokol_company_nip', true );
	$company_email   = get_user_meta( $user_id, 'ks_protokol_company_email', true )
		?: get_the_author_meta( 'user_email', $user_id );
	$company_phone   = get_user_meta( $user_id, 'ks_protokol_company_phone', true )
		?: get_user_meta( $user_id, 'ks_company_phone', true );
	$company_contact = get_user_meta( $user_id, 'ks_protokol_company_contact', true );

	$company_logo_id  = get_user_meta( $user_id, 'ks_company_logo', true );
	$company_logo_url = $company_logo_id ? wp_get_attachment_url( (int) $company_logo_id ) : '';
	$footer_note   = get_user_meta( $user_id, 'ks_protocol_footer', true );
	$device_name   = get_the_title( $device_id );
	$device_address = get_post_meta( $device_id, 'ks_adres_urzadzenia', true );
	$service_date   = get_post_meta( $device_id, 'ks_data_serwisu', true );

	// Device extra fields — use submitted values (already saved above) or fall back to stored meta
	if ( '' === $device_serial ) {
		$device_serial = get_post_meta( $device_id, 'ks_device_serial', true );
	}
	if ( '' === $device_year ) {
		$device_year = get_post_meta( $device_id, 'ks_device_year', true );
	}

	// Checklist stored as plain newline-separated text
	$checklist_raw = get_user_meta( $user_id, 'ks_protocol_checklist', true );
	$all_checklist = $checklist_raw
		? array_values( array_filter( array_map( 'trim', explode( "\n", $checklist_raw ) ) ) )
		: array();

	// Technician's registered email for Reply-To
	$technician_email = get_the_author_meta( 'user_email', $user_id );

	ob_start();
	?>
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body { font-family: Arial, sans-serif; color: #1e293b; margin: 0; padding: 0; background: #f8fafc; }
.wrap { max-width: 680px; margin: 30px auto; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
.header { background: #4F46E5; color: #fff; padding: 28px 40px; display: flex; align-items: center; gap: 20px; }
.header-logo-wrap { background: #fff; border-radius: 10px; padding: 8px; flex-shrink: 0; display: inline-flex; align-items: center; justify-content: center; }
.header-logo { width: 64px; height: 64px; object-fit: contain; max-width: 112px; display: block; }
.header-text h1 { margin: 0 0 4px; font-size: 22px; }
.header-text p { margin: 0; opacity: .8; font-size: 14px; }
.body { padding: 32px 40px; }
.section-title { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; color: #64748b; margin: 24px 0 10px; border-bottom: 1px solid #f1f5f9; padding-bottom: 6px; }
.info-row { display: flex; gap: 12px; margin-bottom: 6px; font-size: 14px; }
.info-label { color: #64748b; min-width: 160px; flex-shrink: 0; }
.checklist-item { display: flex; align-items: center; gap: 8px; padding: 6px 0; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
.check-yes { color: #10B981; font-weight: 700; }
.notes-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px 16px; font-size: 14px; line-height: 1.6; margin-top: 8px; white-space: pre-wrap; }
.sig-section { margin-top: 24px; border-top: 2px solid #e2e8f0; padding-top: 20px; }
.sig-placeholder { display: inline-block; border: 2px dashed #cbd5e1; border-radius: 8px; padding: 16px 32px; color: #94a3b8; font-size: 13px; margin-top: 8px; }
.footer-note { margin-top: 24px; font-size: 12px; color: #94a3b8; border-top: 1px solid #f1f5f9; padding-top: 16px; }
@media (max-width: 600px) {
  .body { padding: 20px; }
  .header { padding: 20px; flex-direction: column; }
  .info-label { min-width: 120px; }
}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <?php if ( $company_logo_url ) : ?>
    <span class="header-logo-wrap"><img src="<?php echo esc_url( $company_logo_url ); ?>" class="header-logo" alt="<?php echo esc_attr( $company_name ); ?>"></span>
    <?php endif; ?>
    <div class="header-text">
      <h1>Protokół Serwisowy</h1>
      <p><?php echo esc_html( $company_name ); ?><?php if ( $company_phone ) echo ' &bull; ' . esc_html( $company_phone ); ?></p>
    </div>
  </div>
  <div class="body">

    <?php if ( $company_address || $company_nip || $company_email || $company_phone || $company_contact ) : ?>
    <div class="section-title">Dane serwisanta</div>
    <?php if ( $company_name ) : ?>
    <div class="info-row"><span class="info-label">Firma:</span><strong><?php echo esc_html( $company_name ); ?></strong></div>
    <?php endif; ?>
    <?php if ( $company_address ) : ?>
    <div class="info-row"><span class="info-label">Adres:</span><?php echo esc_html( $company_address ); ?></div>
    <?php endif; ?>
    <?php if ( $company_nip ) : ?>
    <div class="info-row"><span class="info-label">NIP:</span><?php echo esc_html( $company_nip ); ?></div>
    <?php endif; ?>
    <?php if ( $company_phone ) : ?>
    <div class="info-row"><span class="info-label">Telefon:</span><?php echo esc_html( $company_phone ); ?></div>
    <?php endif; ?>
    <?php if ( $company_email ) : ?>
    <div class="info-row"><span class="info-label">E-mail:</span><?php echo esc_html( $company_email ); ?></div>
    <?php endif; ?>
    <?php if ( $company_contact ) : ?>
    <div class="info-row"><span class="info-label">Osoba kontaktowa:</span><?php echo esc_html( $company_contact ); ?></div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if ( $client_name || $email || $client_phone ) : ?>
    <div class="section-title">Dane klienta</div>
    <?php if ( $client_name ) : ?>
    <div class="info-row"><span class="info-label">Imię i nazwisko:</span><strong><?php echo esc_html( $client_name ); ?></strong></div>
    <?php endif; ?>
    <div class="info-row"><span class="info-label">E-mail:</span><?php echo esc_html( $email ); ?></div>
    <?php if ( $client_phone ) : ?>
    <div class="info-row"><span class="info-label">Telefon:</span><?php echo esc_html( $client_phone ); ?></div>
    <?php endif; ?>
    <?php endif; ?>

    <div class="section-title">Urządzenie</div>
    <div class="info-row"><span class="info-label">Nazwa / Model:</span><strong><?php echo esc_html( $device_name ); ?></strong></div>
    <?php if ( $device_address ) : ?><div class="info-row"><span class="info-label">Adres:</span><?php echo esc_html( $device_address ); ?></div><?php endif; ?>
    <div class="info-row"><span class="info-label">Data serwisu:</span><?php echo esc_html( $service_date ?: ks_warsaw_now()->format( 'Y-m-d' ) ); ?></div>
    <?php if ( $device_serial ) : ?>
    <div class="info-row"><span class="info-label">Numer fabryczny:</span><?php echo esc_html( $device_serial ); ?></div>
    <?php endif; ?>
    <?php if ( $device_year ) : ?>
    <div class="info-row"><span class="info-label">Rok produkcji:</span><?php echo esc_html( $device_year ); ?></div>
    <?php endif; ?>

    <?php if ( ! empty( $checked_items ) ) : ?>
    <div class="section-title">Wykonane czynności</div>
    <?php foreach ( $checked_items as $item ) : ?>
    <div class="checklist-item">
      <span class="check-yes">&#10004;</span>
      <?php echo esc_html( $item ); ?>
    </div>
    <?php endforeach; ?>
    <?php elseif ( ! empty( $all_checklist ) ) : ?>
    <div class="section-title">Wykonane czynności</div>
    <?php foreach ( $all_checklist as $item ) : ?>
    <div class="checklist-item">
      <span>&#9711;</span>
      <?php echo esc_html( $item ); ?>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>

    <?php if ( $proto_notes ) : ?>
    <div class="section-title">Uwagi</div>
    <div class="notes-box"><?php echo esc_html( $proto_notes ); ?></div>
    <?php endif; ?>

    <?php if ( $signature_url ) : ?>
    <div class="sig-section">
      <div class="section-title">Podpis klienta</div>
      <img src="<?php echo esc_url( $signature_url ); ?>" style="max-width:240px; width:100%; border:1px solid #e2e8f0; border-radius:8px; margin-top:8px; display:block;" alt="Podpis klienta">
    </div>
    <?php elseif ( ! empty( $_POST['proto_signature'] ) ) : ?>
    <div class="sig-section">
      <div class="section-title">Podpis klienta</div>
      <div class="sig-placeholder">Podpis niedostępny</div>
    </div>
    <?php endif; ?>

    <?php if ( $footer_note ) : ?>
    <div class="footer-note"><?php echo nl2br( esc_html( $footer_note ) ); ?></div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
	<?php
	$html = ob_get_clean();

	$subject = 'Protokół serwisowy – ' . $device_name . ' (' . ks_warsaw_now()->format( 'd.m.Y' ) . ')';
	$headers = array(
		'Content-Type: text/html; charset=UTF-8',
		'From: KiedySerwis.pl <biuro@kiedyserwis.pl>',
		'Reply-To: ' . $company_name . ' <' . $technician_email . '>',
	);

	wp_mail( $email, $subject, $html, $headers );

	// Optionally send copy to technician
	if ( $send_copy && $tech_email && is_email( $tech_email ) && $tech_email !== $email ) {
		$copy_subject = '[KOPIA] ' . $subject;
		wp_mail( $tech_email, $copy_subject, $html, $headers );
	}

	$redirect_args = array(
		'ks_tab'        => 'protokol',
		'proto_sent'    => '1',
		'proto_sent_to' => rawurlencode( $email ),
	);
	wp_safe_redirect( add_query_arg( $redirect_args, home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_send_protocol', 'ks_handle_send_protocol' );

/**
 * ============================================================
 * MODULE: OFERTOMAT – handler
 * ============================================================
 */

/**
 * Handle Ofertomat form submission: build HTML offer email and send it.
 */
function ks_handle_send_ofertomat() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	if ( ! isset( $_POST['ks_send_ofertomat_nonce'] ) || ! wp_verify_nonce( $_POST['ks_send_ofertomat_nonce'], 'ks_send_ofertomat' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$user_id = get_current_user_id();

	if ( ! ks_is_premium_active( $user_id ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'ofertomat', 'ofert_error' => '1' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	$client_email   = sanitize_email( wp_unslash( $_POST['ofert_send_email'] ?? '' ) );
	if ( ! $client_email || ! is_email( $client_email ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'ofertomat', 'ofert_error' => 'invalid_email' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	// Collect and sanitize items
	$raw_items = isset( $_POST['ofert_items'] ) && is_array( $_POST['ofert_items'] ) ? $_POST['ofert_items'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$items     = array();
	foreach ( $raw_items as $row ) {
		$name      = sanitize_text_field( wp_unslash( $row['name'] ?? '' ) );
		$desc      = sanitize_text_field( wp_unslash( $row['desc'] ?? '' ) );
		$qty       = max( 0.0, (float) ( $row['qty'] ?? 0 ) );
		$price_net = max( 0.0, (float) ( $row['price_net'] ?? 0 ) );
		$vat_str   = in_array( $row['vat'] ?? '', array( '23', '8', '5', '0', 'zw' ), true ) ? $row['vat'] : '23';
		if ( '' === $name ) {
			continue;
		}
		$vat_rate  = ( 'zw' === $vat_str || '0' === $vat_str ) ? 0.0 : (float) $vat_str / 100;
		$row_net   = round( $qty * $price_net, 2 );
		$row_vat   = round( $row_net * $vat_rate, 2 );
		$row_gross = $row_net + $row_vat;
		$items[]   = array(
			'name'      => $name,
			'desc'      => $desc,
			'qty'       => $qty,
			'price_net' => $price_net,
			'vat_str'   => $vat_str,
			'row_net'   => $row_net,
			'row_vat'   => $row_vat,
			'row_gross' => $row_gross,
		);
	}

	if ( empty( $items ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'ofertomat', 'ofert_error' => 'no_items' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	// Remaining fields
	$client_name    = sanitize_text_field( wp_unslash( $_POST['ofert_client_name'] ?? '' ) );
	$client_phone   = sanitize_text_field( wp_unslash( $_POST['ofert_client_phone'] ?? '' ) );
	$client_address = sanitize_text_field( wp_unslash( $_POST['ofert_client_address'] ?? '' ) );
	$offer_title    = sanitize_text_field( wp_unslash( $_POST['ofert_title'] ?? '' ) );
	$notes          = sanitize_textarea_field( wp_unslash( $_POST['ofert_notes'] ?? '' ) );
	$valid_until    = sanitize_text_field( wp_unslash( $_POST['ofert_valid_until'] ?? '' ) );
	$conditions     = sanitize_text_field( wp_unslash( $_POST['ofert_conditions'] ?? '' ) );
	$discount       = max( 0.0, (float) ( $_POST['ofert_discount'] ?? 0 ) );
	$sum_net        = max( 0.0, (float) ( $_POST['ofert_sum_net'] ?? 0 ) );
	$sum_vat        = max( 0.0, (float) ( $_POST['ofert_sum_vat'] ?? 0 ) );
	$sum_gross      = (float) ( $_POST['ofert_sum_gross'] ?? 0 );
	$copy_to_me     = ! empty( $_POST['ofert_copy_to_me'] );

	// Recalculate server-side totals (ignore client-submitted values)
	$srv_net   = 0.0;
	$srv_vat   = 0.0;
	foreach ( $items as $it ) {
		$srv_net += $it['row_net'];
		$srv_vat += $it['row_vat'];
	}
	$srv_net   = round( $srv_net, 2 );
	$srv_vat   = round( $srv_vat, 2 );
	$srv_gross = round( $srv_net + $srv_vat - $discount, 2 );

	// Company data from business card
	$company_name    = get_user_meta( $user_id, 'ks_company_name', true )
		?: get_the_author_meta( 'display_name', $user_id );
	$company_phone   = get_user_meta( $user_id, 'ks_company_phone', true );
	$company_url     = get_user_meta( $user_id, 'ks_company_url', true );
	$company_city    = get_user_meta( $user_id, 'ks_company_city', true );
	$company_logo_id = get_user_meta( $user_id, 'ks_company_logo', true );
	$company_logo    = $company_logo_id ? wp_get_attachment_url( (int) $company_logo_id ) : '';
	$tech_email      = get_the_author_meta( 'user_email', $user_id );

	$title = $offer_title ?: 'Oferta handlowa';

	// Build HTML e-mail
	ob_start();
	?>
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body { font-family: Arial, sans-serif; color: #1e293b; margin: 0; padding: 0; background: #f8fafc; }
.wrap { max-width: 680px; margin: 30px auto; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
.header { background: #4F46E5; color: #fff; padding: 28px 40px; display: flex; align-items: center; gap: 20px; }
.header-logo-wrap { background: #fff; border-radius: 10px; padding: 8px; flex-shrink: 0; display: inline-flex; align-items: center; justify-content: center; }
.header-logo { width: 64px; height: 64px; object-fit: contain; max-width: 112px; display: block; }
.header-text h1 { margin: 0 0 4px; font-size: 22px; }
.header-text p { margin: 0; opacity: .8; font-size: 14px; }
.body { padding: 32px 40px; }
.section-title { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; color: #64748b; margin: 24px 0 10px; border-bottom: 1px solid #f1f5f9; padding-bottom: 6px; }
.info-row { display: flex; gap: 12px; margin-bottom: 6px; font-size: 14px; }
.info-label { color: #64748b; min-width: 160px; flex-shrink: 0; }
table.items { width: 100%; border-collapse: collapse; font-size: 14px; }
table.items th { background: #f1f5f9; color: #475569; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; padding: 8px 10px; text-align: left; }
table.items td { padding: 9px 10px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }
table.items tr:last-child td { border-bottom: none; }
table.items td.num { text-align: right; white-space: nowrap; }
.summary-table { width: 100%; border-collapse: collapse; font-size: 14px; max-width: 300px; margin-left: auto; margin-top: 12px; }
.summary-table td { padding: 6px 10px; }
.summary-table td:last-child { text-align: right; font-weight: 600; }
.summary-table tr.total td { border-top: 2px solid #e2e8f0; font-size: 16px; font-weight: 800; color: #4F46E5; padding-top: 10px; }
.notes-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px 16px; font-size: 14px; line-height: 1.6; margin-top: 8px; white-space: pre-wrap; }
.footer-contact { margin-top: 28px; border-top: 2px solid #e2e8f0; padding-top: 18px; font-size: 13px; color: #64748b; }
@media (max-width: 600px) {
  .body { padding: 20px; }
  .header { padding: 20px; flex-direction: column; }
  .info-label { min-width: 110px; }
}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <?php if ( $company_logo ) : ?>
    <span class="header-logo-wrap"><img src="<?php echo esc_url( $company_logo ); ?>" class="header-logo" alt="<?php echo esc_attr( $company_name ); ?>"></span>
    <?php endif; ?>
    <div class="header-text">
      <h1><?php echo esc_html( $title ); ?></h1>
      <p><?php echo esc_html( $company_name ); ?><?php if ( $company_phone ) echo ' &bull; ' . esc_html( $company_phone ); ?></p>
    </div>
  </div>
  <div class="body">

    <!-- Company data -->
    <div class="section-title">Dane serwisanta</div>
    <div class="info-row"><span class="info-label">Firma:</span><strong><?php echo esc_html( $company_name ); ?></strong></div>
    <?php if ( $company_phone ) : ?><div class="info-row"><span class="info-label">Telefon:</span><?php echo esc_html( $company_phone ); ?></div><?php endif; ?>
    <?php if ( $company_city ) : ?><div class="info-row"><span class="info-label">Miasto:</span><?php echo esc_html( $company_city ); ?></div><?php endif; ?>
    <?php if ( $company_url ) : ?><div class="info-row"><span class="info-label">Strona:</span><a href="<?php echo esc_url( $company_url ); ?>" style="color:#4F46E5;"><?php echo esc_html( $company_url ); ?></a></div><?php endif; ?>

    <!-- Client data -->
    <?php if ( $client_name || $client_email || $client_phone || $client_address ) : ?>
    <div class="section-title">Dane klienta</div>
    <?php if ( $client_name ) : ?><div class="info-row"><span class="info-label">Imię i nazwisko:</span><strong><?php echo esc_html( $client_name ); ?></strong></div><?php endif; ?>
    <?php if ( $client_email ) : ?><div class="info-row"><span class="info-label">E-mail:</span><?php echo esc_html( $client_email ); ?></div><?php endif; ?>
    <?php if ( $client_phone ) : ?><div class="info-row"><span class="info-label">Telefon:</span><?php echo esc_html( $client_phone ); ?></div><?php endif; ?>
    <?php if ( $client_address ) : ?><div class="info-row"><span class="info-label">Adres instalacji:</span><?php echo esc_html( $client_address ); ?></div><?php endif; ?>
    <?php endif; ?>

    <!-- Items table -->
    <div class="section-title">Pozycje oferty</div>
    <table class="items">
      <thead>
        <tr>
          <th>Nazwa</th>
          <th style="text-align:right;">Ilość</th>
          <th style="text-align:right;">Cena netto</th>
          <th style="text-align:right;">VAT</th>
          <th style="text-align:right;">Netto</th>
          <th style="text-align:right;">VAT</th>
          <th style="text-align:right;">Brutto</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ( $items as $it ) : ?>
        <tr>
          <td>
            <strong><?php echo esc_html( $it['name'] ); ?></strong>
            <?php if ( $it['desc'] ) : ?><br><span style="color:#64748b; font-size:12px;"><?php echo esc_html( $it['desc'] ); ?></span><?php endif; ?>
          </td>
          <td class="num"><?php echo number_format( $it['qty'], 2, ',', ' ' ); ?></td>
          <td class="num"><?php echo number_format( $it['price_net'], 2, ',', ' ' ); ?> zł</td>
          <td class="num"><?php echo esc_html( $it['vat_str'] ); ?>%</td>
          <td class="num"><?php echo number_format( $it['row_net'], 2, ',', ' ' ); ?> zł</td>
          <td class="num"><?php echo number_format( $it['row_vat'], 2, ',', ' ' ); ?> zł</td>
          <td class="num"><strong><?php echo number_format( $it['row_gross'], 2, ',', ' ' ); ?> zł</strong></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>

    <!-- Summary -->
    <table class="summary-table">
      <tr><td>Suma netto:</td><td><?php echo number_format( $srv_net, 2, ',', ' ' ); ?> zł</td></tr>
      <tr><td>Suma VAT:</td><td><?php echo number_format( $srv_vat, 2, ',', ' ' ); ?> zł</td></tr>
      <?php if ( $discount > 0 ) : ?>
      <tr><td>Rabat:</td><td>&minus; <?php echo number_format( $discount, 2, ',', ' ' ); ?> zł</td></tr>
      <?php endif; ?>
      <tr class="total"><td>Suma brutto:</td><td><?php echo number_format( $srv_gross, 2, ',', ' ' ); ?> zł</td></tr>
    </table>

    <?php if ( $notes ) : ?>
    <div class="section-title">Uwagi</div>
    <div class="notes-box"><?php echo esc_html( $notes ); ?></div>
    <?php endif; ?>

    <?php if ( $valid_until || $conditions ) : ?>
    <div class="section-title">Warunki</div>
    <?php if ( $valid_until ) : ?><div class="info-row"><span class="info-label">Ważność oferty:</span><?php echo esc_html( $valid_until ); ?></div><?php endif; ?>
    <?php if ( $conditions ) : ?><div class="info-row"><span class="info-label">Warunki realizacji:</span><?php echo esc_html( $conditions ); ?></div><?php endif; ?>
    <?php endif; ?>

    <!-- Footer contact -->
    <div class="footer-contact">
      <strong><?php echo esc_html( $company_name ); ?></strong>
      <?php if ( $company_phone ) : ?> &bull; <?php echo esc_html( $company_phone ); ?><?php endif; ?>
      <?php if ( $company_url ) : ?> &bull; <a href="<?php echo esc_url( $company_url ); ?>" style="color:#4F46E5;"><?php echo esc_html( $company_url ); ?></a><?php endif; ?>
      <?php if ( $company_city ) : ?>
      <br><?php echo esc_html( $company_city ); ?>
      <?php endif; ?>
    </div>

  </div>
</div>
</body>
</html>
	<?php
	$html = ob_get_clean();

	$subject = $title . ' – ' . $company_name . ' (' . ks_warsaw_now()->format( 'd.m.Y' ) . ')';
	$headers = array(
		'Content-Type: text/html; charset=UTF-8',
		'From: KiedySerwis.pl <biuro@kiedyserwis.pl>',
		'Reply-To: ' . $company_name . ' <' . $tech_email . '>',
	);

	wp_mail( $client_email, $subject, $html, $headers );

	if ( $copy_to_me && $tech_email && is_email( $tech_email ) && $tech_email !== $client_email ) {
		wp_mail( $tech_email, '[KOPIA] ' . $subject, $html, $headers );
	}

	wp_safe_redirect( add_query_arg( array(
		'ks_tab'        => 'ofertomat',
		'ofert_sent'    => '1',
		'ofert_sent_to' => rawurlencode( $client_email ),
	), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_send_ofertomat', 'ks_handle_send_ofertomat' );

/**
 * ============================================================
 * MODULE: MAGAZYN – handlers
 * ============================================================
 */

/**
 * Save (add/update) a warehouse part.
 */
function ks_handle_save_czesc() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	if ( ! isset( $_POST['ks_czesc_nonce'] ) || ! wp_verify_nonce( $_POST['ks_czesc_nonce'], 'ks_save_czesc' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$user_id = get_current_user_id();
	if ( ! ks_is_premium_active( $user_id ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'magazyn' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	$part_id  = isset( $_POST['part_id'] ) ? intval( $_POST['part_id'] ) : 0;
	$name     = sanitize_text_field( $_POST['czesc_name'] ?? '' );
	$stock    = max( 0, intval( $_POST['czesc_stan'] ?? 0 ) );
	$minimum  = max( 0, intval( $_POST['czesc_minimum'] ?? 0 ) );

	if ( empty( $name ) ) {
		wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'magazyn', 'mag_error' => '1' ), home_url( '/panel-serwisanta/' ) ) );
		exit;
	}

	if ( $part_id ) {
		// Centralized ownership check.
		if ( ks_verify_part_ownership( $part_id, $user_id ) ) {
			wp_update_post( array( 'ID' => $part_id, 'post_title' => $name ) );
			update_post_meta( $part_id, 'ks_stan', $stock );
			update_post_meta( $part_id, 'ks_minimum', $minimum );
		}
	} else {
		$new_id = wp_insert_post( array(
			'post_title'  => $name,
			'post_type'   => 'ks_czesc',
			'post_status' => 'publish',
			'post_author' => $user_id,
		) );
		if ( $new_id ) {
			update_post_meta( $new_id, 'ks_stan', $stock );
			update_post_meta( $new_id, 'ks_minimum', $minimum );
		}
	}

	// Check for low-stock items and notify once per day
	ks_check_magazyn_low_stock( $user_id );

	wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'magazyn', 'mag_saved' => '1' ), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_save_czesc', 'ks_handle_save_czesc' );

/**
 * Delete a warehouse part.
 */
function ks_handle_delete_czesc() {
	if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	if ( ! isset( $_POST['ks_delete_czesc_nonce'] ) || ! wp_verify_nonce( $_POST['ks_delete_czesc_nonce'], 'ks_delete_czesc' ) ) {
		wp_die( 'Błąd bezpieczeństwa.' );
	}

	$user_id = get_current_user_id();
	$part_id = intval( $_POST['part_id'] ?? 0 );

	// Centralized ownership check.
	if ( ks_verify_part_ownership( $part_id, $user_id ) ) {
		wp_delete_post( $part_id, true );
	}

	wp_safe_redirect( add_query_arg( array( 'ks_tab' => 'magazyn', 'mag_deleted' => '1' ), home_url( '/panel-serwisanta/' ) ) );
	exit;
}
add_action( 'admin_post_ks_delete_czesc', 'ks_handle_delete_czesc' );

/**
 * Check magazyn for low-stock items and send notification email (once per day).
 */
function ks_check_magazyn_low_stock( $user_id ) {
	$transient_key = 'ks_mag_notif_' . $user_id;
	if ( get_transient( $transient_key ) ) {
		return; // Already notified today
	}

	$parts = get_posts( array(
		'post_type'        => 'ks_czesc',
		'author'           => $user_id,
		'post_status'      => 'publish',
		'posts_per_page'   => -1,
		'fields'           => 'ids',
		'suppress_filters' => false, // Allow pre_get_posts isolation to run.
	) );

	$low_stock = array();
	foreach ( $parts as $pid ) {
		$stock   = (int) get_post_meta( $pid, 'ks_stan', true );
		$minimum = (int) get_post_meta( $pid, 'ks_minimum', true );
		if ( $minimum > 0 && $stock <= $minimum ) {
			$low_stock[] = array(
				'name'    => get_the_title( $pid ),
				'stock'   => $stock,
				'minimum' => $minimum,
				'at_min'  => $stock === $minimum,
			);
		}
	}

	if ( empty( $low_stock ) ) {
		return;
	}

	$user  = get_userdata( $user_id );
	$email = $user->user_email;

	$body = "Powiadomienie KiedySerwis.pl – Stan magazynowy\n\n";
	$body .= "Następujące części osiągnęły lub przekroczyły próg minimum:\n\n";
	foreach ( $low_stock as $item ) {
		$label = $item['at_min'] ? 'Osiągnięto minimum' : 'Poniżej minimum';
		$body .= "- {$item['name']}: stan {$item['stock']} / minimum {$item['minimum']} ({$label})\n";
	}
	$body .= "\nZarządzaj magazynem: " . home_url( '/panel-serwisanta/?ks_tab=magazyn' );

	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		'From: KiedySerwis.pl <biuro@kiedyserwis.pl>',
	);

	wp_mail( $email, '[KiedySerwis] Osiągnięto minimum magazynowe', $body, $headers );

	set_transient( $transient_key, 1, DAY_IN_SECONDS );
}

/**
 * Helper: count low-stock parts for current user (for menu badge).
 */
function ks_get_low_stock_count( $user_id ) {
	$parts = get_posts( array(
		'post_type'        => 'ks_czesc',
		'author'           => $user_id,
		'post_status'      => 'publish',
		'posts_per_page'   => -1,
		'fields'           => 'ids',
		'no_found_rows'    => true,
		'suppress_filters' => false, // Allow pre_get_posts isolation to run.
	) );

	$count = 0;
	foreach ( $parts as $pid ) {
		$stock   = (int) get_post_meta( $pid, 'ks_stan', true );
		$minimum = (int) get_post_meta( $pid, 'ks_minimum', true );
		if ( $minimum > 0 && $stock <= $minimum ) {
			$count++;
		}
	}
	return $count;
}
